# JamSpellPro

[![Build Status][travis-image]][travis] [![Release][release-image]][releases]

[travis-image]: https://circleci.com/gh/bakwc/JamSpellPro.svg?style=shield&circle-token=c8ca2d8447201b69f3d242b74dacdb09cdf4b235
[travis]: https://circleci.com/gh/bakwc/JamSpellPro

[release-image]: https://img.shields.io/badge/release-0.9.0-blue.svg?style=flat
[releases]: http://jamspell.com/pro/jamspellpro_0_9_0.tar.gz

JamSpellPro is a spell checking library for automatic and manual spelling correction. It is:

- **accurate** - it consider words surroundings (context) for better correction. It use machine learning ([catboost](https://github.com/catboost/catboost) ) for errors detection and candidates ranking
- **fast** - near 600 words per second
- **multi-language** - it's written in C++ and available for many languages with swig bindings

## Menu
- [Quick Start](#quick-start)
- [Major Features](#major-features)
- [How it works](#how-it-works)
- [Models](https://jamspell.com/pro/w/models.html)
- [Install/Use](https://jamspell.com/pro/w/install.html)
- [Code API](https://jamspell.com/pro/w/code_api.html)
- [HTTP API](https://jamspell.com/pro/w/http_api.html)
- [Quality](https://jamspell.com/pro/w/quality.html)
- [Release Notes](https://jamspell.com/pro/w/release_notes.html)
- [Train](https://jamspell.com/pro/w/train.html)

## Quick Start

- Download [**JamSpellPro 0.9.0**.tar.gz](http://jamspell.com/pro/jamspellpro_0_9_0.tar.gz)
- Choose [model for your language](https://jamspell.com/pro/w/models.html)
- Install with `sudo python3 setup.py install` ([more details](https://jamspell.com/pro/w/install.html)) and use
```python
import jamspellpro
corrector = jamspellpro.TSpellCorrector()
corrector.LoadLangModel('model_en')
corrector.FixFragment('I am the begt spell cherken!')
```

## Major Features

- Context-Aware
- Fixes up to 3 edit distance error
- Splits two merged words
- May detect errors even if word exists in dictionary
- Adding words / sentences at runtime
- Custom model training
- Fine-tuning existing models

## How it works

It use a combination of [catboost](http://catboost.ai) gradient-boosted decision trees, ngram language model and a static dictionary for error detection and candidates ranking.

For each word a set of features generated, such as word length, prediction of 2-grams lm, 3-grams lm, 4 masked grams, absence or presence in dictionary and others.

Fast classifier makes a prediction if the word is correct or not. For errored words a list of candidates generated. This list is ranked with a catboost ranking model.

