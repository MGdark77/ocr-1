import os, errno
import random
import sys
sys.path.append("tools")
import shutil
from collections import defaultdict
import pytest
import jamspellpro
from tools import generate_dataset
from tools.evaluate import evaluateJamspell, wordItertator
from tools.train import trainLangModel, evaluateModel
from tools.train_add import trainAdd


TEMP_DIR = 'temp'
TEMP_MODEL_DIR = 'temp_model'
TEST_DATA = 'test_data/'


def silentremove(filename):
    try:
        os.remove(filename)
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise


#@pytest.mark.skip(reason="save time")
@pytest.mark.parametrize('dataset,alphabet,expected_f1', [
    ('sherlockholmes.txt', 'alphabet_en.txt', 0.65),
    ('kapitanskaya_dochka.txt', 'alphabet_ru.txt', 0.5)
])
def test_train(dataset, alphabet, expected_f1):
    alphabetFile = TEST_DATA + alphabet
    dataset = os.path.join(TEST_DATA, dataset)
    try:
        shutil.rmtree(TEMP_DIR)
    except:
        pass
    try:
        shutil.rmtree(TEMP_MODEL_DIR)
    except:
        pass
    os.mkdir(TEMP_DIR)
    os.mkdir(TEMP_MODEL_DIR)

    f1 = trainLangModel(dataset, TEMP_DIR, alphabetFile, TEMP_MODEL_DIR, ('', ''), None)
    assert f1 >= expected_f1


@pytest.mark.parametrize('dataset,alphabet,expected_f1,positiveTest', [
    ('sherlockholmes.txt', 'alphabet_en.txt', 0.65, True),
    ('sherlockholmes.txt', 'alphabet_en.txt', 0.2, False),
])
def test_trainGrams(dataset, alphabet, expected_f1, positiveTest):
    alphabetFile = TEST_DATA + alphabet
    dataset = os.path.join(TEST_DATA, dataset)
    try:
        shutil.rmtree(TEMP_DIR)
    except:
        pass
    try:
        shutil.rmtree(TEMP_MODEL_DIR)
    except:
        pass
    os.mkdir(TEMP_DIR)
    os.mkdir(TEMP_MODEL_DIR)

    data = open(dataset).read().lower()
    alphachars = set(open(alphabetFile).read().lower().split('\n')[0])
    alphachars.add(' ')

    data = ''.join([c for c in data if c in alphachars])

    if not positiveTest:
        data = data[:int(len(data) * 0.001)]

    words = data.split()
    gramsCounts = defaultdict(int)
    for i in range(0, len(words)-3):
        w1 = words[i]
        w2 = words[i+1]
        w3 = words[i+2]
        gramsCounts[w1] += 1
        gramsCounts[w1 + ' ' + w2] += 1
        gramsCounts[w1 + ' ' + w2 + ' ' + w3] += 1

    gramsFile = os.path.join(TEMP_DIR, 'grams.txt')
    with open(gramsFile, 'w') as f:
        for k, v in gramsCounts.items():
            f.write(str(v))
            f.write(' ')
            f.write(k.strip())
            f.write('\n')
        f.flush()

    f1 = trainLangModel(dataset, TEMP_DIR, alphabetFile, TEMP_MODEL_DIR, ('', ''), None, grams=gramsFile)
    if positiveTest:
        assert f1 >= expected_f1
    else:
        assert f1 <= expected_f1


@pytest.mark.parametrize('alphabet,expected_f1', [
    ('alphabet_en.txt', 0.65),
])
def test_existing_model(alphabet, expected_f1):
    modelPath = os.path.join(TEST_DATA, 'test_model')
    alphabetFile = TEST_DATA + alphabet
    f1 = evaluateModel(modelPath, modelPath, alphabetFile)
    assert f1 >= expected_f1

def test_fixFragment():
    modelPath = os.path.join(TEST_DATA, 'test_model')
    jsp = jamspellpro.TSpellCorrector()
    jsp.LoadLangModel(modelPath)
    assert jsp.FixFragment("I am the begt spell cherken") == "I am the best spell cherken"
    assert jsp.FixFragment("hzllo, world") == "hello, world"

def test_addWord():
    modelPath = os.path.join(TEST_DATA, 'test_model')
    dictPath = os.path.join(modelPath, 'dictionary.txt')
    silentremove(dictPath)
    jsp = jamspellpro.TSpellCorrector()
    jsp.LoadLangModel(modelPath)
    assert jsp.FixFragment("aqcde, world") != "abcde, world"
    jsp.AddText('abcde')
    assert jsp.FixFragment("abcde, world") == "abcde, world"

def test_addWordNewAlphabet():
    modelPath = os.path.join(TEST_DATA, 'test_model')
    dictPath = os.path.join(modelPath, 'dictionary.txt')
    silentremove(dictPath)
    jsp = jamspellpro.TSpellCorrector()
    jsp.LoadLangModel(modelPath)
    assert jsp.FixFragment("aqcde, world") != "a%cde, world"
    jsp.AddText('a%cde')
    assert jsp.FixFragment("aqcde, world") != "a%cde, world"

    newAlphabetPath = os.path.join(TEST_DATA, 'alphabet_en_test1.txt')
    assert jsp.LoadAlphabet(newAlphabetPath)

    jsp.AddText('a%cde')

    assert jsp.FixFragment("aqcde, world") == "a%cde, world"

def test_addWordDict():
    modelPathOrig = os.path.join(TEST_DATA, 'test_model')
    modelPath = os.path.join(TEST_DATA, 'test_model_tmp')

    try:
        shutil.rmtree(modelPath)
    except:
        pass
    shutil.copytree(modelPathOrig, modelPath)

    dictPath = os.path.join(modelPath, 'dictionary.txt')

    silentremove(dictPath)
    jsp = jamspellpro.TSpellCorrector()
    jsp.LoadLangModel(modelPath)

    assert jsp.FixFragment("aqcde, world") != "abcde, world"
    jsp.AddText('abcde', 0.1, True)
    assert jsp.FixFragment("abcde, world") == "abcde, world"

    jsp.SaveLangModel(modelPath)
    words = set()
    for line in open(dictPath, 'rt').read().split():
        words.add(line.strip())
    print("Words:", words)
    assert 'abcde' in words


def test_additionalTrin():
    try:
        shutil.rmtree(TEMP_MODEL_DIR)
    except:
        pass
    baseModelPath = os.path.join(TEST_DATA, 'test_model')
    shutil.copytree(baseModelPath, TEMP_MODEL_DIR)
    alphabetFile = TEST_DATA + 'alphabet_en.txt'
    jsp = jamspellpro.TSpellCorrector()
    jsp.LoadLangModel(TEMP_MODEL_DIR)
    f1 = evaluateModel(baseModelPath, TEMP_MODEL_DIR, alphabetFile)
    assert 0.72 < f1 < 0.82

    del jsp

    trainAdd(os.path.join(TEST_DATA, 'test_model', 'dataset_test.txt'), TEMP_MODEL_DIR, 0.001)

    jsp = jamspellpro.TSpellCorrector()
    jsp.LoadLangModel(TEMP_MODEL_DIR)
    f1 = evaluateModel(baseModelPath, TEMP_MODEL_DIR, alphabetFile)
    assert 0.86 < f1 < 1.0

@pytest.mark.parametrize('origSentences,errSentences,expPoss,expNewPoss,expWords,expectedErrWords', [
    [
        [['abc', 'ccc'], ['abc', 'ccc', 'xyz']],
        [['aba', 'ccc'], ['abc', 'cxc', 'xxx']],
        [0, 1, 0, 1, 2],
        [0, 1, 0, 1, 2],
        ['abc', 'ccc', 'abc', 'ccc', 'xyz'],
        ['aba', 'ccc', 'abc', 'cxc', 'xxx']
    ],
    [
        [['abc', 'ccc'], ['abc', 'ccc', 'xyz', 'qwe']],
        [['aba', 'ccc'], ['abc', 'cccxyz', '+', 'qwe']],
        [0, 1, 0, 1, 3],
        [0, 1, 0, 1, 2],
        ['abc', 'ccc', 'abc', 'ccc xyz', 'qwe'],
        ['aba', 'ccc', 'abc', 'cccxyz', 'qwe']
    ],
])
def testWordIteratorSimple(origSentences,errSentences,expPoss,expNewPoss,expWords,expectedErrWords):
    positions = []
    newPositions = []
    origWords = []
    errWords = []
    for item in wordItertator(origSentences, errSentences):
        positions.append(item.pos)
        newPositions.append(item.newPos)
        origWords.append(item.originalWord)
        errWords.append(item.erroredWord)

    assert positions == expPoss
    assert newPositions == expNewPoss
    assert origWords == expWords
    assert errWords == expectedErrWords

