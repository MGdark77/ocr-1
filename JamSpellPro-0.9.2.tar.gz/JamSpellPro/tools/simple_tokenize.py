#!/usr/bin/env python

import sys
from utils import *

def main():
    srcFile = sys.argv[1]
    dstFile = sys.argv[2]

    originalText = loadText(srcFile)
    originalSentences = generateSentences(originalText)
    words = []
    for s in originalSentences:
        for w in s:
            words.append(w.lower())
    saveText(dstFile, words)

if __name__ == '__main__':
    main()
