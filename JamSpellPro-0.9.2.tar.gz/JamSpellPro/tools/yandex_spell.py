#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import codecs
from collections import Counter
import json
import utils


BASE_URL = 'https://speller.yandex.net/services/spellservice.json/checkText?text='


def checkText(text):
    url = BASE_URL + utils.urlquote(text.encode('utf-8'))
    res = utils.fetchUrl(url)
    res = json.loads(res)
    return res

if __name__ == '__main__':
    text = u'корреспондент чтв наталья дубровская жыясняла причины'
    res = checkText(text)
    print(res)
