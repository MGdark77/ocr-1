from transformers import pipeline
from transformers import RobertaTokenizerFast
from transformers import AutoModelWithLMHead
import torch

tokenizer = RobertaTokenizerFast.from_pretrained(
    "/Users/filipp/Downloads/eng_big_tokenizer",
    max_len=512
)

model = AutoModelWithLMHead.from_pretrained("/Users/filipp/Downloads/transformers/")

fill_mask = pipeline(
    "fill-mask",
    model=model,
    tokenizer=tokenizer
)

def w2id(w):
    return tokenizer.encode(w)[1]

def getWordChances(sentence, pos, words):
    sentence = sentence[:]
    sentence[pos] = '<mask>'
    sentence = u' '.join(sentence) + u'.'
    inputs = tokenizer(sentence, add_special_tokens=True, return_tensors="pt", padding=True)
    input_ids = inputs["input_ids"][0]
    masked_index = (input_ids == tokenizer.mask_token_id).nonzero()
    with torch.no_grad():
        predictions = model(**inputs)[0].cpu()[0].numpy()[masked_index]
    results = []
    for w in words:
        results.append(predictions[w2id(w)])
    return results

def main():
    print(getWordChances(['i', 'want', 'to', 'go', 'home'], 3, ['go', 'come', 'yes', 'wtf', 'dance']))

    # mask = "I want to <mask> home."
    # inputs = tokenizer(mask, add_special_tokens=True, return_tensors="pt", padding=True)
    # print("tokenized:", inputs)
    #
    # input_ids = inputs["input_ids"][0]
    # masked_index = (input_ids == tokenizer.mask_token_id).nonzero()
    #
    # with torch.no_grad():
    #     predictions = model(**inputs)[0].cpu()[0].numpy()[masked_index]
    #
    # print('go', predictions[w2id('go')])
    # print('come', predictions[w2id('come')])
    # print('yes', predictions[w2id('yes')])
    # print('wall', predictions[w2id('wall')])


if __name__ == '__main__':
    main()

