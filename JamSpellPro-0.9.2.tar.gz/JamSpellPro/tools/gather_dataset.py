#!/usr/bin/env python3.7

import os
import sys
import train
from generate_dataset import generateDataset, GeneratorArgs
from lang import SHORT_TO_FULL, FULL_TO_SHORT

SIZES = ['small', 'med', 'big']
LANGUAGES = ['ar', 'no', 'hi', 'pt', 'nl', 'pl', 'uk', 'tr', 'ru', 'en', 'de', 'it', 'fr', 'es']
SKIP_LITERATURE = {'ar'}
SKIP_WIKI = {'ar'}

SIZES_MEGABYTES = {
    'small': 100,
    'med': 500,
    'big': 10000,
}


MODELS_BASE_DIR = '/Users/filipp/koding/JamSpell'
DATASETS_BASE_DIR = '/Users/filipp/koding/JamSpell/dataset/main'
DICTIONARY_BASE_DIR = '/Users/filipp/koding/JamSpell/dataset'
ALPHABET_BASE_DIR = '/Users/filipp/koding/JamSpell/test_data'
PUBLISH_HOST = 'pastexen'
PUBLISH_HOST2 = 'jetson'
PUBLISH_DIR = '/data2/jamspell_models'
NEWS_REMOTE_DIR = '/data2/trash/news/news_texts/'
SUBS_REMOTE_DIR = '/data2/trash/subtitles/extracted/'
WIKI_REMOTE_DIR = '/data2/trash/wiki/'
PUBLISH_HOST_SOURCES_DIR = 'koding/JamSpellPro'
PUBLISH_HOST_GUTENBERG_PATH = '/data2/trash/gutenberg/data/.mirror/'
INTERNET_ARCHIVE_DIR = '/Users/filipp/koding/JamSpell/tools/ic'


META = {
    'ru': (
        MODELS_BASE_DIR+'/dataset/corrected_sents.txt',
        MODELS_BASE_DIR+'/dataset/source_sents.txt'
    ),
}


def getPublishedModels():
    models = os.popen("ssh " + PUBLISH_HOST + " 'ls " + PUBLISH_DIR + "'").read()
    return models.split()


class Dataset(object):

    def __init__(self, lang):
        self.lang = lang
        self.langFull = SHORT_TO_FULL[lang]

    def bake(self):
        print('[info] baking dataset', self.lang)
        if not self.isDirReady():
            self.makeDir()
        if not self.isNewsReady():
            self.bakeNews()
        if not self.isLiteratureReady():
            self.bakeLiteratore()
        if not self.isSubtitlesReady():
            self.bakeSubtitles()
        if not self.isWikiReady():
            self.bakeWiki()
        print('[info]', self.lang, 'dataset ready')
        with open(os.path.join(DATASETS_BASE_DIR, self.lang, 'task_finished'), 'wt') as f:
            f.write('\n')

    def getPathAbs(self, subdir):
        return os.path.join(DATASETS_BASE_DIR, self.lang, subdir)

    def isDirReady(self):
        return os.path.exists(os.path.join(DATASETS_BASE_DIR, self.lang))

    def makeDir(self):
        os.makedirs(os.path.join(DATASETS_BASE_DIR, self.lang), exist_ok=True)

    def isNewsReady(self):
        return os.path.exists(os.path.join(self.getPathAbs('news'), 'task_finished'))

    def isSubtitlesReady(self):
        return os.path.exists(os.path.join(self.getPathAbs('subtitles'), 'task_finished'))

    def isWikiReady(self):
        if self.lang in SKIP_WIKI:
            return True
        return os.path.exists(os.path.join(self.getPathAbs('wiki'), 'task_finished'))

    def isLiteratureReady(self):
        if self.lang in SKIP_LITERATURE:
            return True
        return os.path.exists(os.path.join(self.getPathAbs('literature'), 'task_finished'))

    def bakeNews(self):
        print('[info] fetching', self.lang, 'news')
        os.makedirs(self.getPathAbs('news'), exist_ok=True)
        localNewsPath = os.path.join(self.getPathAbs('news'), 'news1/')
        try:
            os.remove(localNewsPath)
        except OSError:
            pass

        cmd = "scp -r " + PUBLISH_HOST + ":" + NEWS_REMOTE_DIR + '/' + self.lang + '/ ' + localNewsPath
        print(cmd)
        res = os.popen(cmd).read()
        print(res)

        localNewsPath = os.path.join(self.getPathAbs('news'), 'news2/')
        try:
            os.remove(localNewsPath)
        except OSError:
            pass

        cmd = "scp -r " + PUBLISH_HOST2 + ":" + NEWS_REMOTE_DIR + '/' + self.lang + '/ ' + localNewsPath
        print(cmd)
        res = os.popen(cmd).read()
        print(res)
        with open(os.path.join(self.getPathAbs('news'), 'task_finished'), 'wt') as f:
            f.write('\n')

    def bakeSubtitles(self):
        print('[info] fetching', self.lang, 'subtitles')
        os.makedirs(self.getPathAbs('subtitles'), exist_ok=True)
        cmd = "scp " + PUBLISH_HOST + ":" + SUBS_REMOTE_DIR + '/subs_' + self.lang + '.txt ' + self.getPathAbs('subtitles/')
        print(cmd)
        res = os.popen(cmd).read()
        print(res)
        with open(os.path.join(self.getPathAbs('subtitles'), 'task_finished'), 'wt') as f:
            f.write('\n')

    def bakeWiki(self):
        print('[info] fetching', self.lang, 'wiki')
        cmd = "scp -r " + PUBLISH_HOST + ":" + WIKI_REMOTE_DIR + '/extracted_' + self.lang + '/ ' + self.getPathAbs('wiki')
        print(cmd)
        res = os.popen(cmd).read()
        print(res)
        with open(os.path.join(self.getPathAbs('wiki'), 'task_finished'), 'wt') as f:
            f.write('\n')

    def bakeLiteratore(self):
        print('[info] fetching', self.lang, 'literature')
        os.makedirs(self.getPathAbs('literature'), exist_ok=True)
        args = GeneratorArgs()
        args.epub = os.path.join(INTERNET_ARCHIVE_DIR, self.langFull)
        args.out_file = os.path.join(self.getPathAbs('literature'), 'dump')
        args.language = self.langFull
        generateDataset(args)

        with open(os.path.join(self.getPathAbs('literature'), 'task_finished'), 'tw') as f:
            f.write('\n')


class Model(object):
    def __init__(self, lang, size):
        self.lang = lang
        self.size = size

    def dictionaryAbsPath(self):
        return os.path.join(DICTIONARY_BASE_DIR, 'dictionary_' + self.lang + '.txt')

    def alphabetAbsPath(self):
        return os.path.join(ALPHABET_BASE_DIR, 'alphabet_' + self.lang + '.txt')

    def datasetAbsPath(self):
        return os.path.join(DATASETS_BASE_DIR, self.lang + '/')

    def tmpAbsPath(self):
        return os.path.join(MODELS_BASE_DIR, 'tmp_' + self.lang + '_' + self.size)

    def modelDirName(self):
        return 'model_' + self.lang + '_' + self.size

    def modelDirAbs(self):
        return os.path.join(MODELS_BASE_DIR, self.modelDirName())

    def packedModelName(self):
        return self.lang + '_' + self.size + '.tar.gz'

    def packedModelPath(self):
        return os.path.join(MODELS_BASE_DIR, self.packedModelName())

    def bake(self):
        print('[info] baking model', self.packedModelName())
        if not self.isPublished():
            self.publish()
        print('[info]', self.packedModelName(), ' ready')

    def isPublished(self):
        return self.packedModelName() in getPublishedModels() and self.lang != 'ar' and self.lang != 'arabic'

    def publish(self):
        if not self.isPacked():
            self.pack()
        print('[info] publishing model', self.packedModelName())
        cmd = "scp " + self.packedModelPath() + " " + PUBLISH_HOST + ":" + PUBLISH_DIR
        print(cmd)
        res = os.popen(cmd).read()
        print(res)

    def isPacked(self):
        return os.path.exists(self.packedModelPath())

    def pack(self):
        if not self.isTrained():
            self.train()
        print('[info] compressing model', self.packedModelName())
        cmd = "tar -czf " + self.packedModelPath() + " -C " + MODELS_BASE_DIR + " " + self.modelDirName()
        print(cmd)
        res = os.popen(cmd).read()
        print(res)

    def isTrained(self):
        return os.path.exists(self.modelDirAbs())

    def train(self):
        if not self.isReadyToTrain():
            self.prepareToTrain()
        print('[info] training model', self.packedModelPath())
        meta = META.get(self.lang, ('', ''))
        train.trainLangModel(
            dataset=self.datasetAbsPath(),
            tmpdir=self.tmpAbsPath(),
            alphabet=self.alphabetAbsPath(),
            outmodel=self.modelDirAbs(),
            meta=meta,
            dict=self.dictionaryAbsPath(),
            maxBytes=SIZES_MEGABYTES[self.size] * 1024 * 1024
        )

    def isReadyToTrain(self):
        return os.path.exists(os.path.join(self.datasetAbsPath(), 'task_finished')) and \
                os.path.exists(self.alphabetAbsPath()) and \
                os.path.exists(self.dictionaryAbsPath())

    def prepareToTrain(self):
        if not os.path.exists(os.path.join(self.datasetAbsPath(), 'task_finished')):
            dataset = Dataset(self.lang)
            dataset.bake()
            assert os.path.exists(os.path.join(self.datasetAbsPath(), 'task_finished'))

        if not os.path.exists(self.alphabetAbsPath()):
            raise Exception("missing alphabet at", self.alphabetAbsPath())
        if not os.path.exists(self.dictionaryAbsPath()):
            raise Exception("missing dictionary at", self.dictionaryAbsPath())


def publish(model):
    publishedModels = getPublishedModels()
    if model.packedModelName() in publishedModels:
        print('[info]', model.packedModelName(), 'already published, skipping')
        return

    return

def main():
    for lang in LANGUAGES:
        for size in SIZES:
            model = Model(lang, size)
            model.bake()


if __name__ == '__main__':
    main()
