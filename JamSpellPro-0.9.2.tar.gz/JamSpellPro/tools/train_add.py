#!/usr/bin/env python3

import os
import argparse
import jamspellpro

def trainAdd(dataset, modelDir, priority):
    print("[info] start additional training")
    assert os.path.exists(dataset)
    assert os.path.exists(modelDir)

    js = jamspellpro.TSpellCorrector()
    if not js.LoadLangModel(modelDir):
        print("failed to load model")
        return
    js.TrainAdd(dataset, modelDir, priority)
    print("[info] additional train finished")

def main():
    parser = argparse.ArgumentParser(description='train spellchecker model')
    parser.add_argument('-ds', '--dataset', type=str, help='path to single txt file', required=True)
    parser.add_argument('-m', '--model_dir', type=str, help='output model path', required=True)
    parser.add_argument('-p', '--priority', type=float, help='dataset priority, default is 0.001', required=True)

    args = parser.parse_args()

    trainAdd(args.dataset, args.model_dir, args.priority)


if __name__ == '__main__':
    main()
