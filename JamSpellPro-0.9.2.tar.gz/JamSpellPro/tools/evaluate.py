#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import codecs
import random
import argparse
from copy import deepcopy
from typo_model import generateTypos
import time
import copy
import tqdm
from utils import normalize, loadText, generateSentences, loadLines
import utils
from sklearn.metrics import classification_report

try:
    import readline
except:
    pass


class STATE:
    NONE = 0
    LETTER = 1
    DOT = 2
    SPACE = 3


class Corrector(object):
    def __init__(self):
        pass

    def correct(self, sentence, position):
        pass


class DummyCorrector(Corrector):
    def __init__(self):
        super(DummyCorrector, self).__init__()

    def correct(self, sentence, position):
        return sentence[position]


class HunspellCorrector(Corrector):
    def __init__(self, modelPath):
        super(HunspellCorrector, self).__init__()
        import hunspell
        self.__model = hunspell.HunSpell(modelPath + '.dic', modelPath + '.aff')

    def correct(self, sentence, position):
        word = sentence[position]
        if self.__model.spell(word):
            return word
        res = self.__model.suggest(word)
        if res:
            return res
        return sentence[position]


class NorvigCorrector(Corrector):
    def __init__(self, trainFile):
        super(NorvigCorrector, self).__init__()
        import norvig_spell
        norvig_spell.init(trainFile)

    def correct(self, sentence, position):
        word = sentence[position]
        import norvig_spell
        res = norvig_spell.correction(word)
        #print(word + ' -> ' + res)
        return res


class ContextCorrector(Corrector):
    def __init__(self, modelPath):
        super(ContextCorrector, self).__init__()
        import context_spell
        context_spell.init(modelPath + '.txt', modelPath + '.binary')

    def correct(self, sentence, position):
        import context_spell
        return context_spell.correction(sentence, position)


class ContextPrototypeCorrector(Corrector):
    def __init__(self, modelPath):
        super(ContextPrototypeCorrector, self).__init__()
        import context_spell_prototype
        context_spell_prototype.init(modelPath + '.txt', modelPath + '.bin')

    def correct(self, sentence, position):
        import context_spell_prototype
        return context_spell_prototype.correction(sentence, position)


class JamspellOldCorrector(Corrector):
    def __init__(self, modelFile):
        super(JamspellOldCorrector, self).__init__()
        import jamspell
        self.model = jamspell.TSpellCorrector()
        # self.model.SetPenalty(16.0, 0.0)
        if not (self.model.LoadLangModel(modelFile)):
            raise Exception('wrong model file: %s' % modelFile)

    def correct(self, sentence, position):
        cands = list(self.model.GetCandidates(sentence, position))
        if len(cands) == 0:
            return sentence[position]
        return cands


class JamspellCorrector(Corrector):
    def __init__(self, modelDir):
        super(JamspellCorrector, self).__init__()
        import jamspellpro
        import catboost
        self.model = jamspellpro.TSpellCorrector()
        self.model.SetMaxCandiatesToCheck(999)

        DEFAULT_PARAMS = {
            'iterations': 500,
            'custom_metric': ['NDCG', 'PFound', 'AverageGain:top=10'],
            'verbose': False,
            'random_seed': 42,
        }
        parameters = deepcopy(DEFAULT_PARAMS)
        parameters['loss_function'] = 'PairLogitPairwise'

        MODEL_PATH = os.path.join(modelDir, 'catboost_rank.bin')
        ERRORS_MODEL_PATH = os.path.join(modelDir, 'catboost_error.bin')
        SHORT_MODEL_PATH = os.path.join(modelDir, 'catboost_short.bin')

        if os.path.exists(MODEL_PATH):
            self.cbmodel = catboost.CatBoost(parameters)
            self.cbmodel.load_model(MODEL_PATH)

        if os.path.exists(ERRORS_MODEL_PATH):
            self.cbemodel = catboost.CatBoostClassifier()
            self.cbemodel.load_model(ERRORS_MODEL_PATH)

        if os.path.exists(SHORT_MODEL_PATH):
            self.cbsmodel = catboost.CatBoostClassifier()
            self.cbsmodel.load_model(SHORT_MODEL_PATH)

        # self.model.SetPenalty(16.0, 0.0)
        print('[info] loading lang model')
        self.model.LoadLangModel(modelDir)
        print('[info] loaded')

    def scoreFeatures(self, sentence, position):
        return self.model.ScoreFeatures(sentence, position)

    def correct(self, sentence, position):
        cands = list(self.model.GetCandidates(sentence, position))
        if not cands:
            cands.append(sentence[position])
        return cands

        # errFeatures = self.scoreFeatures(sentence, position)
        # prediction = self.cbemodel.predict([errFeatures])[0]
        # if prediction == 0:
        #     return sentence[position]

        hasError = int(self.hasError(sentence, position))

        #print(prediction, hasError)
        #assert prediction == hasError

        if not hasError:
            return sentence[position]

        # if not self.hasError(sentence, position):
        #     return sentence[position]

        cands = None

        #cands = list(self.model.GetCandidates(sentence, position))

        shortFeatures, shortCands = self.getFeaturesShortProd(sentence, position)

        if shortFeatures is not None:
            prediction = self.cbsmodel.predict([shortFeatures])[0]
            if prediction == 1:
                cands = shortCands


        if cands == None:
            cands = list(self.model.GetCandidatesFeatures(sentence, position, True))

        if len(cands) == 0:
            return sentence[position]

        # cands = sorted(cands, key=lambda x: -x[1][-1])[:30]
        # cands = [c[0] for c in cands]


        data_x = [c[1] for c in cands]
        pred_x = self.cbmodel.predict(data_x)

        # print("position: ", position)
        # print("sentence: ", u" ".join(sentence))

        cands = sorted(list(zip([c[0] for c in cands], pred_x)), key=lambda x: -x[1])
        cands = [c[0] for c in cands]

        return cands

    def getFeaturesShort(self, sentence, position, originalWord):
        cands = list(self.model.GetCandidatesFeatures(sentence, position, False))
        if not cands:
            return None

        data_x = [c[1] for c in cands]
        pred_x = self.cbmodel.predict(data_x)
        cands = sorted(list(zip(cands, pred_x)), key=lambda x: -x[1])

        target = int(originalWord in [c[0][0] for c in cands])
        features = [target]
        features += list(cands[0][0][1])
        features.append(cands[0][1])
        features.append(len(cands))
        return features

    def getFeaturesShortProd(self, sentence, position):
        origCands = cands = list(self.model.GetCandidatesFeatures(sentence, position, False))
        if not cands:
            return None, None

        data_x = [c[1] for c in cands]
        pred_x = self.cbmodel.predict(data_x)
        cands = sorted(list(zip(cands, pred_x)), key=lambda x: -x[1])

        features = list(cands[0][0][1])
        features.append(cands[0][1])
        features.append(len(cands))
        return features, origCands


    def getFeatures(self, sentence, position):
        cands = list(self.model.GetCandidatesFeatures(sentence, position, True))
        cands = sorted(cands, key=lambda x: -x[1][-1])[:30]
        return cands

    def hasError(self, sentence, position):
        return self.model.HasError(sentence, position)

    def getMaskedWords(self, sentence, pos, count):
        candidates = list(self.model.GetMaskedWord(sentence, pos, count + 1))
        candidates = sorted(candidates, key=lambda x: -x[1])
        candidates = [x[0] for x in candidates]
        return candidates


class JamspellCorrectorWithBert(Corrector):
    def __init__(self, modelFile):
        super(JamspellCorrectorWithBert, self).__init__()
        import jamspellpro
        import bert_lm
        self.model = jamspellpro.TSpellCorrector()
        self.model.SetMaxCandiatesToCheck(7)
        self.getWordChances = bert_lm.getWordChances
        # self.model.SetPenalty(16.0, 0.0)
        if not (self.model.LoadLangModel(modelFile)):
            raise Exception('wrong model file: %s' % modelFile)

    def correct(self, sentence, position):
        cands = list(self.model.GetCandidates(sentence, position))
        if len(cands) == 0:
            cands = [sentence[position]]

        if cands[0] != sentence[position]:
            # req = sentence[:]
            # req[position] = '<mask>'
            # print('sentence:', u' '.join(sentence))
            # print('masked:', u' '.join(req))

            predictions = self.getWordChances(sentence, position, cands)

            #print('original cands:', cands)
            if max(predictions) > 2.2:
                cands = zip(cands, predictions)
                cands = sorted(cands, key=lambda x: -x[1])
                #print("preds:", cands)
                cands = [x[0] for x in cands]

            # print('fixed cands:', cands)
            # print()
            # input()
        return cands

    def hasError(self, sentence, position):
        return self.model.HasError(sentence, position)

    def getMaskedWords(self, sentence, pos, count):
        candidates = list(self.model.GetMaskedWord(sentence, pos, count + 1))
        candidates = sorted(candidates, key=lambda x: -x[1])
        candidates = [x[0] for x in candidates]
        return candidates

class BertCorrector(Corrector):
    def __init__(self):
        super(BertCorrector, self).__init__()
        import bert_lm
        self.fillMask = bert_lm.fill_mask

    def getMaskedWords(self, sentence, pos, count):
        sentence = sentence[:]
        sentence[pos] = u'<mask>'
        origLen = len(sentence)
        #print("Orig:", sentence)
        #print("orig len:", len(sentence))
        sentence = u' '.join(sentence) + '.'
        predictions = self.fillMask(sentence)
        candidates = []
        for p in predictions:
            score = p['score']
            seq = p['sequence'][3:-5].split(' ')
            #print("Seq:", seq)
            #print("new len:", len(seq))
            if len(seq) != origLen:
                continue
            word = seq[pos]
            candidates.append((word, score))

        candidates = sorted(candidates, key=lambda x: -x[1])
        candidates = [x[0] for x in candidates]
        return candidates

class NeuralCorrector(Corrector):
    def __init__(self):
        super(NeuralCorrector, self).__init__()
        import neural_errors_detector
        self.corrector = neural_errors_detector.NeuralErrorsDetector()

    def hasError(self, sentence, position):
        return self.corrector.hasError(sentence, position)

class YaSpellerCorrector(Corrector):
    def __init__(self):
        super(YaSpellerCorrector, self).__init__()
        from yandex_spell import checkText
        self.checkText = checkText
        self.cache = {} # sentence => correction

    def correct(self, sentence, position):
        text = ' '.join(sentence)
        if text not in self.cache:
            spellResult = self.checkText(text)
            changes = {}
            fixedSent = sentence[:]
            for res in spellResult:
                if res['s']:
                    changes[res['word']] = res['s'][0].lower()
            fixedText = text[:]
            for word, suggestion in changes.items():
                for i in range(len(fixedSent)):
                    if sentence[i] == word:
                        fixedSent[i] = suggestion
            self.cache[text] = fixedSent
        fixedSentence = self.cache[text]
        return fixedSentence[position]

class BingSpellerCorrector(Corrector):
    def __init__(self):
        super(BingSpellerCorrector, self).__init__()
        from bing_spell import fixText
        self.fixText = fixText
        self.cache = {} # sentence => correction

    def correct(self, sentence, position):
        text = ' '.join(sentence)
        if text not in self.cache:
            fixedText = self.fixText(text)
            # if fixedText != text:
            #     print("original: ", text)
            #     print("fixed: ", fixedText)
            self.cache[text] = fixedText.split(' ')
        fixedSentence = self.cache[text]
        return fixedSentence[position]


def getRequiredSentences(sentences, maxWords):
    if maxWords == None:
        return len(sentences)
    res = 0
    n = 0
    for e in sentences:
        n += len(e)
        res += 1
        if n > maxWords:
            break
    return res

def evaluateCorrectorErrors(correctorName, corrector, originalSentences, erroredSentences, maxWords=None):

    orig = []
    pred = []
    fp = 0
    fn = 0
    total = 0

    n = 0
    for sentID in tqdm.tqdm(range(getRequiredSentences(originalSentences, maxWords))):
        originalText = originalSentences[sentID]
        erroredText = erroredSentences[sentID]
        for pos in range(len(originalText)):
            erroredWord = erroredText[pos]
            originalWord = originalText[pos]
            realError = erroredWord != originalWord
            hasError = corrector.hasError(erroredText, pos)
            total += 1

            if realError != hasError:
                if realError:
                    # print('false negative:')
                    fn += 1
                else:
                    # print('false positive:')
                    fp += 1
                # print('orig word:', originalWord)
                # print('errored word:', erroredWord)
                # print('original sentence:', u' '.join(originalText))
                # print('errored text:', u' '.join(erroredText))
                # print()

            orig.append(realError)
            pred.append(hasError)

    return orig, pred, float(fp)/total, float(fn)/total


def evaluateCorrectorMasks(correctorName, corrector, originalSentences, erroredSentences, maxWords=None):
    total = 0
    top1correct = 0
    top5correct = 0
    top20correct = 0

    for sentID in tqdm.tqdm(range(getRequiredSentences(originalSentences, maxWords))):
        originalText = originalSentences[sentID]
        for pos in range(len(originalText)):
            originalWord = originalText[pos]
            predictedWords = corrector.getMaskedWords(originalText, pos, 20)
            total += 1

            if predictedWords and originalWord == predictedWords[0]:
                top1correct += 1
            if originalWord in predictedWords[:5]:
                top5correct += 1
            if originalWord in predictedWords[:20]:
                top20correct += 1

    return float(top1correct) / float(total), float(top5correct) / float(total), float(top20correct) / float(total)

class WordIteratorItem(object):
    def __init__(self, originalWord, erroredWord, originalText,
                 erroredText, newErroredText, pos, newPos, baseErr
             ):
        self.originalWord = originalWord
        self.erroredWord = erroredWord
        self.originalText = originalText
        self.erroredText = erroredText
        self.newErroredText = newErroredText
        self.pos = pos
        self.newPos = newPos
        self.baseErr = baseErr


def wordItertator(originalSentences, erroredSentences, maxWords=None):
    lastTime = time.time()

    pbar = None
    if maxWords is None:
        pbar = tqdm.tqdm(total=len(originalSentences))
    else:
        pbar = tqdm.tqdm(total=maxWords)

    n = 0

    for sentID in range(len(originalSentences)):
        originalText = originalSentences[sentID]
        erroredText = erroredSentences[sentID]
        baseErr = erroredText[:]
        assert len(originalText) == len(erroredText)

        if maxWords is None:
            pbar.update()

        for pos in range(len(originalText)):
            erroredWord = erroredText[pos]
            if erroredWord == '+':
                continue
            originalWord = originalText[pos]
            newErroredText = [w for w in erroredText if w != '+']
            newPos = 0
            for i in range(pos):
                if erroredText[i] == '+':
                    continue
                newPos += 1

            if pos < len(originalText)-1 and erroredText[pos+1] == '+':
                originalWord = originalWord + ' ' + originalText[pos + 1]

            yield WordIteratorItem(
                originalWord, erroredWord, originalText,
                erroredText, newErroredText, pos, newPos, baseErr
            )

            n += 1
            if maxWords is not None:
                pbar.update()

            if maxWords is not None and n >= maxWords:
                break

        if maxWords is not None and n >= maxWords:
            break


def evaluateCorrector(correctorName, corrector, originalSentences, erroredSentences, maxWords=None):
    totalErrors = 0
    origErrors = 0
    fixedErrors = 0
    broken = 0
    totalNotTouched = 0
    topNtotalErrors = 0
    topNfixed = 0

    erroredSentences = copy.deepcopy(erroredSentences)

    startTime = time.time()
    n = 0

    tp = 0.0
    tn = 0.0
    fp = 0.0
    fn = 0.0

    for item in wordItertator(originalSentences, erroredSentences, maxWords):

        fixedCandidates = corrector.correct(item.newErroredText, item.newPos)
        if isinstance(fixedCandidates, list):
            fixedCandidates = fixedCandidates #[:7]
            fixedWord = fixedCandidates[0]
            fixedWords = fixedCandidates[:]
        else:
            fixedWord = fixedCandidates
            fixedWords = [fixedCandidates]


        fixedWord = fixedWord.split()
        if not fixedWord:
            fixedWord = ['']

        item.erroredText[item.pos] = fixedWord[0]
        if len(fixedWord) == 2:
            item.erroredText[item.pos] = fixedWord[0]
            if item.pos < len(item.erroredText)-1 and item.erroredText[item.pos+1] == '':
                item.erroredText[item.pos+1] = fixedWord[1]

        fixedWord = fixedWord[0]

        #if erroredWord == '':
        #if len(erroredWord) > 1.5 * len(originalWord) and len(originalWord) > 5:

        # if item.originalWord != fixedWord:
        #     print(u'correct is: %s. Errored %s was fixed to %s:' % (item.originalWord, item.erroredWord, fixedWord))
        #     print(u'err text: ' + u' '.join(item.baseErr))
        #     print(u'fix text: ' + u' '.join(item.erroredText[:item.pos + 1]))
        #     print(u'new errt: ' + u' '.join(item.newErroredText[:item.newPos + 1]))
        #     print(u'org text: ' + u' '.join(item.originalText))
        #     #print(u' '.join(fixedWords))
        #     print('\n')

        n += 1

        if item.erroredWord != item.originalWord:
            if fixedWord == item.originalWord:
                tp += 1
            else:
                fn += 1

        if item.erroredWord == item.originalWord:
            if fixedWord == item.erroredWord:
                tn += 1
            else:
                fp += 1

        if item.erroredWord != item.originalWord:
            origErrors += 1
            if fixedWord == item.originalWord:
                fixedErrors += 1
            if item.originalWord in fixedCandidates:
                topNfixed += 1
        else:
            totalNotTouched += 1
            if fixedWord != item.originalWord:
                broken += 1
                # print originalWord, fixedWord

        if fixedWord != item.originalWord:
            totalErrors += 1

        if item.originalWord not in fixedWords:
            topNtotalErrors += 1


    recall = tp / (tp + fn)
    precision = tp / (tp + fp)
    f1 = 2.0 * (precision * recall) / (precision + recall)

    return float(totalErrors) / n, \
           float(fixedErrors) / origErrors, \
           float(broken) / totalNotTouched, \
           float(topNtotalErrors) / n, \
           float(topNfixed) / origErrors, \
           time.time() - startTime, \
           (precision, recall, f1)


def genFeatures(featuresFile, corrector, originalSentences, erroredSentences, maxWords=None):

    erroredSentences = copy.deepcopy(erroredSentences)

    n = 0
    pairID = 0
    features = []

    goodCases = 0


    for item in wordItertator(originalSentences, erroredSentences, maxWords):
        if item.originalWord == item.erroredWord:
            goodCases += 1
            if goodCases % 5 != 0:  # we don't need many good cases
                continue

        candidates = corrector.getFeatures(item.newErroredText, item.newPos)
        n += 1

        origCand = None
        otherCands = []
        for c in candidates:
            if c[0] == item.originalWord:
                origCand = c
            else:
                otherCands.append(c)
        if origCand is None:
            continue

        for c in otherCands:
            features.append([1, origCand[0], pairID] + list(origCand[1]))
            features.append([0, c[0], pairID] + list(c[1]))


    with codecs.open(featuresFile, 'w', encoding='utf-8') as f:
        for feature in features:
            f.write(u';'.join(map(str,feature)) + u"\n")


def genFeaturesError(featuresFile, corrector, originalSentences, erroredSentences, maxWords=None):

    erroredSentences = copy.deepcopy(erroredSentences)

    features = []

    for item in wordItertator(originalSentences, erroredSentences, maxWords):
        currFeatures = corrector.scoreFeatures(item.newErroredText, item.newPos)
        features.append([int(item.originalWord != item.erroredWord)] + list(currFeatures))

    with codecs.open(featuresFile, 'w', encoding='utf-8') as f:
        for feature in features:
            f.write(u';'.join(map(str,feature)) + u"\n")


def genFeaturesShort(featuresFile, corrector, originalSentences, erroredSentences, maxWords=None):

    erroredSentences = copy.deepcopy(erroredSentences)

    features = []
    n = 0

    for item in wordItertator(originalSentences, erroredSentences, maxWords):
        n += 1
        if item.originalWord == item.erroredWord and n % 10 != 0:
            continue

        currFeatures = corrector.getFeaturesShort(item.newErroredText, item.newPos, item.originalWord)
        if currFeatures is None:
            continue
        features.append(currFeatures)


    with codecs.open(featuresFile, 'w', encoding='utf-8') as f:
        for feature in features:
            f.write(u';'.join(map(str,feature)) + u"\n")


def testMode(corrector):
    while True:
        sentence = input(">> ").lower().strip()
        sentence = normalize(sentence).split()
        if not sentence:
            continue
        newSentence = []
        for i in range(len(sentence)):
            fix = corrector.correct(sentence, i)
            if isinstance(fix, list):
                fix = fix[0]
            newSentence.append(fix)
        print(' '.join(newSentence))


def evaluateJamspell(modelFile, testText, alphabetFile, maxWords=50000):
    utils.loadAlphabet(alphabetFile)
    corrector = JamspellCorrector(modelFile)
    random.seed(42)
    originalText = loadText(testText)
    erroredText = generateTypos(originalText)
    assert len(originalText) == len(erroredText)
    originalSentences = generateSentences(originalText)
    erroredSentences = generateSentences(erroredText)
    return evaluateChecker({'jamspell': corrector}, originalSentences, erroredSentences, maxWords)


def evaluateChecker(correctors, originalSentences, erroredSentences, maxWords):
    results = {}
    singleResults = None

    for correctorName, corrector in correctors.items():
        errorsRate, fixRate, broken, topNerr, topNfix, execTime, metrics = \
            evaluateCorrector(correctorName, corrector, originalSentences, erroredSentences, maxWords)
        singleResults = results[correctorName] = errorsRate, fixRate, broken, topNerr, topNfix, execTime, metrics

    print('')

    print(
        '[info] %12s %8s  %8s  %8s  %8s  %8s  %8s  %8s  %8s  %8s' %
        ('', 'errRate', 'fixRate', 'broken', 'topNerr', 'topNfix', 'pr', 're', 'f1', 'time'))
    for k, _ in sorted(results.items(), key=lambda x: x[1]):
        print('[info] %10s  %8.2f%% %8.2f%% %8.2f%% %8.2f%% %8.2f%% %8.2f%% %8.2f%% %8.2f%% %8.2fs' % \
              (k,
               100.0 * results[k][0],
               100.0 * results[k][1],
               100.0 * results[k][2],
               100.0 * results[k][3],
               100.0 * results[k][4],
               100.0 * results[k][6][0],
               100.0 * results[k][6][1],
               100.0 * results[k][6][2],
               results[k][5]))
    return singleResults


def evaluateErrors(correctors, originalSentences, erroredSentences, maxWords):
    results = {}

    for correctorName, corrector in correctors.items():
        orig, pred, fp, fn = \
            evaluateCorrectorErrors(correctorName, corrector, originalSentences, erroredSentences, maxWords)
        results[correctorName] = (orig, pred, fp, fn)

    print('')

    for k, _ in sorted(results.items(), key=lambda x: x[1]):
        orig, pred, fp, fn = results[k]
        print("                    <<<< " + k + ' >>>>    ')
        print(classification_report(orig, pred))
        print("false positive: ", 100.0 * fp)
        print("false negative: ", 100.0 * fn)
        print("")


def evaluateMask(correctors, originalSentences, erroredSentences, maxWords):
    results = {}

    for correctorName, corrector in correctors.items():
        top1acc, top5acc, top20acc = evaluateCorrectorMasks(correctorName, corrector, originalSentences, erroredSentences, maxWords)
        results[correctorName] = (top1acc, top5acc, top20acc)

    print('')

    for k, _ in sorted(results.items(), key=lambda x: x[1]):
        top1acc, top5acc, top20acc = results[k]
        print("                    <<<< " + k + ' >>>>    ')
        print("top1 accuracy:  ", 100.0 * top1acc)
        print("top5 accuracy:  ", 100.0 * top5acc)
        print("top20 accuracy: ", 100.0 * top20acc)
        print("")


def generateRankFeatures(modelDir, inputBase, featuresFile, maxWords, inputExt, inputExtErrors):
    corrector = JamspellCorrector(modelDir)
    random.seed(42)
    originalSentences, erroredSentences, _ = getSentences(inputBase, inputExt, inputExtErrors)
    assert len(originalSentences) == len(erroredSentences)
    print('[info] generating rank features')
    genFeatures(featuresFile, corrector, originalSentences, erroredSentences, maxWords)


def generateErrorFeatures(modelDir, inputBase, featuresFile, maxWords, inputExt, inputExtErrors):
    corrector = JamspellCorrector(modelDir)
    random.seed(42)
    print('[info] loading text')
    originalSentences, erroredSentences, _ = getSentences(inputBase, inputExt, inputExtErrors)
    assert len(originalSentences) == len(erroredSentences)

    print('[info] generating error features')
    genFeaturesError(featuresFile, corrector, originalSentences, erroredSentences, maxWords)


def generateShortFeatures(modelDir, inputBase, featuresFile, maxWords, inputExt, inputExtErrors):
    corrector = JamspellCorrector(modelDir)
    random.seed(42)
    print('[info] loading text')
    originalSentences, erroredSentences, _ = getSentences(inputBase, inputExt, inputExtErrors)

    assert len(originalSentences) == len(erroredSentences)

    print('[info] generating short features')
    genFeaturesShort(featuresFile, corrector, originalSentences, erroredSentences, maxWords)

def mapSentences(originalLines, erroredLines):
    origSentences = []
    errSentences = []

    total = 0
    matched = 0

    for i in range(0, len(originalLines)):
        originalLine = originalLines[i]
        erroredLine = erroredLines[i]

        newErroredSentence = []
        origWords = [w for w in originalLine.split() if w and w != '.']
        erroredWords = [w for w in erroredLine.split() if w and w != '.']

        j = 0
        i = 0

        while i < len(origWords):
            # no error
            if j < len(erroredWords) and origWords[i] == erroredWords[j]:
                newErroredSentence.append(erroredWords[j])
                j += 1
                i += 1
                continue

            # case A - typo
            if j < len(erroredWords) and i == len(origWords) - 1:
                newErroredSentence.append(erroredWords[j])
                j += 1
                i += 1
                continue

            if i < len(origWords) - 1 and j < len(erroredWords) - 1 and origWords[i+1] == erroredWords[j+1]:
                newErroredSentence.append(erroredWords[j])
                j += 1
                i += 1
                continue

            if i < len(origWords) - 2 and j < len(erroredWords) - 2 and origWords[i+2] == erroredWords[j + 2]:
                newErroredSentence.append(erroredWords[j])
                j += 1
                i += 1
                continue

            # case B - split
            if i < len(origWords) - 2 and j < len(erroredWords) - 1 and origWords[i+2] == erroredWords[j+1]:
                newErroredSentence.append(erroredWords[j])
                newErroredSentence.append('+')
                j += 1
                i += 2
                continue

            break

        currMatched = i == len(origWords) and j == len(erroredWords)

        # print('orig words:', ';'.join(origWords))
        # print('err words:', ';'.join(erroredWords))
        # print('new sent:', ';'.join(newErroredSentence))
        # print("matched:", currMatched)
        # print()
        total += 1
        if currMatched:
            origSentences.append(origWords)
            errSentences.append(newErroredSentence)
            matched += 1
    print("mapped", matched, "of", total, '-', 100.0 * matched / total, "% sentences)")

    assert len(origSentences) == len(errSentences)
    return origSentences, errSentences


def getSentences(datasetBase, datasetExt, datasetExtErrors):
    originalText = []
    sentences = []
    erroredSentences = []

    if datasetExt is not None:
        print('[info] loading existing errors dataset')
        originalLines = loadLines(datasetExt)
        originalText += loadText(datasetExt)
        erroredLines = loadLines(datasetExtErrors)

        extSentences, extSentencesErrors = mapSentences(originalLines, erroredLines)
        assert len(extSentences) == len(extSentencesErrors)
        
        sentences += extSentences
        erroredSentences += extSentencesErrors

    if datasetBase is not None:
        originalText += loadText(datasetBase)
        originalTextLen = len(list(originalText))

        print('[info] generating typos')
        erroredText = generateTypos(originalText)
        erroredTextLen = len(list(erroredText))

        assert originalTextLen == erroredTextLen

        sentencesBase = generateSentences(originalText)
        erroredSentencesBase = generateSentences(erroredText)

        assert len(sentencesBase) == len(erroredSentencesBase)
        sentences += sentencesBase
        erroredSentences += erroredSentencesBase

    return sentences, erroredSentences, originalText


def main():
    parser = argparse.ArgumentParser(description='spelling correctors evaluation')
    parser.add_argument('file', type=str, help='text file to use for evaluation')
    parser.add_argument('-hs', '--hunspell', type=str, help='path to hunspell model')
    parser.add_argument('-ns', '--norvig', type=str, help='path to train file for Norvig spell corrector')
    parser.add_argument('-cs', '--context', type=str, help='path to context spell model')
    parser.add_argument('-csp', '--context_prototype', type=str, help='path to context spell prototype model')
    parser.add_argument('-ya', '--yandex', action='store_true', help='yandex speller')
    parser.add_argument('-bng', '--bing', action='store_true', help='bing spell checker')
    parser.add_argument('-jsp', '--jamspell', type=str, help='path to jamspell model file')
    parser.add_argument('-jso', '--jamspell_old', type=str, help='path to old jamspell model file')
    parser.add_argument('-nnc', '--neural_corrector', action='store_true', help='lstm corrector')
    parser.add_argument('-brt', '--bert_corrector', action='store_true', help='bert corrector')
    parser.add_argument('-t', '--test', action="store_true")
    parser.add_argument('-mx', '--max_words', type=int, help='max words to evaluate')
    parser.add_argument('-a', '--alphabet', type=str, help='alphabet file')
    parser.add_argument('-e', '--error', action='store_true', help='evaluate errors')
    parser.add_argument('-m', '--mask', action='store_true', help='evaluate masked word prediction')
    parser.add_argument('-fe', '--features', type=str, help='generate features path')
    parser.add_argument('-fer', '--features_error', type=str, help='generate error prediction features path')
    parser.add_argument('-fes', '--features_short', type=str, help='check if candidate exists among first edits')
    parser.add_argument('-rev', '--ru_eval', type=str, help='take error corpus from existing dataset')
    args = parser.parse_args()

    if args.alphabet:
        utils.loadAlphabet(args.alphabet)

    correctors = {
        #'dummy': DummyCorrector(),
    }
    # corrector = correctors['dummy']

    maxWords = args.max_words

    print('[info] loading models')

    if args.hunspell:
        corrector = correctors['hunspell'] = HunspellCorrector(args.hunspell)

    if args.norvig:
        corrector = correctors['norvig'] = NorvigCorrector(args.norvig)

    if args.context:
        corrector = correctors['context'] = ContextCorrector(args.context)

    if args.context_prototype:
        corrector = correctors['prototype'] = ContextPrototypeCorrector(args.context_prototype)

    if args.jamspell:
        corrector = correctors['jamspell'] = JamspellCorrector(args.jamspell)

    if args.jamspell_old:
        corrector = correctors['jamspell_old'] = JamspellOldCorrector(args.jamspell_old)

    if args.bert_corrector:
        corrector = correctors['bert'] = BertCorrector()

    if args.yandex:
        corrector = correctors['yandex'] = YaSpellerCorrector()

    if args.bing:
        corrector = correctors['bing'] = BingSpellerCorrector()

    if args.neural_corrector:
        corrector = correctors['neural'] = NeuralCorrector()

    if args.test:
        return testMode(corrector)

    random.seed(42)
    print('[info] loading text')

    datasetCorrectFile = args.file
    datasetErrorsFile = args.ru_eval or None

    if datasetErrorsFile is not None:
        originalSentences, erroredSentences, originalText = getSentences(None, datasetCorrectFile, datasetErrorsFile)
    else:
        originalSentences, erroredSentences, originalText = getSentences(datasetCorrectFile, None, None)

    assert len(originalSentences) == len(erroredSentences)

    # for s in originalSentences[:50]:
    #    print ' '.join(s) + '.'

    print('[info] total words: %d' % len(originalText))
    print('[info] evaluating')

    if args.features_short:
        genFeaturesShort(args.features_short, corrector, originalSentences, erroredSentences, maxWords)
    elif args.features_error:
        genFeaturesError(args.features_error, corrector, originalSentences, erroredSentences, maxWords)
    elif args.features:
        genFeatures(args.features, corrector, originalSentences, erroredSentences, maxWords)
    elif args.mask:
        evaluateMask(correctors, originalSentences, erroredSentences, maxWords)
    elif args.error:
        evaluateErrors(correctors, originalSentences, erroredSentences, maxWords)
    else:
        evaluateChecker(correctors, originalSentences, erroredSentences, maxWords)


if __name__ == '__main__':
    main()
