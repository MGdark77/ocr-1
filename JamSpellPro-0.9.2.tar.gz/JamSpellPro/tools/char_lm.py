import pickle
import zlib
import math
import sys
import tqdm
from collections import defaultdict
import utils


class CharLangModel(object):

    def __init__(self):
        self.grams = defaultdict(int)

    def fit(self, words):
        for word in words:
            for l in word:
                self.grams[l] += 1
            for i in range(0, len(word) - 1):
                k = word[i:i+2]
                self.grams[k] += 1
            for i in range(0, len(word) - 2):
                k = word[i:i+3]
                self.grams[k] += 1
            for i in range(0, len(word) - 3):
                k = word[i:i+4]
                self.grams[k] += 1

    def predict(self, word):
        if len(word) == 0:
            return 0.0

        grams1 = 1.0
        for l in word:
            grams1 += (self.grams.get(l, 0)+1)
        grams1 /= len(word)

        grams2 = 1.0
        if len(word) >= 2:
            for i in range(0, len(word) - 1):
                k = word[i:i + 2]
                grams2 += (self.grams.get(k, 0.0)+1)
            grams2 /= (len(word)-1)

        grams3 = 1.0
        if len(word) >= 3:
            for i in range(0, len(word) - 2):
                k = word[i:i + 3]
                grams3 += (self.grams.get(k, 0.0)+1)
            grams3 /= (len(word)-2)

        grams4 = 1.0
        if len(word) >= 4:
            for i in range(0, len(word) - 3):
                k = word[i:i + 4]
                grams4 += (self.grams.get(k, 0.0)+1)
            grams4 /= (len(word)-3)

        return math.log(grams1) + math.log(grams2) + math.log(grams3) + math.log(grams4)

    def save(self, path):
        data = zlib.compress(pickle.dumps(self.grams))
        with open(path, 'wb') as f:
            f.write(data)

    def load(self, path):
        with open(path, 'rb') as f:
            self.grams = pickle.loads(zlib.decompress(f.read()))


def train(srcData, dstModel):
    text = utils.loadText(srcData)
    sentences = utils.generateSentences(text)
    words = []
    for sentence in tqdm.tqdm(sentences):
        for word in sentence:
            words.append(word)

    model = CharLangModel()
    model.fit(words)
    model.save(dstModel)


def predict(modelPath):
    model = CharLangModel()
    model.load(modelPath)
    while True:
        word = input('>> ')
        print(model.predict(word))


def main():
    if sys.argv[1] == 'train':
        train(sys.argv[2], sys.argv[3])
    if sys.argv[1] == 'predict':
        predict(sys.argv[2])

if __name__ == '__main__':
    main()
