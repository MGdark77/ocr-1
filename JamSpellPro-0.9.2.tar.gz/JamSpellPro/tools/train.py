#!/usr/bin/env python3

from pathlib import Path
import os
import argparse
import codecs
import tqdm
import shutil
from copy import deepcopy
from catboost import CatBoost, Pool, CatBoostError, CatBoostClassifier
from catboost.utils import get_gpu_device_count
from generate_dataset import generateDatasetTxt
from sklearn.metrics import classification_report
import evaluate
import jamspellpro
import utils
import random


def generateDataset(tmpDir, datasetPath, maxBytes):
    if os.path.exists(os.path.join(tmpDir, 'dataset_created')):
        return
    print('[info] generating dataset')
    generateDatasetTxt(datasetPath, os.path.join(tmpDir, 'dataset'), maxBytes)
    with open(os.path.join(tmpDir, 'dataset_created'), 'wt') as f:
        f.write('\n')


def calculateFrequencies(tmpDir, modelDir, alphabetFile, grams=None):
    if os.path.exists(os.path.join(tmpDir, 'frequencies_created')):
        return
    print('[info] calculating frequenceis')
    spellChecker = jamspellpro.TSpellCorrector()
    if not grams:
        grams = ''
    assert spellChecker.TrainLangModel(os.path.join(tmpDir, 'dataset_train.txt'), alphabetFile, modelDir, tmpDir, grams)
    with open(os.path.join(tmpDir, 'frequencies_created'), 'wt') as f:
        f.write('\n')


class DatasetPaths(object):
    def __init__(self, tmpDir):
        self.trainDatasetBase = os.path.join(tmpDir, 'dataset_validate.txt')
        self.testDatasetBase = os.path.join(tmpDir, 'dataset_test.txt')
        self.trainDatasetExt = None
        self.testDatasetExt = None
        self.trainDatasetExtErrors = None
        self.testDatasetErrorsExt = None

        if os.path.exists(os.path.join(tmpDir, 'meta_train_error.txt')):
            self.trainDatasetExt = os.path.join(tmpDir, 'meta_train_correct.txt')
            self.trainDatasetExtErrors = os.path.join(tmpDir, 'meta_train_error.txt')
            self.testDatasetExt = os.path.join(tmpDir, 'meta_test_correct.txt')
            self.testDatasetErrorsExt = os.path.join(tmpDir, 'meta_test_error.txt')


def generateRankFeatures(tmpDir, modelDir):
    if os.path.exists(os.path.join(tmpDir, 'rank_features_created')):
        return
    print('[info] generating rank features')

    dataset = DatasetPaths(tmpDir)

    evaluate.generateRankFeatures(
        modelDir,
        dataset.trainDatasetBase,
        os.path.join(tmpDir, 'features_rank_train.txt'),
        70000,
        dataset.trainDatasetExt,
        dataset.trainDatasetExtErrors
    )
    evaluate.generateRankFeatures(
        modelDir,
        dataset.testDatasetBase,
        os.path.join(tmpDir, 'features_rank_test.txt'),
        20000,
        dataset.testDatasetExt,
        dataset.testDatasetErrorsExt
    )
    with open(os.path.join(tmpDir, 'rank_features_created'), 'wt') as f:
        f.write('\n')

def generateErrorFeatures(tmpDir, modelDir):
    if os.path.exists(os.path.join(tmpDir, 'error_features_created')):
        return

    print('[info] generating error features')

    dataset = DatasetPaths(tmpDir)

    evaluate.generateErrorFeatures(
        modelDir,
        dataset.trainDatasetBase,
        os.path.join(tmpDir, 'features_error_train.txt'),
        70000,
        dataset.trainDatasetExt,
        dataset.trainDatasetExtErrors
    )
    evaluate.generateErrorFeatures(
        modelDir,
        dataset.testDatasetBase,
        os.path.join(tmpDir, 'features_error_test.txt'),
        20000,
        dataset.testDatasetExt,
        dataset.testDatasetErrorsExt
    )
    with open(os.path.join(tmpDir, 'error_features_created'), 'wt') as f:
        f.write('\n')

def generateShortFeatures(tmpDir, modelDir):
    if os.path.exists(os.path.join(tmpDir, 'short_features_created')):
        return

    print('[info] generating short features')

    dataset = DatasetPaths(tmpDir)

    evaluate.generateShortFeatures(
        modelDir,
        dataset.trainDatasetBase,
        os.path.join(tmpDir, 'features_short_train.txt'),
        70000,
        dataset.trainDatasetExt,
        dataset.trainDatasetExtErrors
    )
    evaluate.generateShortFeatures(
        modelDir,
        dataset.testDatasetBase,
        os.path.join(tmpDir, 'features_short_test.txt'),
        20000,
        dataset.testDatasetExt,
        dataset.testDatasetErrorsExt
    )
    with open(os.path.join(tmpDir, 'short_features_created'), 'wt') as f:
        f.write('\n')


def loadRankDataset(fileName):
    data = []
    with codecs.open(fileName, 'r', encoding='utf-8') as f:
        for line in tqdm.tqdm(f):
            line = line.split(';')
            line = ['0' if v.startswith('False') else v for v in line]
            line = [int(line[0]), line[1]] + list(map(float, line[3:]))
            data.append(line)
    return data

def getRankEvalPool(testX, testPairs):
    groupIDs = []
    for i in range(0, len(testX) // 2):
        groupIDs.append(i + 1)
        groupIDs.append(i + 1)
    while len(groupIDs) < len(testX):
        groupIDs.append(0)

    eval_pool = Pool(
        data=testX, pairs=testPairs, group_id=groupIDs
    )
    return eval_pool

def trainRankModel(tmpDir, modelDir):
    if os.path.exists(os.path.join(tmpDir, 'rank_model_created')):
        return
    print('[info] training rank model')

    trainFile = os.path.join(tmpDir, 'features_rank_train.txt')
    testFile = os.path.join(tmpDir, 'features_rank_test.txt')
    modelPath = os.path.join(modelDir, 'catboost_rank.bin')

    params = {
        'loss_function': 'PairLogitPairwise',
        'iterations': 400,
        'learning_rate': 0.1,
        'depth': 8,
        'verbose': False,
        'random_seed': 42,
        'early_stopping_rounds': 50,
        'border_count': 64,

        'leaf_estimation_backtracking': 'AnyImprovement',
        'leaf_estimation_iterations': 2,
        'leaf_estimation_method': 'Newton',

        'task_type': 'GPU'
    }

    print('[info] loading dataset')
    trainData = loadRankDataset(trainFile)
    testData = loadRankDataset(testFile)


    testX = [x[2:] for x in testData]
    testY = [x[0] for x in testData]

    trainX = [x[2:] for x in trainData]
    trainY = [x[0] for x in trainData]

    trainPairs = []
    for i in range(0, len(trainY) // 2):
        idx1 = i * 2
        idx2 = i * 2 + 1
        if trainY[idx2]:
            idx1, idx2 = idx2, idx2
        trainPairs.append((idx1, idx2))

    testPairs = []
    for i in range(0, len(testY) // 2):
        idx1 = i * 2
        idx2 = i * 2 + 1
        if testY[idx2]:
            idx1, idx2 = idx2, idx2
        testPairs.append((idx1, idx2))

    evalPool = getRankEvalPool(testX, testPairs)

    groupIDs = []
    for i in range(0, len(trainX) // 2):
        groupIDs.append(i + 1)
        groupIDs.append(i + 1)
    while len(groupIDs) < len(trainX):
        groupIDs.append(0)

    print('[info] training catboost rank model, dataset size:', len(groupIDs))

    model = CatBoost(params, )
    # try:
    #     model.fit(trainX, trainY, pairs=trainPairs, group_id=groupIDs, eval_set=evalPool, verbose=1)
    # except CatBoostError:
    #     print('[warning] gpu is not available (required nvidia + cuda), rollback to cpu')
    #     print('[warning] (slower training time)')
    params['task_type'] = 'CPU'
    params['loss_function'] = 'PairLogit'
    model = CatBoost(params, )
    model.fit(trainX, trainY, pairs=trainPairs, group_id=groupIDs, eval_set=evalPool, verbose=1)

    #print(model.get_all_params())

    predY = model.predict(testX)
    total = 0.0
    correct = 0.0
    for i in range(0, len(testX) // 2):
        idx1 = i * 2
        idx2 = i * 2 + 1
        if testX[idx1][-2] != testX[idx2][-2]:
            continue
        real = testY[idx1] > testY[idx2]
        pred = predY[idx1] > predY[idx2]
        total += 1
        if real == pred:
            correct += 1

    print("[info] same edit distance samples:", total)
    print("[info] same edit distance accuracy:", 100.0 * correct / total)

    model.save_model(modelPath)

    with open(os.path.join(tmpDir, 'rank_model_created'), 'wt') as f:
        f.write('\n')


def loadErrorFeatures(fname):
    X = []
    y = []
    with open(fname, 'r') as f:
        data = f.read().split('\n')
        for line in data:
            if not line:
                continue
            line = line.split(';')
            y.append(int(line[0]))
            X.append(list(map(float, line[1:])))
    return X, y


def trainErrorModel(tmpDir, modelDir):

    if os.path.exists(os.path.join(tmpDir, 'error_model_created')):
        return

    print('[info] training error model')

    trainFile = os.path.join(tmpDir, 'features_error_train.txt')
    testFile = os.path.join(tmpDir, 'features_error_test.txt')
    modelPath = os.path.join(modelDir, 'catboost_error.bin')

    trainX, trainY = loadErrorFeatures(trainFile)
    testX, testY = loadErrorFeatures(testFile)

    currentWeight = 300.0
    attempt = 1
    while True:
        print('[info] attempt', attempt, 'weight', currentWeight)

        trainWeight = [w * currentWeight + 1.0 for w in trainY]

        model = CatBoostClassifier(
            iterations=400,
            learning_rate=0.3,
            depth=8
        )

        model.fit(trainX, trainY, sample_weight=trainWeight, verbose=False)

        predict = model.predict(testX)
        #print('[info] error model classification report')
        #print(classification_report(testY, predict))
        total = 0
        correct = 0
        for i in range(0, len(testY)):
            if testY[i]:
                total += 1
                if predict[i]:
                    correct += 1
        detectedErrors = 100.0 * correct / total
        print("[info] detected errors:", detectedErrors)
        if detectedErrors > 98.0 or currentWeight > 1000:
            break
        currentWeight += 100.0
        attempt += 1

    model.save_model(modelPath)

    with open(os.path.join(tmpDir, 'error_model_created'), 'wt') as f:
        f.write('\n')


def trainShortModel(tmpDir, modelDir):

    if os.path.exists(os.path.join(tmpDir, 'short_model_created')):
        return

    print('[info] training error model')

    trainFile = os.path.join(tmpDir, 'features_short_train.txt')
    testFile = os.path.join(tmpDir, 'features_short_test.txt')
    modelPath = os.path.join(modelDir, 'catboost_short.bin')

    trainX, trainY = loadErrorFeatures(trainFile)
    testX, testY = loadErrorFeatures(testFile)
    print('sum', sum(trainY), sum(testY))

    currentWeight = 100.0
    attempt = 1
    while True:
        print('[info] attempt', attempt, 'weight', currentWeight)

        trainWeight = [(1-w)*currentWeight+1.0 for w in trainY]

        model = CatBoostClassifier(
            iterations=200,
            learning_rate=0.3,
            depth=8
        )

        model.fit(trainX, trainY, sample_weight=trainWeight, verbose=False)

        predict = model.predict(testX)
        # print('[info] error model classification report')
        # print(classification_report(testY, predict))

        total = 0
        correct = 0
        for i in range(0, len(testY)):
            if testY[i] == 0:
                total += 1
                if predict[i] == 0:
                    correct += 1

        detectedErrors = 100.0 * correct / total
        print("[info] detected errors:", detectedErrors)
        if detectedErrors > 90.0 or currentWeight > 1000:
            break
        currentWeight += 100.0
        attempt += 1

    model.save_model(modelPath)

    with open(os.path.join(tmpDir, 'short_model_created'), 'wt') as f:
        f.write('\n')

def evaluateModel(datasetDir, modelDir, alphabetFile):
    return evaluate.evaluateJamspell(modelDir, os.path.join(datasetDir, 'dataset_test.txt'), alphabetFile, maxWords=15000)[-1][-1]


def generateMeta(tmpDir, meta):
    if not meta[0]:
        return
    if os.path.exists(os.path.join(tmpDir, 'meta_created')):
        return

    random.seed(42)
    linesCorrect = open(meta[0]).read().split('\n')
    linesError = open(meta[1]).read().split('\n')
    assert len(linesCorrect) == len(linesError)
    assert len(linesCorrect) > 0

    c = list(zip(linesCorrect, linesError))
    random.shuffle(c)
    linesCorrect, linesError = zip(*c)

    l = int(len(linesCorrect) * 0.8)
    linesCorrectTrain = linesCorrect[:l]
    linesErrorTrain = linesError[:l]
    linesCorrectTest = linesCorrect[l:]
    linesErrorTest = linesError[l:]
    with open(os.path.join(tmpDir, 'meta_train_correct.txt'), 'wt') as f:
        f.write('\n'.join(linesCorrectTrain))
    with open(os.path.join(tmpDir, 'meta_train_error.txt'), 'wt') as f:
        f.write('\n'.join(linesErrorTrain))
    with open(os.path.join(tmpDir, 'meta_test_correct.txt'), 'wt') as f:
        f.write('\n'.join(linesCorrectTest))
    with open(os.path.join(tmpDir, 'meta_test_error.txt'), 'wt') as f:
        f.write('\n'.join(linesErrorTest))

    print('[info] meta generated model')
    with open(os.path.join(tmpDir, 'meta_created'), 'wt') as f:
        f.write('\n')

def copyDict(modelDir, dictFile):
    if dictFile is None:
        return
    dstFile = os.path.join(modelDir, 'dictionary.txt')
    if os.path.exists(dstFile):
        return
    shutil.copy(dictFile, dstFile)


def trainLangModel(dataset, tmpdir, alphabet, outmodel, meta, dict, maxBytes=None, grams=None):
    assert os.path.exists(alphabet)
    assert os.path.exists(dataset)

    utils.loadAlphabet(alphabet)

    Path(tmpdir).mkdir(parents=True, exist_ok=True)
    Path(outmodel).mkdir(parents=True, exist_ok=True)

    print('[infp] stage 0.5 / 9')
    copyDict(outmodel, dict)
    print('[info] stage 1 / 9')
    generateDataset(tmpdir, dataset, maxBytes)
    print('[info] stage 1.5 / 9')
    generateMeta(tmpdir, meta)
    print('[info] stage 2 / 9')
    calculateFrequencies(tmpdir, outmodel, alphabet, grams)
    print('[info] stage 3 / 9')
    generateRankFeatures(tmpdir, outmodel)
    print('[info] stage 4 / 9')
    trainRankModel(tmpdir, outmodel)
    print('[info] stage 5 / 9')
    generateErrorFeatures(tmpdir, outmodel)
    print('[info] stage 6 / 9')
    trainErrorModel(tmpdir, outmodel)
    print('[info] stage 7 / 9')
    generateShortFeatures(tmpdir, outmodel)
    print('[info] stage 8 / 9')
    trainShortModel(tmpdir, outmodel)
    print('[info] stage 9 / 9')
    f1 = evaluateModel(tmpdir, outmodel, alphabet)
    return f1


def main():
    parser = argparse.ArgumentParser(description='train spellchecker model')
    parser.add_argument('-ds', '--dataset', type=str, help='path to source dataset - single txt file or directory', required=True)
    parser.add_argument('-gm', '--grams', type=str, help='path to raw grams counts', required=False)
    parser.add_argument('-ab', '--alphabet', type=str, help='path to file with alphabet', required=True)
    parser.add_argument('-tmp', '--tmp_dir', type=str, help='path to hunspell model', required=True)
    parser.add_argument('-m', '--model_dir', type=str, help='output model path', required=True)
    parser.add_argument('-mtc', '--meta_correct', type=str, help='output model path', required=False)
    parser.add_argument('-mte', '--meta_error', type=str, help='output model path', required=False)
    parser.add_argument('-dct', '--dict', type=str, help='dictionary file', required=False)
    parser.add_argument('-mxmb', '--max_megabytes', type=int, help='max megabytes')
    args = parser.parse_args()

    meta = ('', '')
    assert bool(args.meta_correct) == bool(args.meta_error)
    if args.meta_correct:
        meta = (args.meta_correct, args.meta_error)

    maxBytes = None
    if args.max_megabytes is not None:
        maxBytes = args.max_megabytes * 2**20

    trainLangModel(args.dataset, args.tmp_dir, args.alphabet, args.model_dir, meta, args.dict, maxBytes, args.grams)


if __name__ == '__main__':
    main()
