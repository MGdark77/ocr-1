#!/usr/bin/env python3.7

import os
import sys
import gzip
import srt
import tqdm
from langdetect import detect
import re

def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', data)

def dirFilesIterator(dirPath):
    for root, directories, filenames in os.walk(dirPath):
        for filename in filenames:
            yield os.path.join(root, filename)

def extractSentences(filePath):
    try:
        data = open(filePath, 'rb').read().decode('utf-8', errors='ignore')
        subs = data.split('\n')
    except:
        return None, None
    sentences = []
    for sub in subs:
        sentences.append(sub.split('\t')[-1])
    fullTxt = '\n'.join(sentences)
    if len(fullTxt) < 100:
        return None, None
    try:
        lng = detect(fullTxt)
    except:
        return None, None
    return sentences, lng

_g_files = {}
def getLangFile(outfile, lng):
    if lng in _g_files:
        return _g_files[lng]
    f = open(outfile + '_' + lng + '.txt', 'wt')
    _g_files[lng] = f
    return f

def main():
    dirToScan = sys.argv[1]
    outfile = sys.argv[2]
    paths = dirFilesIterator(dirToScan)
    for filePath in tqdm.tqdm(paths):
        if filePath.endswith('.txt'):
            try:
                sentences, lng = extractSentences(filePath)
            except:
                continue
            if not sentences:
                continue
            fOut = getLangFile(outfile, lng)
            for s in sentences:
                fOut.write(s + "\n")

if __name__ == '__main__':
    main()
