#!/usr/bin/env python
# -*- coding: utf-8 -*-

import codecs
import random
import os
import argparse
import xml.sax
import tqdm
from collections import defaultdict
from lang import getShortLang, getFullLang

RANDOM_SEED = 42
TRAIN_TEST_SPLIT = 0.95
TEST_VALIDATE_SPLIT = 0.5
LANG_DETECT_FRAGMENT_SIZE = 2000


def saveSentences(sentences, fname, maxbytes=None):
    bytesWritten = 0
    with codecs.open(fname, 'w', 'utf-8') as f:
        for s in sentences:
            f.write(s)
            f.write('\n')
            bytesWritten += len(s) + 1
            if maxbytes is not None and bytesWritten > maxbytes:
                break


def dirFilesIterator(dirPath):
    for root, directories, filenames in os.walk(dirPath):
        for filename in filenames:
            yield os.path.join(root, filename)


class FB2Handler(xml.sax.handler.ContentHandler):
    def __init__(self, tagsToExclude):
        xml.sax.handler.ContentHandler.__init__(self)
        self.__tagsToExclude = tagsToExclude
        self.__counters = defaultdict(int)
        self.__buff = []

    def getBuff(self):
        return ''.join(self.__buff)

    def _mayProcess(self):
        for counter in self.__counters.itervalues():
            if counter > 0:
                return False
        return True

    def startElement(self, name, attrs):
        if name in self.__tagsToExclude:
            self.__counters[name] += 1

    def endElement(self, name):
        if name in self.__tagsToExclude:
            self.__counters[name] -= 1

    def characters(self, content):
        if self._mayProcess():
            self.__buff.append(content)


class DataSource(object):
    def __init__(self, path, name, lang=None):
        self.__path = path
        self.__name = name
        self.__lang = lang

    def getPath(self):
        return self.__path

    def getName(self):
        return self.__name

    def isMatch(self, pathToFile):
        return False

    def loadSentences(self, pathToFile, sentences):
        pass

    def checkLang(self, textFragment):
        if self.__lang is None:
            return True
        from langdetect import detect
        detectedLang = detect(textFragment)
        if detectedLang != self.__lang and detectedLang != getShortLang(self.__lang):
            return False
        return True


class LeipzigDataSource(DataSource):
    def __init__(self, path, lang):
        super(LeipzigDataSource, self).__init__(path, 'leipzig', lang)

    def isMatch(self, pathToFile):
        return pathToFile.endswith('-sentences.txt')

    def loadSentences(self, pathToFile, sentences):
        with codecs.open(pathToFile, 'r', 'utf-8') as f:
            data = f.read()
            if not self.checkLang(data[:LANG_DETECT_FRAGMENT_SIZE]):
                return
            for line in data.split('\n'):
                if not line:
                    continue
                sentences.append(line.split('\t')[1].strip().lower())


class TxtDataSource(DataSource):
    def __init__(self, path, lang):
        super(TxtDataSource, self).__init__(path, 'txt', lang)

    def isMatch(self, pathToFile):
        return pathToFile.endswith('.txt') or 'wiki_' in pathToFile

    def loadSentences(self, pathToFile, sentences):
        with codecs.open(pathToFile, 'r', 'utf-8') as f:
            for line in tqdm.tqdm(f.read().split('\n')):
                line = line.strip().lower()
                if not line:
                    continue
                sentences.append(line)

class Tokenizer(object):

    def __init__(self, lang):
        import nltk
        nltk.download('punkt')
        self.lang = lang
        if lang == 'hindi':
            from indicnlp import common
            common.set_resources_path("/Users/filipp/koding/indic_nlp_resources")

            from indicnlp import loader
            loader.load()
            from indicnlp.tokenize import sentence_tokenize
            self.sentence_split = sentence_tokenize.sentence_split
        else:
            if lang == 'ukrainian':
                lang = 'russian'
            self.tokenizer = nltk.data.load('tokenizers/punkt/PY3/' + lang + '.pickle')

    def getSentences(self, data):
        data = data.replace('\n', ' ')
        data = data.replace('\r', ' ')
        if self.lang == 'hindi':
            data = self.sentence_split(data, lang='hi')
        else:
            data = self.tokenizer.tokenize(data)
        return data

class GutenbergDataSource(DataSource):

    def __init__(self, path, lang):
        super(GutenbergDataSource, self).__init__(path, 'txt', lang)
        lang = lang or 'english'
        self.lang = lang
        self.tokenizer = Tokenizer(lang)

    def isMatch(self, pathToFile):
        return pathToFile.endswith('.txt')

    def getLang(self, data):
        pos = data.find('Language: ')
        if pos == -1:
            return 'english'
        pos2 = data.find('\n', pos+1)
        lang = data[pos + len('Language: '):pos2-1]
        return lang.lower()

    def loadSentences(self, pathToFile, sentences):
        print('processing file', pathToFile)
        try:
            with codecs.open(pathToFile, 'r', 'utf-8') as f:
                data = f.read()
        except:
            return

        lang = self.getLang(data)
        if self.lang != None and self.lang != lang:
            return

        pos = data.find('START OF THIS PROJECT GUTENBERG')
        if pos == -1:
            pos = data.find('START OF THE PROJECT GUTENBERG')

        if pos == -1:
            return

        pos = data.find('***', pos+1)

        if pos == -1:
            return

        data = data[pos+4:]

        pos = data.find('End of the Project Gutenberg')
        if pos == -1:
            pos = data.find('*** END OF THIS PROJECT GUTENBERG')
        if pos == -1:
            pos = data.find('***END OF THE PROJECT GUTENBERG')

        if pos == -1:
            return

        data = data[:pos]
        data = self.tokenizer.getSentences(data)

        for line in data:
            line = line.strip().lower()
            if not line:
                continue
            sentences.append(line)


class FB2DataSource(DataSource):
    def __init__(self, path, lang):
        super(FB2DataSource, self).__init__(path, 'FB2', lang)

    def isMatch(self, pathToFile):
        return pathToFile.endswith('.fb2')

    def loadSentences(self, pathToFile, sentences):
        parser = xml.sax.make_parser()
        handler = FB2Handler(['binary'])
        parser.setContentHandler(handler)
        print('[info] loading file', pathToFile)
        with open(pathToFile, 'rb') as f:
            parser.parse(f)
        data = handler.getBuff()
        if not self.checkLang(data[:LANG_DETECT_FRAGMENT_SIZE]):
            print('[info] wrong language')
        for line in data.split('\n'):
            line = line.strip().lower()
            if not line:
                continue
            sentences.append(line)


class EPubDataSource(DataSource):
    def __init__(self, path, lang):
        super(EPubDataSource, self).__init__(path, 'EPUB', lang)
        import ebooklib
        from ebooklib import epub
        from bs4 import BeautifulSoup
        lang = lang or 'english'
        self.blacklist = [
            '[document]', 'noscript', 'header',
            'html', 'meta', 'head','input',
            'script',
        ]
        self.tokenizer = Tokenizer(lang)

    def chap2text(self, chap):
        from bs4 import BeautifulSoup
        output = ''
        soup = BeautifulSoup(chap, 'html.parser')
        text = soup.find_all(text=True)
        for t in text:
            if t.parent.name not in self.blacklist:
                output += '{} '.format(t)
        return output


    def isMatch(self, pathToFile):
        return pathToFile.lower().endswith('.epub')

    def loadSentences(self, pathToFile, sentences):
        from ebooklib import epub
        import ebooklib
        try:
            book = epub.read_epub(pathToFile)
        except Exception:
            return
        for item in book.get_items():
            if item.get_type() == ebooklib.ITEM_DOCUMENT:
                text = self.chap2text(item.get_content()).strip()
                if not text:
                    continue
                # if not self.checkLang(text):
                #     # print("wrong lang", text[:30])
                #     continue
                sentences += self.tokenizer.getSentences(text)
                # print("\nadding sentences:\n", '\n'.join(sentences[:5]))
        return


def generateDatasetTxt(inFile, outFile, maxBytes):
    source = TxtDataSource(inFile, None)
    sentences = []

    path = source.getPath()
    paths = [path] if os.path.isfile(path) else dirFilesIterator(path)
    for filePath in paths:
        if source.isMatch(filePath):
            source.loadSentences(filePath, sentences)

    assert sentences
    processSentences(sentences, outFile, maxBytes)


def processSentences(sentences, outFile, maxBytes):
    print('[info] removing duplicates')

    sentences = list(set(sentences))
    sentences = sorted(sentences)

    print('[info] %d left' % len(sentences))
    print('[info] shuffling')

    random.seed(RANDOM_SEED)
    random.shuffle(sentences)

    total = len(sentences)
    trainHalf = int(total * TRAIN_TEST_SPLIT)
    trainSentences = sentences[:trainHalf]
    testSentences = sentences[trainHalf:]
    testHalf = int(len(testSentences) * TEST_VALIDATE_SPLIT)
    validateSentences = testSentences[testHalf:]
    testSentences = testSentences[:testHalf]

    maxTrainBytes = None
    maxTestBytes = None
    if maxBytes is not None:
        maxTrainBytes = int(maxBytes * TRAIN_TEST_SPLIT)
        maxTestBytes = int(maxBytes * (1.0 - TRAIN_TEST_SPLIT))

    print('[info] saving train set')
    saveSentences(trainSentences, outFile + '_train.txt', maxTrainBytes)

    print('[info] saving test set')
    saveSentences(testSentences, outFile + '_test.txt', maxTestBytes)

    print('[info] saving validate set')
    saveSentences(validateSentences, outFile + '_validate.txt', maxTestBytes)

    print('[info] done')

class GeneratorArgs(object):
    def __init__(self):
        self.language = None
        self.split = None
        self.leipzig = None
        self.txt = None
        self.gutenberg = None
        self.fb2 = None
        self.epub = None
        self.out_file = None
        self.max_bytes = None
        self.max_sentences = None

def generateDataset(args):
    lang = None
    if args.language:
        lang = args.language
        assert len(lang) > 2

    if args.split:
        global TRAIN_TEST_SPLIT
        TRAIN_TEST_SPLIT = args.split

    dataSources = []
    if args.leipzig:
        dataSources.append(LeipzigDataSource(args.leipzig, lang))
    if args.fb2:
        dataSources.append(FB2DataSource(args.fb2, lang))
    if args.txt:
        dataSources.append(TxtDataSource(args.txt, lang))
    if args.gutenberg:
        dataSources.append(GutenbergDataSource(args.gutenberg, lang))
    if args.epub:
        dataSources.append(EPubDataSource(args.epub, lang))

    if not dataSources:
        raise Exception('specify at least single data source')

    sentences = []
    for dataSource in dataSources:
        print('[info] loading %s collection' % dataSource.getName())
        path = dataSource.getPath()
        paths = [path] if os.path.isfile(path) else dirFilesIterator(path)
        for filePath in tqdm.tqdm(paths):
            if dataSource.isMatch(filePath):
                dataSource.loadSentences(filePath, sentences)
                if args.max_sentences is not None and len(sentences) > args.max_sentences:
                    break

    print('[info] loaded %d sentences' % len(sentences))
    if not sentences:
        print('[error] no sentences loaded')
        return

    processSentences(sentences, args.out_file, args.max_bytes)


def main():
    parser = argparse.ArgumentParser(description='datset generator')
    parser.add_argument('out_file', type=str, help='will be created out_file_train and out_file_test')
    parser.add_argument('-lz', '--leipzig', type=str, help='path to file or dir with Leipzig Corpora files')
    parser.add_argument('-fb2', '--fb2', type=str, help='path to file or dir with files in FB2 format')
    parser.add_argument('-ep', '--epub', type=str, help='path to file or dir with files in epub format')
    parser.add_argument('-txt', '--txt', type=str, help='path to file or dir with utf-8 txt files')
    parser.add_argument('-gb', '--gutenberg', type=str, help='path to file or dir with gutenberg txt files')
    parser.add_argument('-lng', '--language', type=str, help='filter by content language')
    parser.add_argument('-s', '--split', type=float, help='train / test ratio, default 0.95')
    parser.add_argument('-mxb', '--max_bytes', type=int, help='max bytes')
    parser.add_argument('-mxs', '--max_sentences', type=int, help='max sentences')
    args = parser.parse_args()

    generateDataset(args)


if __name__ == '__main__':
    main()
