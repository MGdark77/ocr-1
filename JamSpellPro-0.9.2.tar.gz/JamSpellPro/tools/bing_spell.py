#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import json
import time
import sys

API_KEY = "92779b841f8840c3b47384755d9a4ecc"
ENDPOINT = "https://fippo-spellckech.cognitiveservices.azure.com/bing/v7.0/SpellCheck"

def checkText(text, lang='en-us'):
    data = {'text': text}
    params = {
        'mkt':lang,
        'mode':'proof'
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Ocp-Apim-Subscription-Key': API_KEY,
    }

    time.sleep(1.02)
    #print(ENDPOINT, params, data)
    response = requests.post(ENDPOINT, headers=headers, params=params, data=data)
    json_response = response.json()
    #print(json_response)
    return json_response

def fixText(text, lang='en-us'):
    data = checkText(text, lang)

    changes = {}
    for tok in data['flaggedTokens']:
        suggests = tok["suggestions"]
        if not suggests:
            continue
        changes[tok["token"]] = suggests[0]["suggestion"].lower()

    fixedText = text[:]
    for word, suggestion in changes.items():
        fixedText = fixedText.replace(word, suggestion)
    return fixedText


if __name__ == '__main__':
    print(fixText("the finesher medal from the 2016 chikago marathon"))
