#!/usr/bin/env python
# -*- coding: utf-8 -*-

import codecs
import tqdm
try:
    import urllib2 as urlreq # Python 2.x
    from urllib import quote as urlquote
except:
    import urllib.request as urlreq # Python 3.x
    from urllib.parse import quote as urlquote

ALPHABET = 'abcdefghijklmnopqrstuvwxyz'

def normalize(text):
    letters = []
    for l in tqdm.tqdm(text.lower()):
        if l in ALPHABET:
            letters.append(l)
        elif l in ".?!":
            letters.append(' ')
            letters.append('.')
            letters.append(' ')
        else:
            letters.append(' ')
    text = ''.join(letters)
    text = ' '.join(text.split())
    return text

def normalizeNp(text):
    letters = []
    for l in text.lower():
        if l in ALPHABET:
            letters.append(l)
        elif l in ".?!":
            letters.append(' ')
            letters.append('.')
            letters.append(' ')
        else:
            letters.append(' ')
    text = ''.join(letters)
    text = ' '.join(text.split())
    return text

#assert normalize('AsD?! d!@$%^^ ee   ') == 'asd . . d . ee'

def loadText(fname):
    with codecs.open(fname, 'r', 'utf-8') as f:
        data = f.read()
        return normalize(data).split()

def saveText(fname, words):
    with codecs.open(fname, 'w', 'utf-8') as f:
        f.write(u' '.join(words))

def loadLines(fname):
    with codecs.open(fname, 'r', 'utf-8') as f:
        data = f.read()
        sentences = data.split('\n')
        sentences = list(map(normalizeNp, sentences))
        return sentences

def loadAlphabet(fname):
    global ALPHABET
    with codecs.open(fname, 'r', 'utf-8') as f:
        data = f.read().split('\n')[0]
        data = data.strip().lower()
        ALPHABET = data

def generateSentences(words):
    sentences = []
    currSent = []
    for w in words:
        if w == '.':
            if currSent:
                sentences.append(currSent)
            currSent = []
        else:
            currSent.append(w)
    if currSent:
        sentences.append(currSent)
    newSents = []
    for s in sentences:
        newSent = []
        i = 0
        while i < len(s):
            w = s[i]
            if not w:
                i += 1
                newSent.append(w)
                continue
            if w[-1] == '+':
                w = w[:-1]
                if i < len(s) - 1:
                    w = w + s[i+1]
                    if w[-1] == '+':
                        w = w[:-1]
                    newSent.append(w)
                    newSent.append('+')
                    i += 2
                    continue

            newSent.append(w)
            i += 1
            continue

        newSents.append(newSent)
    return newSents

def fetchUrl(url):
    req = urlreq.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36')
    result = urlreq.urlopen(req).read()
    return result
