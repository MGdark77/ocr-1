
SHORT_TO_FULL = {
    'en': 'english',
    'hi': 'hindi',
    'ru': 'russian',
    'it': 'italian',
    'no': 'norwegian',
    'de': 'german',
    'fr': 'french',
    'es': 'spanish',
    'tr': 'turkish',
    'uk': 'ukrainian',
    'pl': 'polish',
    'nl': 'dutch',
    'pt': 'portuguese',
    'ur': 'urdu',
    'ar': 'arabic',
}
FULL_TO_SHORT = {v:k for k,v in SHORT_TO_FULL.items()}

def getShortLang(fullLang):
    return FULL_TO_SHORT.get(fullLang, None)

def getFullLang(shortLang):
    return SHORT_TO_FULL.get(shortLang, None)
