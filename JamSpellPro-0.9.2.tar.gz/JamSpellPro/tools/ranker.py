#!/usr/bin/env python

import codecs
from copy import deepcopy
from catboost import CatBoost


TRAIN_FILE = '/Users/filipp/koding/JamSpell/dataset/features_validate.txt'
TEST_FILE = '/Users/filipp/koding/JamSpell/dataset/features_test.txt'
MAX_LINES = 3000


DEFAULT_PARAMS = {
    'iterations': 300,
    'custom_metric': ['NDCG', 'PFound', 'AverageGain:top=10'],
    'verbose': True,
    'random_seed': 42,
}

def loadDataset(fileName):
    data = []
    with codecs.open(fileName, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.split(';')
            line = [int(line[0]), line[1]] + list(map(float, line[3:]))
            data.append(line)
            if len(data) > MAX_LINES:
                break
    return data


def main():
    trainData = loadDataset(TRAIN_FILE)
    testData = loadDataset(TEST_FILE)

    testX = [x[2:] for x in testData]
    testY = [x[0] for x in testData]

    trainX = [x[2:] for x in trainData]
    trainY = [x[0] for x in trainData]


    trainPairs = []
    for i in range(0, len(trainY)//2):
        idx1 = i * 2
        idx2 = i * 2 + 1
        if trainY[idx2]:
            idx1, idx2 = idx2, idx2
        trainPairs.append((idx1, idx2))

    parameters = deepcopy(DEFAULT_PARAMS)
    parameters['loss_function'] = 'PairLogitPairwise'
    #parameters['train_dir'] = None

    model = CatBoost(parameters)
    model.fit(trainX, trainY, pairs=trainPairs)

    predY = model.predict(testX)


    # print(trainData[0])
    # print(trainData[1])


if __name__ == '__main__':
    main()
