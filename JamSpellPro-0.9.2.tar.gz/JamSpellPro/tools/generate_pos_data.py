#!/usr/bin/env python3

import os
import argparse
import xml.sax
import tqdm
import opencorpora
import utils
import random

TRAIN_TEST_SPLIT = 0.8


def readOpenCorpusRu(filePath):
    print("[info] reading", filePath)
    tokens = []
    corpus = opencorpora.load(filePath)
    for doc in tqdm.tqdm(corpus.docs):
        for tok in doc.tokens:
            tokens.append((tok.source, tok.grammemes[0]))
    return tokens

def normData(tokens):
    print("[info] normalizing")
    resTokens = []
    for text, pos in tqdm.tqdm(tokens):
        text = utils.normalizeNp(text).strip()
        if not text:
            continue
        if len(text.split()) > 1:
            continue
        if text == '.' and pos == 'PNCT':
            pos = '.'
        resTokens.append((text, pos))
    return resTokens

def save(data, outFile):
    print("[info] saving", outFile)

    result = ''
    resultOnlyText = ''
    for text, pos in data:
        result += text + '/' + pos
        resultOnlyText += text
        if text == '.':
            result += '\n'
            resultOnlyText += '\n'
        else:
            result += ' '
            resultOnlyText += ' '

    lines = result.split('\n')
    linesOnlyText = resultOnlyText.split('\n')
    # random.seed(42)
    # random.shuffle(lines)
    p = int(len(lines) * 0.8)
    linesTrain = lines[:p]
    linesTest = lines[p:]
    linesTestOnlyText = linesOnlyText[p:]

    with open(outFile + '_train.txt', 'wt') as f:
        f.write('\n'.join(linesTrain))
    with open(outFile + '_test.txt', 'wt') as f:
        f.write('\n'.join(linesTest))
    with open(outFile + '_test_raw.txt', 'wt') as f:
        f.write('\n'.join(linesTestOnlyText))


def main():
    parser = argparse.ArgumentParser(description='datset generator')
    parser.add_argument('out_file', type=str, help='will be created out_file_train and out_file_test')
    parser.add_argument('-oc', '--open_corpus_ru', type=str, help='path to open corpus xml file')
    parser.add_argument('-ab', '--alphabet', type=str, required=True)
    args = parser.parse_args()

    utils.loadAlphabet(args.alphabet)

    data = None
    if args.open_corpus_ru:
        data = readOpenCorpusRu(args.open_corpus_ru)
    else:
        raise Exception("Missing source file")

    data = normData(data)

    save(data, args.out_file)


if __name__ == '__main__':
    main()
