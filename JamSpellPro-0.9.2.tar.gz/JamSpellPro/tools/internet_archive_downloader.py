import os
import time
import json
from internetarchive import get_session, get_item, get_files
from tqdm import tqdm
import urllib.request
import urllib.error
import requests


OUT_DIR = 'ic/'

LANGUAGES = set([
    'hindi',
    'french',
    'italian',
    'spanish',
    'turkish',
    'ukrainian',
    'polish',
    'dutch',
    'portuguese',
    'urdu',
    'norwegian'
])

OUT_DIR = 'ic/'

NUM_PAGES = 5

LANG_NUM_PAGES = {
    'french': 1,
    'polish': 10,
}

def getFragments(data, fragment):
    pos = 0
    fragmentSize = len(fragment)
    items = []
    while True:
        pos = data.find(fragment, pos)
        if pos == -1:
            break
        pos += fragmentSize
        pos2 = data.find('"', pos)
        if pos2 == -1:
            break
        itemID = data[pos:pos2]
        items.append(itemID)
    return items

def getEpubUrls(itemID):
    url = "https://archive.org/details/" + itemID
    fp = urllib.request.urlopen(url)
    data = fp.read()
    data = data.decode("utf8")
    items = getFragments(data, 'href="/download/')
    items = list(set([item for item in items if item.lower().endswith(".epub")]))
    return items

def getLinks(lang, page):
    url = 'https://archive.org/search.php?query=format%3Aepub&and%5B%5D=languageSorter%3A"' + lang + '"&page=' + str(page)
    #print(url)
    fp = urllib.request.urlopen(url)
    data = fp.read()
    data = data.decode("utf8")
    return getFragments(data, '<a href="/details/')

def downloadFile(outFile, fileId):
    url = 'https://archive.org/download/' + fileId
    if os.path.exists(outFile):
        return
    for i in range(3):
        try:
            #urllib.request.urlretrieve(url, outFile)
            request = requests.get(url, timeout=20, stream=True)

            with open(outFile, 'wb') as fh:
                for chunk in request.iter_content(1024 * 1024):
                    fh.write(chunk)

        except requests.exceptions.ReadTimeout as e:
            print('[warning] failed to fetch', fileId, e)
            time.sleep(3.0)

def processPage(lang, pageNum):
    print("processing", lang, pageNum, 'of', NUM_PAGES)
    taskDoneFile = os.path.join(OUT_DIR, lang, str(pageNum) + '_done')
    if os.path.exists(taskDoneFile):
        return
    lang = lang[0].upper() + lang[1:]
    items = getLinks(lang, pageNum)
    if not items:
        print('no items for', lang, pageNum)
        return

    for itemNum in tqdm(range(len(items))):
        epubUrls = getEpubUrls(items[itemNum])
        if not epubUrls:
            print("no epubs for", lang, pageNum, itemNum)
        for i, url in enumerate(epubUrls[:10]):
            #outFileName = items[0] + '_' + str(i) + '.epub'
            outFileName = url.replace('/', '_')
            outFileName = outFileName[-35:]
            outFileName = os.path.join(OUT_DIR, lang, outFileName)
            downloadFile(outFileName, url)

    with open(taskDoneFile, 'wt') as f:
        f.write('\n')

def bakeLanguage(lang):
    os.makedirs(os.path.join(OUT_DIR, lang), exist_ok=True)
    maxPages = LANG_NUM_PAGES.get(lang, NUM_PAGES)
    for i in range(1, maxPages+1):
        processPage(lang, i)


def bakeAll():
    for lang in LANGUAGES:
        bakeLanguage(lang)


def main():
    bakeAll()

    # items = getLinks("Hindi", 34)
    # print('\n'.join(items))
    # epubUrls = getEpubUrls(items[0])
    # print(epubUrls)
    # downloadFile(items[0] + '_0' + '.epub', epubUrls[0])

    # s = get_session()
    # s.mount_http_adapter()
    #
    # search_results = s.search_items('format:EPUB')
    #
    # for result in tqdm(search_results):
    #     itemID = result['identifier']
    #     item = get_item('govlawgacode20071')
    #     if item.metadata['language'].lower() not in LANGUAGES:
    #         continue
    #     # print(item)
    #     # print(item.metadata)
    #     # print()
    #     allFiles = []
    #     for f in get_files(itemID, formats=['EPUB']):
    #         allFiles.append(f)
    #     for f in get_files(itemID, formats=['epub']):
    #         allFiles.append(f)
    #
    #     fid = 0
    #     for f in allFiles:
    #         processFile(itemID + '_' + str(fid), f, item.metadata)
    #         fid += 1

if __name__ == '__main__':
    main()
