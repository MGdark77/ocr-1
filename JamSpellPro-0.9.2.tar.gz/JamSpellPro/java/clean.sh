ls *.java | grep -v main.java | xargs rm -f
rm -rf *.class
rm -rf jamspellpro_wrap.cxx
rm -rf jamspellpro.so

