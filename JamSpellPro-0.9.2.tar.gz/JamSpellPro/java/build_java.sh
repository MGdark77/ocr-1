set -e

SWIG_BINARY='/usr/local/opt/swig@4.0/bin/swig'
JDK_INCLUDE='/Library/Java/JavaVirtualMachines/jdk1.8.0_191.jdk/Contents/Home/include'
JDK_INCLUDE2='/Library/Java/JavaVirtualMachines/jdk1.8.0_191.jdk/Contents/Home/include/darwin'


$SWIG_BINARY -java -c++ -outcurrentdir ../jamspellpro.i 

g++ -std=c++17 -shared -I$JDK_INCLUDE -I$JDK_INCLUDE2 -I../ -I../contrib jamspellpro_wrap.cxx ../contrib/bloom/*.cpp ../contrib/phf/*.cc ../contrib/cityhash/*.cc ../contrib/tsl/*.cpp  ../contrib/catboost_evaluator/*.cpp ../jamspell/*.cpp -o jamspellpro.so


