public class main {
   public static void main(String argv[]) {
     System.load(System.getProperty("user.dir") + "/jamspellpro.so");
     var spellChecker = new TSpellCorrector();
     spellChecker.LoadLangModel("../test_data/test_model/");
     System.out.println(spellChecker.FixFragment("test sqntence"));
   }
}
