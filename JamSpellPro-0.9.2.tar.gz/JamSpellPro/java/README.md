## Java example

This is a simple example of building jamspell for java (`main.java`):

```
public class main {
   public static void main(String argv[]) {
     System.load(System.getProperty("user.dir") + "/jamspellpro.so");
     var spellChecker = new TSpellCorrector();
     spellChecker.LoadLangModel("../test_data/test_model/");
     System.out.println(spellChecker.FixFragment("test sqntence"));  // Will display "test sentence"
   }
}
```

#### Requirements
- latest swig (worked on swig4, may work on swig3 but not sure)
- JDK (java development kit)
- cpp compiler (checked on clang, should work on gcc, not sure about vsc)

#### Steps
- Edit `buils_java.sh`. Set SWIG_BINARY path, JDK_INCLUDE and JDK_INCLUDE2
- Run `./build_java.sh`
- Compile with `javac *.java`
- Run `java main`
- Clean files with `./clean.sh`

