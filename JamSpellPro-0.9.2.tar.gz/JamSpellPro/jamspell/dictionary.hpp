#include <string>
#include <unordered_set>

#include "utils.hpp"


namespace NJamSpell {

class TDictionary {
public:
    void Load(const std::string& fileName);
    void Save(const std::string& fileName);
    bool Exists(const std::wstring& word) const;
    TWord GetWord(const std::wstring& word) const;
    void AddWord(const std::wstring& word);
private:
    std::unordered_set<std::wstring> Data;
    bool Modified = false;
};

} // NJamSpell
