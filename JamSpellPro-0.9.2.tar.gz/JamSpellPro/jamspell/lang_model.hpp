#pragma once

#include <unordered_map>
#include <vector>
#include <utility>
#include <string>
#include <limits>
#include <fstream>

#include <contrib/handypack/handypack.hpp>
#include <contrib/tsl/robin_map.h>
#include "utils.hpp"
#include "perfect_hash.hpp"
#include "bloom_filter.hpp"
#include "dictionary.hpp"

namespace NJamSpell {


constexpr uint64_t LANG_MODEL_MAGIC_BYTE = 8559322735408079685L;
constexpr uint16_t LANG_MODEL_VERSION = 11;
constexpr double LANG_MODEL_DEFAULT_K = 0.05;

using TWordId = uint32_t;
using TCount = uint32_t;

using TGram1Key = TWordId;
using TGram2Key = std::pair<TWordId, TWordId>;
using TGram3Key = std::tuple<TWordId, TWordId, TWordId>;
using TWordIds = std::vector<TWordId>;
using TIdSentences = std::vector<TWordIds>;

struct TGram2KeyHash {
public:
  std::size_t operator()(const TGram2Key& x) const {
      return (size_t)x.first ^ ((size_t)x.second << 16);
  }
};

struct TGram3KeyHash {
public:
  std::size_t operator()(const TGram3Key& x) const {
    return (size_t)std::get<0>(x) ^
            ((size_t)std::get<1>(x) << 16) ^
            ((size_t)std::get<2>(x) << 32);
  }
};

class TRobinSerializer: public NHandyPack::TUnorderedMapSerializer<tsl::robin_map<std::wstring, TWordId>, std::wstring, TWordId> {};
class TRobinHash: public tsl::robin_map<std::wstring, TWordId> {
public:
    inline virtual void Dump(std::ostream& out) const {
        TRobinSerializer::Dump(out, *this);
    }
    inline virtual void Load(std::istream& in) {
        TRobinSerializer::Load(in, *this);
    }
};

class TLangModel {
public:
    bool Train(
        const std::string& fileName,
        const std::string& alphabetFile,
        const std::string& tmpDir,
        const std::string& gramsFile = std::string()
    );
    bool TrainAdd(const std::string& fileName, int count, const std::string& gramsFile = std::string());
    void AddText(const std::wstring& text, int count, bool addToDictionary = false);
    double Score(const TWords& words) const;
    double ScoreFeatures(const TWords& words, size_t pos, std::vector<double>& features) const;
    double Score(const std::wstring& str) const;
    TWord GetWord(const std::wstring& word) const;
    bool HasWordInDict(const std::wstring& word) const;
    const std::unordered_set<wchar_t>& GetAlphabet() const;
    TSentences Tokenize(const std::wstring& text) const;

    bool Dump(const std::string& modelFileName) const;
    bool Load(const std::string& modelFileName);
    void LoadDictionary(const std::string& dictPath);
    void SaveDictionary(const std::string& dictPath);
    void Clear();

    const TRobinHash& GetWordToId() const;

    TWordId GetWordId(const TWord& word);
    TWordId GetWordIdNoCreate(const TWord& word) const;
    TWord GetWordById(TWordId wid) const;
    const std::wstring& GetWordByIdWs(TWordId wid) const;
    TWordId GetLastWordId() const; // id of last word + 1
    TCount GetWordCount(TWordId wid) const;

    uint64_t GetCheckSum() const;

    int GetTop100WordCount() const;

    inline virtual void Dump(std::ostream& out) const {
        NHandyPack::Dump(out, (uint32_t)WordToId.size());
        for (auto it = WordToId.begin(); it != WordToId.end(); ++it) {
            NHandyPack::Dump(out, WideToUTF8(it.key()));
            NHandyPack::Dump(out, it.value());
        }
        NHandyPack::Dump(out, LastWordID);
        NHandyPack::Dump(out, TotalWords);
        NHandyPack::Dump(out, VocabSize);
        NHandyPack::Dump(out, PerfectHash);
        NHandyPack::Dump(out, Grams1);
        NHandyPack::Dump(out, Grams2);
        NHandyPack::Dump(out, Grams3);
        NHandyPack::Dump(out, *BucketsFilter);
        NHandyPack::Dump(out, Buckets);
        NHandyPack::Dump(out, Tokenizer);
        NHandyPack::Dump(out, CheckSum);
    }

    inline virtual void Load(std::ifstream& in) {

        uint32_t size;
        NHandyPack::Load(in, size);
        for (uint32_t i = 0; i < size; ++i) {
            std::string key;
            TWordId value;
            NHandyPack::Load(in, key);
            NHandyPack::Load(in, value);
            WordToId[UTF8ToWide(key)] = value;
        }

        NHandyPack::Load(in, LastWordID);
        NHandyPack::Load(in, TotalWords);
        NHandyPack::Load(in, VocabSize);
        NHandyPack::Load(in, PerfectHash);

        NHandyPack::Load(in, Grams1);
        NHandyPack::Load(in, Grams2);
        NHandyPack::Load(in, Grams3);

        BucketsFilter.reset(new TBloomFilter());
        NHandyPack::Load(in, *BucketsFilter);
        NHandyPack::Load(in, Buckets);
        NHandyPack::Load(in, Tokenizer);
        NHandyPack::Load(in, CheckSum);
    }

    inline virtual void Load10(std::ifstream& in) {

        uint32_t size;
        NHandyPack::Load(in, size);
        for (uint32_t i = 0; i < size; ++i) {
            std::string key;
            TWordId value;
            NHandyPack::Load(in, key);
            NHandyPack::Load(in, value);
            WordToId[UTF8ToWide(key)] = value;
        }

        NHandyPack::Load(in, LastWordID);
        NHandyPack::Load(in, TotalWords);
        NHandyPack::Load(in, VocabSize);
        NHandyPack::Load(in, PerfectHash);

        NHandyPack::Load(in, Grams1);
        NHandyPack::Load(in, Grams2);
        NHandyPack::Load(in, Grams3);

        BucketsFilter.reset(new TBloomFilter());
        NHandyPack::Load(in, *BucketsFilter);
        NHandyPack::Load(in, Buckets);
        Tokenizer.Load10(in);
        NHandyPack::Load(in, CheckSum);
    }

    TTokenizer& GetTokenizer() {
        return Tokenizer;
    }
private:
    TIdSentences ConvertToIds(const TSentences& sentences);

    double GetGram1Prob(TWordId word) const;
    double GetGram2Prob(TWordId word1, TWordId word2) const;
    double GetGram3Prob(TWordId word1, TWordId word2, TWordId word3) const;

    TCount GetGram1HashCount(TWordId word) const;
    TCount GetGram2HashCount(TWordId word1, TWordId word2) const;
    TCount GetGram3HashCount(TWordId word1, TWordId word2, TWordId word3) const;

    void CalculateGramsCount(
            const std::string& fileName,
            std::unordered_map<TGram1Key, TCount>& grams1,
            std::unordered_map<TGram2Key, TCount, TGram2KeyHash>& grams2,
            std::unordered_map<TGram3Key, TCount, TGram3KeyHash>& grams3
    );

    void LoadGramsCount(
            const std::string& gramsFile,
            std::unordered_map<TGram1Key, TCount>& grams1,
            std::unordered_map<TGram2Key, TCount, TGram2KeyHash>& grams2,
            std::unordered_map<TGram3Key, TCount, TGram3KeyHash>& grams3,
            size_t* addedGrams1 = nullptr
    );

public:
    const TWordId UnknownWordId = std::numeric_limits<TWordId>::max();
    const TWordId NumberWordId = std::numeric_limits<uint32_t>::max()-1;
    const TWordId EmptyWordId = std::numeric_limits<uint32_t>::max()-2;
private:
    const std::wstring EmptyWord;
    const std::wstring NumberWord = L"0";

private:
    TDictionary Dictionary;
    double K = LANG_MODEL_DEFAULT_K;
    TRobinHash WordToId;
    std::vector<std::wstring> IdToWord;
    int Top100WordCount = 0;
    TWordId LastWordID = 0;
    TWordId TotalWords = 0;
    TWordId VocabSize = 0;
    TTokenizer Tokenizer;
    std::vector<uint16_t> Buckets;
    TPerfectHash PerfectHash;

    std::unique_ptr<TBloomFilter> BucketsFilter;

    std::unordered_map<TGram1Key, TCount> Grams1;
    std::unordered_map<TGram2Key, TCount, TGram2KeyHash> Grams2;
    std::unordered_map<TGram3Key, TCount, TGram3KeyHash> Grams3;

    uint64_t CheckSum;
};


} // NJamSpell
