#define NOMINMAX
#include <limits>
#include <iostream>
#include <cassert>
#include <cmath>
#include <fstream>
#include <sstream>
#include <ostream>
#include <cstring>
#include <algorithm>
#include <system_error>
#include "lang_model.hpp"

#include <contrib/cityhash/city.h>
#include <contrib/phf/phf.h>
#include <contrib/mio/mio.hpp>

#ifndef ssize_t
#define ssize_t int
#endif

namespace NJamSpell {

int handleError(const std::error_code& error)
{
    const auto& errmsg = error.message();
    std::printf("error mapping file: %s\n", errmsg.c_str());
    return error.value();
}

class MemStream: public std::basic_streambuf<char> {
public:
    MemStream(char* buff, long maxSize)
        : Buff(buff)
        , MaxSize(maxSize)
        , Pos(0)
    {
    }
	std::streamsize xsputn(const char* s, std::streamsize n) override {
        if (n <= 0) {
            return n;
        }
        long toCopy = std::min<long>(n, MaxSize - Pos);
        memcpy(Buff + Pos, s, toCopy);
        Pos += toCopy;
        return n;
    }
    void Reset() {
        Pos = 0;
    }
    long Size() const {
        return Pos;
    }
private:
    char* Buff;
    long MaxSize;
    long Pos;
};

template<typename T>
std::string DumpKey(const T& key) {
    std::stringbuf buf;
    std::ostream out(&buf);
    NHandyPack::Dump(out, key);
    return buf.str();
}

template<typename T>
void PrepareNgramKeys(const T& grams, std::vector<std::string>& keys) {
    for (auto&& it: grams) {
        keys.push_back(DumpKey(it.first));
    }
}

static const uint32_t MAX_REAL_NUM = 268435456;
static const uint32_t MAX_AVAILABLE_NUM = 65536;

uint16_t PackInt32(uint32_t num) {
    double r = double(num) / double(MAX_REAL_NUM);
    assert(r >= 0.0 && r <= 1.0);
    r = pow(r, 0.2);
    r *= MAX_AVAILABLE_NUM;
    return uint16_t(r);
}

uint32_t UnpackInt32(uint16_t num) {
    double r = double(num) / double(MAX_AVAILABLE_NUM);
    r = pow(r, 5.0);
    r *= MAX_REAL_NUM;
    return uint32_t(ceil(r));
}

template<typename T>
void InitializeBuckets(const T& grams, TPerfectHash& ph, std::vector<uint16_t>& buckets, TBloomFilter& filter) {
    for (auto&& it: grams) {
        std::string key = DumpKey(it.first);
        uint32_t bucket = ph.Hash(key);
        assert(bucket < buckets.size());
        buckets[bucket] = PackInt32(it.second);
        filter.Insert(key);
    }
}

void TLangModel::AddText(const std::wstring& text, int count, bool addToDictionary) {
    std::wstring trainText = text;
    ToLower(trainText);
    TSentences sentences = Tokenizer.Process(trainText);
    if (sentences.empty()) {
        return;
    }

    int grams2count = std::max(1, count / 2);

    TIdSentences sentenceIds = ConvertToIds(sentences);

    assert(sentences.size() == sentenceIds.size());
    {
        std::wstring tmp;
        trainText.swap(tmp);
    }
    {
        TSentences tmp;
        sentences.swap(tmp);
    }

    uint64_t lastTime = GetCurrentTimeMs();
    size_t total = sentenceIds.size();
    size_t addedGrams1 = 0;

    for (ssize_t i = 0; i < (ssize_t)total; ++i) {
        const TWordIds& words = sentenceIds[i];

        for (auto w: words) {
            Grams1[w] += count;
            TotalWords += 1;
            addedGrams1 += count;
            if (addToDictionary) {
                Dictionary.AddWord(GetWordById(w).Wstr());
            }
        }

        for (ssize_t j = 0; j < (ssize_t)words.size() - 1; ++j) {
            TGram2Key key(words[j], words[j+1]);
            Grams2[key] += grams2count;
        }
        for (ssize_t j = 0; j < (ssize_t)words.size() - 2; ++j) {
            TGram3Key key(words[j], words[j+1], words[j+2]);
            Grams3[key] += 1;
        }

        uint64_t currTime = GetCurrentTimeMs();
        if (currTime - lastTime > 4000) {
            std::cerr << "[info] processed " << (100.0 * float(i) / float(total)) << "%" << std::endl;
            lastTime = currTime;
        }
    }

    VocabSize += addedGrams1;
}

bool TLangModel::TrainAdd(const std::string& fileName, int count, const std::string& gramsFile) {
    uint64_t trainStarTime = GetCurrentTimeMs();

    size_t addedGrams1 = 0;
    if (!gramsFile.empty()) {
        std::cerr << "[info] loading ngrams file " << gramsFile << "\n";
        LoadGramsCount(gramsFile, Grams1, Grams2, Grams3, &addedGrams1);
    } else {
        std::wstring trainText = UTF8ToWide(LoadFile(fileName));
        ToLower(trainText);
        TSentences sentences = Tokenizer.Process(trainText);
        if (sentences.empty()) {
            std::cerr << "[error] no sentences" << std::endl;
            return false;
        }

        TIdSentences sentenceIds = ConvertToIds(sentences);

        assert(sentences.size() == sentenceIds.size());
        {
            std::wstring tmp;
            trainText.swap(tmp);
        }
        {
            TSentences tmp;
            sentences.swap(tmp);
        }

        uint64_t lastTime = GetCurrentTimeMs();
        size_t total = sentenceIds.size();

        for (ssize_t i = 0; i < (ssize_t)total; ++i) {
            const TWordIds& words = sentenceIds[i];

            for (auto w: words) {
                Grams1[w] += count;
                TotalWords += 1;
                addedGrams1 += count;
            }

            for (ssize_t j = 0; j < (ssize_t)words.size() - 1; ++j) {
                TGram2Key key(words[j], words[j+1]);
                Grams2[key] += count;
            }
            for (ssize_t j = 0; j < (ssize_t)words.size() - 2; ++j) {
                TGram3Key key(words[j], words[j+1], words[j+2]);
                Grams3[key] += count;
            }

            uint64_t currTime = GetCurrentTimeMs();
            if (currTime - lastTime > 4000) {
                std::cerr << "[info] processed " << (100.0 * float(i) / float(total)) << "%" << std::endl;
                lastTime = currTime;
            }
        }
    }

    VocabSize += addedGrams1;

    std::stringbuf checkSumBuf;
    std::ostream checkSumOut(&checkSumBuf);
    NHandyPack::Dump(checkSumOut, trainStarTime, Grams1.size(), Grams2.size(),
                     Grams3.size(), Buckets.size());
    std::string checkSumStr = checkSumBuf.str();
    CheckSum = CityHash64(&checkSumStr[0], checkSumStr.size());
    return true;
}

void TouchFile(const std::string& fileName, size_t fileSize) {
    std::fstream fs;
    fs.open(fileName, std::ios::binary | std::ios::out | std::ios::trunc);
    fs.seekp(fileSize - 1);
    fs.write("", 1);
    fs.close();
}

const char kPathSeparator =
#ifdef _WIN32
            '\\';
#else
            '/';
#endif


bool TLangModel::Train(
        const std::string& fileName,
        const std::string& alphabetFile,
        const std::string& tmpDir,
        const std::string& gramsFile
) {

    std::cerr << "[info] processing text" << std::endl;
    uint64_t trainStarTime = GetCurrentTimeMs();
    if (!Tokenizer.LoadAlphabet(alphabetFile)) {
        std::cerr << "[error] failed to load alphabet" << std::endl;
        return false;
    }

    std::unordered_map<TGram1Key, TCount> grams1;
    std::unordered_map<TGram2Key, TCount, TGram2KeyHash> grams2;
    std::unordered_map<TGram3Key, TCount, TGram3KeyHash> grams3;

    if (gramsFile.empty()) {
        CalculateGramsCount(fileName, grams1, grams2, grams3);
    } else {
        LoadGramsCount(gramsFile, grams1, grams2, grams3);
    }

    VocabSize = grams1.size();

    if (VocabSize == 0) {
        std::cerr << "[error] no sentences" << std::endl;
        return false;
    }

    std::cerr << "[info] generating keys" << std::endl;

    size_t keysDataSize = 0;
    keysDataSize += sizeof(TWordId) * grams1.size();
    keysDataSize += sizeof(TWordId) * 2 * grams2.size();
    keysDataSize += sizeof(TWordId) * 3 * grams3.size();

    size_t phfDataSize = sizeof(phf_string_t) * (grams1.size() + grams2.size() + grams3.size());

    std::string keysFile = tmpDir + kPathSeparator + "keysData.tmp";
    std::string phfFile = tmpDir + kPathSeparator + "phfdata.tmp";

    TouchFile(keysFile, keysDataSize+1);
    TouchFile(phfFile, phfDataSize+1);

    std::error_code error;
    mio::mmap_sink keysData = mio::make_mmap_sink(keysFile, 0, mio::map_entire_file, error);
    if (error) {
        std::cerr << "[error] failed to map keysData file\n";
        handleError(error);
        return false;
    }

    mio::mmap_sink phfData = mio::make_mmap_sink(phfFile, 0, mio::map_entire_file, error);
    if (error) {
        std::cerr << "[error] failed to map phfdata file\n";
        handleError(error);
        return false;
    }

    std::cout << "[info] prepare key data\n";

    char* keysDataPtr = keysData.data();
    char* phfDataPtr = phfData.data();

    int n = 0;
    for (const auto& key: grams1) {
        n++;
        std::string keyStr = DumpKey(key.first);

        memcpy(keysDataPtr, &keyStr[0], keyStr.size());
        phf_string_t phfKey = {keysDataPtr, keyStr.size()};

        memcpy(phfDataPtr, &phfKey, sizeof(phf_string_t));

        keysDataPtr += keyStr.size();
        phfDataPtr += sizeof(phf_string_t);
    }

    for (const auto& key: grams2) {
        std::string keyStr = DumpKey(key.first);
        memcpy(keysDataPtr, &keyStr[0], keyStr.size());
        phf_string_t phfKey = {keysDataPtr, keyStr.size()};

        memcpy(phfDataPtr, &phfKey, sizeof(phf_string_t));
        keysDataPtr += keyStr.size();
        phfDataPtr += sizeof(phf_string_t);
    }

    for (const auto& key: grams3) {
        std::string keyStr = DumpKey(key.first);

        memcpy(keysDataPtr, &keyStr[0], keyStr.size());
        phf_string_t phfKey = {keysDataPtr, keyStr.size()};

        memcpy(phfDataPtr, &phfKey, sizeof(phf_string_t));
        keysDataPtr += keyStr.size();
        phfDataPtr += sizeof(phf_string_t);
    }

    std::cout << "[info] init raw\n";

    PerfectHash.InitRaw(phfData.data(), grams1.size()+grams2.size()+grams3.size());

    std::cerr << "[info] finished, buckets: " << PerfectHash.BucketsNumber() << "\n";

    Buckets.resize(PerfectHash.BucketsNumber());
    double falsePositiveProb = 0.001;
    BucketsFilter.reset(new TBloomFilter(grams1.size() + grams2.size() + grams3.size(), falsePositiveProb));

    InitializeBuckets(grams1, PerfectHash, Buckets, *BucketsFilter);
    InitializeBuckets(grams2, PerfectHash, Buckets, *BucketsFilter);
    InitializeBuckets(grams3, PerfectHash, Buckets, *BucketsFilter);

    std::cerr << "[info] buckets filled" << std::endl;

    std::stringbuf checkSumBuf;
    std::ostream checkSumOut(&checkSumBuf);
    NHandyPack::Dump(checkSumOut, trainStarTime, grams1.size(), grams2.size(),
                    grams3.size(), Buckets.size(), VocabSize);
    std::string checkSumStr = checkSumBuf.str();
    CheckSum = CityHash64(&checkSumStr[0], checkSumStr.size());
    return true;
}


void TLangModel::CalculateGramsCount(
        const std::string& fileName,
        std::unordered_map<TGram1Key, TCount>& grams1,
        std::unordered_map<TGram2Key, TCount, TGram2KeyHash>& grams2,
        std::unordered_map<TGram3Key, TCount, TGram3KeyHash>& grams3
) {
    std::cout << "[info] reading dataset file " << fileName << "\n";
    TFileLoader loader(fileName);
    int batchNumber = 0;
    while (true) {
        batchNumber += 1;
        std::cout << "[info] batch " << batchNumber << "\n";
        std::wstring trainText = loader.ReadNext();
//        std::wstring trainText = UTF8ToWide(LoadFile(fileName));
        if (trainText.empty()) {
            break;
        }

        ToLower(trainText);
        TSentences sentences = Tokenizer.Process(trainText);
        if (sentences.empty()) {
            continue;
        }

        TIdSentences sentenceIds = ConvertToIds(sentences);

        assert(sentences.size() == sentenceIds.size());
        {
            std::wstring tmp;
            trainText.swap(tmp);
        }
        {
            TSentences tmp;
            sentences.swap(tmp);
        }


        size_t total = sentenceIds.size();
        for (ssize_t i = 0; i < (ssize_t)total; ++i) {
            const TWordIds &words = sentenceIds[i];

            for (auto w: words) {
                grams1[w] += 1;
                TotalWords += 1;
            }

            for (ssize_t j = 0; j < (ssize_t) words.size() - 1; ++j) {
                TGram2Key key(words[j], words[j + 1]);
                grams2[key] += 1;
            }
            for (ssize_t j = 0; j < (ssize_t) words.size() - 2; ++j) {
                TGram3Key key(words[j], words[j + 1], words[j + 2]);
                grams3[key] += 1;
            }
        }
    }
}


void TLangModel::LoadGramsCount(
        const std::string& gramsFile,
        std::unordered_map<TGram1Key, TCount>& grams1,
        std::unordered_map<TGram2Key, TCount, TGram2KeyHash>& grams2,
        std::unordered_map<TGram3Key, TCount, TGram3KeyHash>& grams3,
        size_t* addedGrams1
) {
    TFileLoader loader(gramsFile);
    std::cout << "[info] reading ngrams file " << gramsFile << "\n";
    int batchNumber = 0;
    int bytesRead = 0;
    while (true) {
        batchNumber += 1;
        std::cout << "[info] batch " << batchNumber << "\n";
        std::wstring trainText = loader.ReadNext();
        bytesRead += trainText.size();
        if (trainText.empty()) {
            break;
        }

        std::vector<std::wstring> lines = Split(trainText, L'\n');

        for (auto&& l: lines) {
            std::vector<std::wstring> line = Split(l, L' ');
            if (line.size() < 2) {
                continue;
            }
            TCount count = std::stoul(line[0]);
            if (line.size() == 2) {
                auto wid = GetWordId(TWord(line[1]));
                grams1[wid] = count;
                if (addedGrams1) {
                    *addedGrams1 += count;
                    TotalWords += 1;
                }
            }
            if (line.size() == 3) {
                auto wid1 = GetWordId(TWord(line[1]));
                auto wid2 = GetWordId(TWord(line[2]));
                auto key = std::make_pair(wid1, wid2);
                grams2[key] = count;
            }
            if (line.size() == 4) {
                auto wid1 = GetWordId(TWord(line[1]));
                auto wid2 = GetWordId(TWord(line[2]));
                auto wid3 = GetWordId(TWord(line[3]));
                auto key = std::make_tuple(wid1, wid2, wid3);
                grams3[key] = count;
            }
        }
    }

    if (bytesRead == 0) {
        std::cout << "[error] failed to load ngrams file " << gramsFile << "\n";
    }
}


double TLangModel::Score(const TWords& words) const {
    TWordIds sentence;
    for (auto&& w: words) {
        sentence.push_back(GetWordIdNoCreate(w));
    }
    if (sentence.empty()) {
        return std::numeric_limits<double>::min();
    }

    sentence.push_back(UnknownWordId);
    sentence.push_back(UnknownWordId);

    double result = 0;
    for (size_t i = 0; i < sentence.size() - 2; ++i) {
        result += log(GetGram1Prob(sentence[i]));
        result += log(GetGram2Prob(sentence[i], sentence[i + 1]));
        result += log(GetGram3Prob(sentence[i], sentence[i + 1], sentence[i + 2]));
    }
    return result;
}

double TLangModel::ScoreFeatures(const TWords& words, size_t pos, std::vector<double>& features) const {
    TWordIds sentence;
    for (auto&& w: words) {
        sentence.push_back(GetWordIdNoCreate(w));
    }
    if (sentence.empty()) {
        return std::numeric_limits<double>::min();
    }

    double result = 0;
    int totalMeasures = 0;

//    std::cout << "check sentence pos: " << pos << ", words size: " << words.size() << ", sent: ";
//    for (auto&& w: words) {
//        std::cout << WideToUTF8(w.Wstr()) << " ";
//    }
//    std::cout << "\n";

    // has in dictionary
    {
        features.push_back(Dictionary.Exists(words[pos].Wstr()) ? 1.0 : 0.0);
    }

    // 1-gram
    {
//        std::cout << "1\n";
        double pred = log(GetGram1Prob(sentence[pos]));
        result += pred;
        totalMeasures += 1;
        features.push_back(pred);
    }

    // 2-grams
    {
        double pred = 0;
        if ((int)pos > 0){
//            std::cout << "2.1\n";
            pred = log(GetGram2Prob(sentence[pos-1], sentence[pos]));
            totalMeasures += 1;
        }
        result += pred;
        features.push_back(pred);
    }
    {
        double pred = 0;
        if ((int)pos < (int)sentence.size() - 1){
//            std::cout << "2.2\n";
            pred = log(GetGram2Prob(sentence[pos], sentence[pos+1]));
            totalMeasures += 1;
        }
        result += pred;
        features.push_back(pred);
    }

    // 3-grams
    {
        double pred = 0;
        if ((int)pos > 1){
//            std::cout << "3.1\n";
            pred = log(GetGram3Prob(sentence[pos-2], sentence[pos-1], sentence[pos]));
            totalMeasures += 1;
        }
        result += pred;
        features.push_back(pred);
    }
    {
        double pred = 0;
        if ((int)pos > 0 && (int)pos < (int)sentence.size() - 1){
//            std::cout << "3.2\n";
            pred = log(GetGram3Prob(sentence[pos-1], sentence[pos], sentence[pos+1]));
            totalMeasures += 1;
        }
        result += pred;
        features.push_back(pred);
    }
    {
        double pred = 0;
        if ((int)pos < (int)sentence.size() - 2){
//            std::cout << "3.3\n";
            pred = log(GetGram3Prob(sentence[pos], sentence[pos+1], sentence[pos+2]));
            totalMeasures += 1;
        }
        result += pred;
        features.push_back(pred);
    }
    result /= totalMeasures;

//    std::cout << "result: " << result << ", totalMeasures: " << totalMeasures << "\n";

    features.push_back(result);
    return result;
}

double TLangModel::Score(const std::wstring& str) const {
    TSentences sentences = Tokenizer.Process(str);
    TWords words;
    for (auto&& s: sentences) {
        for (auto&& w: s) {
            words.push_back(w);
        }
    }
    return Score(words);
}

bool TLangModel::Dump(const std::string& modelFileName) const {
    std::ofstream out(modelFileName, std::ios::binary);
    if (!out.is_open()) {
        return false;
    }
    NHandyPack::Dump(out, LANG_MODEL_MAGIC_BYTE);
    NHandyPack::Dump(out, LANG_MODEL_VERSION);
    Dump(out);
    NHandyPack::Dump(out, LANG_MODEL_MAGIC_BYTE);
    return true;
}

void TLangModel::LoadDictionary(const std::string& dictPath) {
    Dictionary.Load(dictPath);
}

void TLangModel::SaveDictionary(const std::string& dictPath) {
    Dictionary.Save(dictPath);
}

bool TLangModel::Load(const std::string& modelFileName) {
    std::ifstream in(modelFileName, std::ios::binary);
    if (!in.is_open()) {
        std::cerr << "[error] " << "missing " << modelFileName << "\n";
        return false;
    }
    uint16_t version = 0;
    uint64_t magicByte = 0;
    NHandyPack::Load(in, magicByte);
    if (magicByte != LANG_MODEL_MAGIC_BYTE) {
        std::cerr << "[error] " << "wrong magic byte 1\n";
        return false;
    }

    NHandyPack::Load(in, version);

    if (version == LANG_MODEL_VERSION) {
        Load(in);
    } else if (version == 10) {
        Load10(in);
    } else {
        std::cerr << "[error] " << "wrong model version\n";
        return false;
    }

    magicByte = 0;
    NHandyPack::Load(in, magicByte);
    if (magicByte != LANG_MODEL_MAGIC_BYTE) {
        std::cerr << "[error] " << "wrong magic byte 2\n";
        Clear();
        return false;
    }
    std::set<int> topWordCounts;
    IdToWord.clear();
    IdToWord.resize(WordToId.size());
    for (auto&& it: WordToId) {
        IdToWord[it.second] = it.first;
        int wordCount = GetWordCount(it.second);
        topWordCounts.insert(wordCount);
        if (topWordCounts.size() > 100) {
            topWordCounts.erase(topWordCounts.begin());
        }
    }
    Top100WordCount = *topWordCounts.begin();
    return true;
}

void TLangModel::Clear() {
    K = LANG_MODEL_DEFAULT_K;
    WordToId.clear();
    LastWordID = 0;
    TotalWords = 0;
    Tokenizer.Clear();
}

const TRobinHash& TLangModel::GetWordToId() const {
    return WordToId;
}

TIdSentences TLangModel::ConvertToIds(const TSentences& sentences) {
    TIdSentences newSentences;
    for (size_t i = 0; i < sentences.size(); ++i) {
        const TWords& words = sentences[i];
        TWordIds wordIds;
        for (size_t j = 0; j < words.size(); ++j) {
            const TWord& word = words[j];
            wordIds.push_back(GetWordId(word));
        }
        newSentences.push_back(wordIds);
    }
    return newSentences;
}

TWordId TLangModel::GetWordId(const TWord& word) {
    if (word.empty()) {
        return EmptyWordId;
    }
    if (word.Ptr[0] >= L'0' && word.Ptr[0] <= L'9') {
        return NumberWordId;
    }
    std::wstring w(word.Ptr, word.Len);
    auto it = WordToId.find(w);
    if (it != WordToId.end()) {
        return it->second;
    }
    TWordId wordId = LastWordID;
    ++LastWordID;
    it = WordToId.insert(std::make_pair(w, wordId)).first;
    IdToWord.push_back(it->first);
    return wordId;
}

TWordId TLangModel::GetLastWordId() const {
    return LastWordID;
}

TWordId TLangModel::GetWordIdNoCreate(const TWord& word) const {
    if (word.empty()) {
        return EmptyWordId;
    }
    if (word.Ptr[0] >= L'0' && word.Ptr[0] <= L'9') {
        return NumberWordId;
    }
    std::wstring w(word.Ptr, word.Len);
    auto it = WordToId.find(w);
    if (it != WordToId.end()) {
        return it->second;
    }
    return UnknownWordId;
}

TWord TLangModel::GetWordById(TWordId wid) const {
    if (wid == NumberWordId) {
        return TWord(L"0", 1);
    }
    if (wid >= IdToWord.size()) {
        return TWord();
    }
    return TWord(IdToWord[wid]);
}

const std::wstring& TLangModel::GetWordByIdWs(NJamSpell::TWordId wid) const {
    if (wid == NumberWordId) {
        return NumberWord;
    }
    if (wid >= IdToWord.size()) {
        return EmptyWord;
    }
    return IdToWord[wid];
}

TCount TLangModel::GetWordCount(TWordId wid) const {
    return GetGram1HashCount(wid);
}

uint64_t TLangModel::GetCheckSum() const {
    return CheckSum;
}

int TLangModel::GetTop100WordCount() const {
    return Top100WordCount;
}

TWord TLangModel::GetWord(const std::wstring& word) const {
    auto it = WordToId.find(word);
    if (it != WordToId.end()) {
        return TWord(&it->first[0], it->first.size());
    }
    return Dictionary.GetWord(word);
}

bool TLangModel::HasWordInDict(const std::wstring& word) const {
    return Dictionary.Exists(word);
}

const std::unordered_set<wchar_t>& TLangModel::GetAlphabet() const {
    return Tokenizer.GetAlphabet();
}

TSentences TLangModel::Tokenize(const std::wstring& text) const {
    return Tokenizer.Process(text);
}

double TLangModel::GetGram1Prob(TWordId word) const {
    double countsGram1 = GetGram1HashCount(word);
    countsGram1 += K;
    return countsGram1 / (TotalWords + VocabSize);
}

double TLangModel::GetGram2Prob(TWordId word1, TWordId word2) const {
    double countsGram1 = GetGram1HashCount(word1);
    double countsGram2 = GetGram2HashCount(word1, word2);
    if (countsGram2 > countsGram1) { // (hash collision)
        countsGram2 = 0;
    }
    countsGram1 += TotalWords;
    countsGram2 += K;
    return countsGram2 / countsGram1;
}

double TLangModel::GetGram3Prob(TWordId word1, TWordId word2, TWordId word3) const {
    double countsGram2 = GetGram2HashCount(word1, word2);
    double countsGram3 = GetGram3HashCount(word1, word2, word3);
    if (countsGram3 > countsGram2) { // hash collision
        countsGram3 = 0;
    }
    countsGram2 += TotalWords;
    countsGram3 += K;
    return countsGram3 / countsGram2;
}

template<typename T>
TCount GetGramHashCount(T key,
                        const TPerfectHash& ph,
                        const std::vector<uint16_t>& buckets,
                        TBloomFilter& filter)
{
    constexpr int TMP_BUF_SIZE = 128;
    static char tmpBuff[TMP_BUF_SIZE];
    static MemStream tmpBuffStream(tmpBuff, TMP_BUF_SIZE - 1);
    static std::ostream out(&tmpBuffStream);

    tmpBuffStream.Reset();

    NHandyPack::Dump(out, key);
    if (!filter.Contains(tmpBuff, tmpBuffStream.Size())) {
        return TCount();
    }

    uint32_t bucket = ph.Hash(tmpBuff, tmpBuffStream.Size());

    assert(bucket < ph.BucketsNumber());

    return UnpackInt32(buckets[bucket]);
}

TCount TLangModel::GetGram1HashCount(TWordId word) const {
    if (word == UnknownWordId) {
        return TCount();
    }
    TGram1Key key = word;
    TCount result = GetGramHashCount(key, PerfectHash, Buckets, *BucketsFilter);
    auto it = Grams1.find(key);
    if (it != Grams1.end()) {
        result += it->second;
    }
    return result;
}

TCount TLangModel::GetGram2HashCount(TWordId word1, TWordId word2) const {
    if (word1 == UnknownWordId || word2 == UnknownWordId) {
        return TCount();
    }
    TGram2Key key({word1, word2});
    TCount result = GetGramHashCount(key, PerfectHash, Buckets, *BucketsFilter);
    auto it = Grams2.find(key);
    if (it != Grams2.end()) {
        result += it->second;
    }
    return result;
}

TCount TLangModel::GetGram3HashCount(TWordId word1, TWordId word2, TWordId word3) const {
    if (word1 == UnknownWordId || word2 == UnknownWordId || word3 == UnknownWordId) {
        return TCount();
    }
    TGram3Key key(word1, word2, word3);
    TCount result = GetGramHashCount(key, PerfectHash, Buckets, *BucketsFilter);
    auto it = Grams3.find(key);
    if (it != Grams3.end()) {
        result += it->second;
    }
    return result;
}


} // NJamSpell
