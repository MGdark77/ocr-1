#pragma once

#include <string>
#include <vector>
#include <unordered_set>
#include <locale>

#include <contrib/handypack/handypack.hpp>

namespace NJamSpell {

std::string LoadFile(const std::string& fileName);
void SaveFile(const std::string& fileName, const std::string& data);
std::wstring UTF8ToWide(const std::string& text);
std::string WideToUTF8(const std::wstring& text);
uint64_t GetCurrentTimeMs();
void ToLower(std::wstring& text);
wchar_t MakeUpperIfRequired(wchar_t orig, wchar_t sample);
uint16_t CityHash16(const std::string& str);
uint16_t CityHash16(const char* str, size_t size);

std::vector<std::wstring> Split(const std::wstring& str, const wchar_t delim);
std::unordered_set<wchar_t> StrToSet(const std::wstring& str);

struct TWord {
    TWord() = default;
    TWord(const wchar_t* ptr, size_t len)
        : Ptr(ptr)
        , Len(len)
    {
    }
    TWord(const std::wstring& w)
        : Ptr(&w[0])
        , Len(w.size())
    {
    }
    bool empty() const {
        return (Ptr == nullptr || Len == 0);
    }
    bool operator ==(const TWord& other) const {
        return (Ptr == other.Ptr && Len == other.Len);
    }
    const wchar_t* Ptr = nullptr;
    size_t Len = 0;
    std::wstring Wstr() const {
        return std::wstring(Ptr, Len);
    }
    std::string Str() const {
        return WideToUTF8(Wstr());
    }
    bool StartsWithDigit() const {
        if (empty()) {
            return false;
        }
        return Ptr[0] >= L'0' && Ptr[0] <= L'9';
    }
};

struct TScoredWord {
    TWord Word;
    TWord Word2;
    std::wstring Wstr() const {
        std::wstring res = Word.Wstr();
        if (!Word2.empty()) {
            res += L" ";
            res += Word2.Wstr();
        }
        return res;
    }
    int Len() const {
        int len = Word.Len;
        if (!Word2.empty()) {
            len += Word2.Len + 1;
        }
        return len;
    }
    double Score = 0;
    std::vector<double> Features;
    double Prediction = 0.0;
    int EditDistance = 0;
};

struct TScoredWordWstr {
    std::wstring Word;
    double Score = 0;
};

struct TWordHashPtr {
public:
  std::size_t operator()(const TWord& x) const {
      return (size_t)x.Ptr;
  }
};

struct TWordFeature {
    std::wstring Word;
    std::vector<double> Features;
};

using TWords = std::vector<TWord>;
using TScoredWords = std::vector<TScoredWord>;
using TScoredWordsWstr = std::vector<TScoredWordWstr>;
using TSentences = std::vector<TWords>;
using TWordFeatures = std::vector<TWordFeature>;

TWord StripBeginEnd(TWord word, const std::unordered_set<wchar_t>& charsToStrip);

class TTokenizer {
public:
    TTokenizer();
    bool LoadAlphabet(const std::string& alphabetFile);
    TSentences Process(const std::wstring& originalText) const;
    void Clear();

    const std::unordered_set<wchar_t>& GetAlphabet() const;

    inline void DumpWcharSet(std::ostream& out, const std::unordered_set<wchar_t>& wcharset) const {
        std::wstring alphabet;
        for (auto w: wcharset) {
            alphabet += w;
        }
        NHandyPack::Dump(out, WideToUTF8(alphabet));
    }

    inline void LoadWcharSet(std::istream& in, std::unordered_set<wchar_t>& wcharset) {
        std::string alphabet;
        NHandyPack::Load(in, alphabet);
        std::wstring alphabetw = UTF8ToWide(alphabet);
        for (auto w: alphabetw) {
            wcharset.insert(w);
        }
    }

    inline virtual void Dump(std::ostream& out) const {
        DumpWcharSet(out, Alphabet);
        DumpWcharSet(out, BeginEndStrip);
    }

    inline virtual void Load(std::istream& in) {
        LoadWcharSet(in, Alphabet);
        LoadWcharSet(in, BeginEndStrip);
    }
    inline virtual void Load10(std::istream& in) {
        LoadWcharSet(in, Alphabet);
    }
private:
    std::unordered_set<wchar_t> Alphabet;
    std::unordered_set<wchar_t> BeginEndStrip;
    std::locale Locale;
};

class TFileLoader {
public:
    TFileLoader(const std::string& fileName, int bufferSize = 128000000);
    std::wstring ReadNext();
private:
    std::unique_ptr<std::ifstream> In;
    int BufferSize;
    std::string Buffer;
};



} // NJamSpell
