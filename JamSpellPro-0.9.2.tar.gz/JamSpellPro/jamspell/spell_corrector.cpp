#include <algorithm>
#include <fstream>

#include "spell_corrector.hpp"

namespace NJamSpell {


static std::vector<std::wstring> GetDeletes1(const std::wstring& w) {
    std::vector<std::wstring> results;
    for (size_t i = 0; i < w.size(); ++i) {
        auto nw = w.substr(0, i) + w.substr(i+1);
        if (!nw.empty()) {
            results.push_back(nw);
        }
    }
    return results;
}

static std::vector<std::vector<std::wstring>> GetDeletes2(const std::wstring& w) {
    std::vector<std::vector<std::wstring>> results;
    for (size_t i = 0; i < w.size(); ++i) {
        auto nw = w.substr(0, i) + w.substr(i+1);
        if (!nw.empty()) {
            std::vector<std::wstring> currResults = GetDeletes1(nw);
            currResults.push_back(nw);
            results.push_back(currResults);
        }
    }
    return results;
}

TSpellCorrector::TSpellCorrector(int numThreads) {
    if (numThreads == 0) {
        numThreads = std::thread::hardware_concurrency();
        if (numThreads == 0) {
            numThreads = 1;
        }
        numThreads = std::min(16, numThreads);
    }
    for (int i = 0; i < numThreads; ++i) {
        Threads.emplace_back(std::unique_ptr<std::thread>(new std::thread(&TSpellCorrector::Worker, this)));
    }
}

TSpellCorrector::~TSpellCorrector() {
    {
        std::lock_guard<std::mutex> lock(Lock);
        Finished = true;
    }
    CondVar.notify_all();
    for (auto&& t: Threads) {
        t->join();
    }
}

void TSpellCorrector::Worker() {
    while (true) {
        int taskID = -1;
        {
            std::unique_lock<std::mutex> lock(Lock);
            if (Finished) {
                break;
            }
            if (!ThreadTasks.empty()) {
                taskID = ThreadTasks.front();
                ThreadTasks.pop();
            }
            if (taskID == -1) {
                CondVar.wait(lock);
                continue;
            }
        }
        ProcessTask(taskID);
    }
}

void TSpellCorrector::ProcessTask(int taskID) {
    TWords results;
    for (auto&& w: CandsToCheck[taskID]) {
        TWord c = LangModel.GetWord(w);
        if (c.Ptr && c.Len) {
            results.push_back(c);
        }
        std::string s = WideToUTF8(w);
        if (Deletes1->Contains(s)) {
            Inserts(w, results);
        }
        if (Deletes2->Contains(s)) {
            Inserts2(w, results);
        }
    }

    {
        std::unique_lock<std::mutex> lock(Lock);
        ThreadResults += 1;
        for (auto&& r: results) {
            ThreadResultsWords.push_back(r);
        }
    }
    DoneCondVar.notify_all();
}

const char kPathSeparator =
#ifdef _WIN32
            '\\';
#else
            '/';
#endif

bool TSpellCorrector::LoadLangModel(const std::string& modelPath) {
    if (!LangModel.Load(modelPath + kPathSeparator + "frequencies.bin")) {
        return false;
    }
    LangModel.LoadDictionary(modelPath + kPathSeparator + "dictionary.txt");
    std::string cacheFile = modelPath + kPathSeparator + "frequencies.bin.spell";
    if (!LoadCache(cacheFile)) {
        PrepareCache();
        SaveCache(cacheFile);
    }

    bool loaded = true;

    try {
        EvaluatorErrors.reset(new NCatboostStandalone::TOwningEvaluator(
                modelPath + kPathSeparator + "catboost_error.bin"
        ));
    } catch (std::runtime_error) {
        std::cerr << "[warning] failed to load catboost_error.bin\n";
        loaded = false;
    }

    try {
        EvaluatorShort.reset(new NCatboostStandalone::TOwningEvaluator(
                modelPath + kPathSeparator + "catboost_short.bin"
        ));
    } catch (std::runtime_error) {
        std::cerr << "[warning] failed to load catboost_short.bin";
        loaded = false;
    }

    try {
        EvaluatorRank.reset(new NCatboostStandalone::TOwningEvaluator(
                modelPath + kPathSeparator + "catboost_rank.bin"
        ));
    } catch (std::runtime_error) {
        std::cerr << "[warning] failed to load catboost_rank.bin\n";
        loaded = false;
    }

    for (auto&& ch: LangModel.GetAlphabet()) {
        if (ch == L'\n') {
            loaded = false;
        }
    }

    return loaded;
}

bool TSpellCorrector::SaveLangModel(const std::string& modelPath) {
    if (!LangModel.Dump(modelPath + kPathSeparator + "frequencies.bin")) {
        std::cerr << "[error] failed to save model to path: " + modelPath + kPathSeparator + "frequencies.bin" << "\n";
        return false;
    }
    LangModel.SaveDictionary(modelPath + kPathSeparator + "dictionary.txt");

    std::string cacheFile = modelPath + kPathSeparator + "frequencies.bin" + ".spell";
    if (!SaveCache(cacheFile)) {
        std::cerr << "[error] failed to save cache to path: " + cacheFile << "\n";
        return false;
    }
    return true;
}

bool TSpellCorrector::TrainLangModel(
        const std::string& textFile,
        const std::string& alphabetFile,
        const std::string& modelPath,
        const std::string& tmpDir,
        const std::string& gramsFile
) {
    if (!LangModel.Train(textFile, alphabetFile, tmpDir, gramsFile)) {
        std::cerr << "[error] failed to train model" <<"\n";
        return false;
    }
    std::cout << "[info] preparing cache" << "\n";
    PrepareCache();
    if (!SaveLangModel(modelPath)) {
        std::cerr << "[error] failed to save lang model" <<"\n";
        return false;
    }
    std::cout << "[info] model successfully trained" << "\n";
    return true;
}


bool TSpellCorrector::TrainAdd(
        const std::string &textFile,
        const std::string &modelPath,
        double priority,
        const std::string& gramsFile
) {
    TWordId prevLastWordId = LangModel.GetLastWordId();
    int wordsCount = priority * LangModel.GetTop100WordCount();
    wordsCount = std::max(1, wordsCount);

    if (!LangModel.TrainAdd(textFile, wordsCount, gramsFile)) {
        return false;
    }
    PrepareCache(prevLastWordId);
    if (!SaveLangModel(modelPath)) {
        return false;
    }
    return true;
}

void TSpellCorrector::AddText(const std::wstring& text, double priority, bool addToDictionary) {
    TWordId prevLastWordId = LangModel.GetLastWordId();
    int wordsCount = priority * LangModel.GetTop100WordCount();
    wordsCount = std::max(1, wordsCount);
    LangModel.AddText(text, wordsCount, addToDictionary);
    PrepareCache(prevLastWordId);
}

std::vector<std::string> TSpellCorrector::GetCandidatesU(const std::vector<std::string>& sentence, size_t position) {
    std::vector<std::string> results;
    std::vector<std::wstring> sentenceW;
    for (auto&& w: sentence) {
        sentenceW.push_back(UTF8ToWide(w));
    }
    auto tmpRes = GetCandidates(sentenceW, position);
    for (auto&& res: tmpRes) {
        results.push_back(WideToUTF8(res));
    }
    return results;
}

std::vector<std::pair<std::string,double> > TSpellCorrector::GetCandidatesWithScoresU(
        const std::vector<std::string>& sentence, size_t position)
{
    std::vector<std::pair<std::string,double> > results;
    std::vector<std::wstring> sentenceW;
    for (auto&& w: sentence) {
        sentenceW.push_back(UTF8ToWide(w));
    }
    auto tmpRes = GetCandidatesWithScores(sentenceW, position);
    for (auto&& res: tmpRes) {
        results.push_back(std::make_pair(WideToUTF8(res.first), res.second));
    }
    return results;
}

std::string TSpellCorrector::FixFragmentU(const std::string& text) {
    return WideToUTF8(FixFragment(UTF8ToWide(text)));
}


void TSpellCorrector::AddTextU(const std::string& text, double priority) {
    AddText(UTF8ToWide(text), priority);
}


int dp[301][301];

int editDistDP(const std::wstring& str1, const std::wstring& str2)
{
    int m = str1.size();
    int n = str2.size();
    // Create a table to store results of subproblems

    if (m > 300) m = 300;
    if (n > 300) n = 300;

    // Fill d[][] in bottom up manner
    for (int i = 0; i <= m; i++) {
        for (int j = 0; j <= n; j++) {
            // If first string is empty, only option is to
            // insert all characters of second string
            if (i == 0)
                dp[i][j] = j; // Min. operations = j

                // If second string is empty, only option is to
                // remove all characters of second string
            else if (j == 0)
                dp[i][j] = i; // Min. operations = i

                // If last characters are same, ignore last char
                // and recur for remaining string
            else if (str1[i - 1] == str2[j - 1])
                dp[i][j] = dp[i - 1][j - 1];

                // If the last character is different, consider all
                // possibilities and find the minimum
            else
                dp[i][j] = 1 + std::min(std::min(dp[i][j - 1], // Insert
                                   dp[i - 1][j]), // Remove
                                   dp[i - 1][j - 1]); // Replace
        }
    }

    return dp[m][n];
}

void TSpellCorrector::SetDictionaryWordFixPenalty(double newPenalty) {
    DictionaryWordFixPenalty = newPenalty;
}

void TSpellCorrector::SetShortWordsAfterNumberLength(int length) {
    ShortWordsAfterNumbersLength = length;
}

void TSpellCorrector::SetFixUpperCased(bool fixUpper) {
    FixUpperCased = fixUpper;
}

inline void UpdatePrediction(
        double& prediction, TLangModel& langModel,
        const std::wstring& candidate, TWord origWord,
        double existingWordPenalty
)
{
    if (origWord.Wstr() != candidate) {
        return;
    }
    if (!langModel.HasWordInDict(candidate)) {
        return;
    }
    prediction += existingWordPenalty;
}

TScoredWords TSpellCorrector::GetCandidatesRawWithPredictions(
        const NJamSpell::TWords& sentence,
        size_t position
) {

    if (position >= sentence.size()) {
        return TScoredWords();
    }

    if (sentence[position].empty()) {
        return TScoredWords();
    }

    // skip words beginning with number
    if (sentence[position].StartsWithDigit()) {
        return TScoredWords();
    }

    // skip short words that follows numbers
    if (ShortWordsAfterNumbersLength > 0 && sentence[position].Len <= ShortWordsAfterNumbersLength) {
        if (position > 0 && sentence[position-1].StartsWithDigit()) {
            return TScoredWords();
        }
    }

    if (position == sentence.size() - 1 && sentence[position].Len == 1) {
        return TScoredWords();
    }

    // fast check for errors

    std::vector<double> errFeatures;
    LangModel.ScoreFeatures(sentence, position, errFeatures);
    std::vector<float> errFeaturesFloat;
    for (auto f: errFeatures) {
        errFeaturesFloat.push_back(f);
    }
    if (!EvaluatorErrors) {
        std::cerr << "[error] model not loaded (evaluator errors)\n";
        return TScoredWords();
    }
    double errPredict = EvaluatorErrors->Apply(errFeaturesFloat, NCatboostStandalone::EPredictionType::Class);
    if (errPredict < 0.5) {
        return TScoredWords();
    }


    // check for close edit distances

    TScoredWords candidates = GetCandidatesRawWithScores(sentence, position, true, false);

    if (!candidates.empty()) {
        if (!EvaluatorRank) {
            std::cerr << "[error] model not loaded (evaluator rank)\n";
            return TScoredWords();
        }
        for (auto& c: candidates) {
            std::vector<float> features;
            for (auto f: c.Features) {
                features.push_back(f);
            }
            c.Prediction = EvaluatorRank->Apply(features, NCatboostStandalone::EPredictionType::RawValue);
            if (DictionaryWordFixPenalty > 0.1) {
                UpdatePrediction(c.Prediction, LangModel, c.Wstr(), sentence[position], DictionaryWordFixPenalty);
            }
        }
        std::sort(candidates.begin(), candidates.end(), [](const TScoredWord& w1, const TScoredWord& w2) {
            return w1.Prediction > w2.Prediction;
        });

        std::vector<float> shortFeatures;
        for (auto f: candidates[0].Features) {
            shortFeatures.push_back(f);
        }
        shortFeatures.push_back(candidates[0].Prediction);
        shortFeatures.push_back(candidates.size());
        if (!EvaluatorShort) {
            std::cerr << "[error] model not loaded (evaluator short)\n";
            return TScoredWords();
        }
        double shortPredict = EvaluatorShort->Apply(
                shortFeatures,
                NCatboostStandalone::EPredictionType::Class
        );
        if (shortPredict >= 0.5) {
            return candidates;
        }
    }

    // full edit distances
    candidates = GetCandidatesRawWithScores(sentence, position, true, true);
    if (!EvaluatorRank) {
        std::cerr << "[error] model not loaded (evaluator rank)\n";
        return TScoredWords();
    }
    for (auto& c: candidates) {
        std::vector<float> features;
        for (auto f: c.Features) {
            features.push_back(f);
        }
        c.Prediction = EvaluatorRank->Apply(features, NCatboostStandalone::EPredictionType::RawValue);
        if (DictionaryWordFixPenalty > 0.1) {
            UpdatePrediction(c.Prediction, LangModel, c.Wstr(), sentence[position], DictionaryWordFixPenalty);
        }
    }

    std::sort(candidates.begin(), candidates.end(), [](const TScoredWord& w1, const TScoredWord& w2) {
        return w1.Prediction > w2.Prediction;
    });
//    for (auto&& c: candidates) {
//        std::wstring str = c.Word.Wstr();
//        if (!c.Word2.empty()) {
//            str += L" ";
//            str += c.Word2.Wstr();
//        }
//        std::cout << WideToUTF8(str) << ", score: " << c.Score << ", pred: " << c.Prediction << "\n";
//    }

//    std::cerr << "Last canidates size: " << candidates.size() << "\n";
    return candidates;
}


TScoredWord TSpellCorrector::MakeScoredWord(
        TWord candWord1,
        TWord candWord2,
        const TWords& sentence,
        size_t position,
        bool firstLevel,
        bool knownWord,
        bool needFeatures
) {

    TWords candSentence;
    size_t candPos = 0;
    size_t shift = 0;
    for (size_t i = 0; i < sentence.size(); ++i) {
        if (i == position) {
            candPos = candSentence.size();
            candSentence.push_back(candWord1);
            if (candWord2.Ptr && candWord2.Len) {
                candSentence.push_back(candWord2);
                shift = 1;
            }
        } else if (((i+shift) < position && (i+shift) + 4 >= position) ||
                   ((i+shift) > position && (i+shift) <= position + 4))
        {
            candSentence.push_back(sentence[i]);
        }
    }

    TScoredWord scored;
    scored.Word = candWord1;
    scored.Word2 = candWord2;
    if (needFeatures) {
        scored.Score = LangModel.ScoreFeatures(candSentence, candPos, scored.Features);
    } else {
        scored.Score = LangModel.Score(candSentence);
    }
//    std::cerr << WideToUTF8(scored.Wstr()) << " " << scored.Score << "\n";

    TWord w = sentence[position];

    if (!(scored.Word == w)) {
        if (knownWord) {
            if (firstLevel) {
                scored.Score -= KnownWordsPenalty;
            } else {
                scored.Score *= 50.0;
            }
        } else {
            scored.Score -= UnknownWordsPenalty;
        }
    }

    if (LangModel.GetWord(scored.Word.Wstr()).empty()) {
        scored.Score -= UnknownWordsPenalty;
    }
    if (needFeatures) {
        int editDistance = editDistDP(
                std::wstring(sentence[position].Ptr, sentence[position].Len),
                scored.Wstr()
        );
        int w2len = 0;
        if (scored.Word2.Ptr) {
            w2len = scored.Word2.Len;
        }
        scored.Features.push_back(scored.Word.Len);
        scored.Features.push_back(w2len);

//        scored.Features.push_back(0);
//        std::cerr << "Edit distance: " << editDistance << "\n";
        scored.Features.push_back(editDistance);
        scored.Features.push_back(scored.Len());
        scored.EditDistance = editDistance;
    }

//    std::cerr << WideToUTF8(scored.Wstr()) << " " << scored.Score << "\n";

    return scored;
}

TScoredWords TSpellCorrector::GetCandidatesRawWithScores(
        const TWords& sentence,
        size_t position,
        bool needFeatures,
        bool full
) {
    TScoredWords scoredCandidates;

    if (position >= sentence.size()) {
        return scoredCandidates;
    }

    TWord w = sentence[position];
    TWords candidates = Edits2(w);

    std::vector<std::pair<TWord, TWord>> splitCandidates = Splits(w, false);


//    std::cerr << "splits number: " << splitCandidates.size() << "\n";
//    for (auto s: splitCandidates) {
//        auto w1 = WideToUTF8(std::wstring(s.first.Ptr, s.first.Len));
//        auto w2 = WideToUTF8(std::wstring(s.second.Ptr, s.second.Len));
//        std::cerr << w1 << " " << w2 << "\n";
//    }
//    TWords candidates = Edits(w);

    bool firstLevel = true;
//    bool firstLevel = false;
    bool knownWord = false;
    if (full) {
        auto candidates2 = Edits(w);
        for (auto&& c: candidates2) {
            candidates.push_back(c);
        }
    }
    firstLevel = false;

    if (full && candidates.empty() && splitCandidates.empty()) {
        splitCandidates = Splits(w, true);
    }

    if (candidates.empty() && splitCandidates.empty()) {
        return scoredCandidates;
    }

    {
        TWord c = LangModel.GetWord(std::wstring(w.Ptr, w.Len));
        if (c.Ptr && c.Len) {
            w = c;
            candidates.push_back(c);
            knownWord = true;
        } else {
            candidates.push_back(w);
        }
    }

    std::unordered_set<TWord, TWordHashPtr> uniqueCandidates(candidates.begin(), candidates.end());

    FilterCandidatesByFrequency(uniqueCandidates, w);
    scoredCandidates.reserve(uniqueCandidates.size() + splitCandidates.size());

    for (TWord cand: uniqueCandidates) {
        scoredCandidates.push_back(MakeScoredWord(cand, TWord(), sentence, position, firstLevel, knownWord, needFeatures));
    }
    for (std::pair<TWord, TWord> cand: splitCandidates) {
        scoredCandidates.push_back(MakeScoredWord(cand.first, cand.second, sentence, position, firstLevel, knownWord, needFeatures));
    }

    if (needFeatures) {
        std::map<size_t, size_t> editDistanceCounts;
        for (auto& c: scoredCandidates) {
            editDistanceCounts[c.EditDistance]++;
        }

        for (auto& c: scoredCandidates) {
            int betterEditDistanceCandidates = 0;
            for (int i = 0; i < c.EditDistance; ++i) {
                betterEditDistanceCandidates += editDistanceCounts[i];
            }
            c.Features.push_back(betterEditDistanceCandidates);
        }

        for (auto& c: scoredCandidates) {
            c.Features.push_back(c.Score);
        }
    }

    std::sort(scoredCandidates.begin(), scoredCandidates.end(), [](TScoredWord w1, TScoredWord w2) {
        return w1.Score > w2.Score;
    });
    return scoredCandidates;
}

bool TSpellCorrector::HasErrorRaw(const NJamSpell::TWords& sentence, size_t position) {
    auto wordID = LangModel.GetWordIdNoCreate(sentence[position]);
    if (wordID == LangModel.UnknownWordId) {
        return true;
    }
    auto candidates = GetCandidatesRawWithScores(sentence, position);
    if (candidates.empty()) {
        return true;
    }
    auto candidateID = LangModel.GetWordIdNoCreate(candidates[0].Word);
    return wordID != candidateID;
}

TScoredWordsWstr TSpellCorrector::GetMaskedWordRaw(
        const NJamSpell::TWords& sentence,
        size_t position,
        size_t count)
{
    const auto wordToId = LangModel.GetWordToId();
    NJamSpell::TWords wordsToCheck;
    for (int i = std::max(0, int(position) - 3); i < (int)position + 4 && i < (int)sentence.size(); ++i) {
        wordsToCheck.push_back(sentence[i]);
    }
    position = std::min(3, (int)position);
    std::multimap<double, TScoredWord> res;
    for (auto&& e: wordToId) {
        TScoredWord sw;
        sw.Word = TWord(e.first);
        wordsToCheck[position] = sw.Word;
        sw.Score = LangModel.Score(wordsToCheck);
        res.insert(std::make_pair(sw.Score, sw));
        if (res.size() >= count) {
            res.erase(res.begin());
        }
    }

    TScoredWordsWstr results;
    for (auto&& e: res) {
        TScoredWordWstr resw;
        resw.Word = std::wstring(e.second.Word.Ptr, e.second.Word.Len);
        resw.Score = e.first;
        results.push_back(resw);
    }
    return results;
}

std::vector<std::pair<std::wstring,double> > TSpellCorrector::GetMaskedWord(
        const std::vector<std::wstring>& sentence,
        size_t position,
        size_t count)
{
    TWords words;
    for (auto&& e: sentence) {
        words.push_back(TWord(e));
    }
    std::vector<std::pair<std::wstring,double> > results;
    auto scoredCandidates = GetMaskedWordRaw(words, position, count);
    for (auto s: scoredCandidates) {
        results.push_back(std::make_pair(s.Word, s.Score));
    }
    return results;
}

void TSpellCorrector::FilterCandidatesByFrequency(std::unordered_set<TWord, TWordHashPtr>& uniqueCandidates, TWord origWord) {
    if (uniqueCandidates.size() <= MaxCandiatesToCheck) {
        return;
    }

    using TCountCand = std::pair<TCount, TWord>;
    std::vector<TCountCand> candidateCounts;
    for (auto&& c: uniqueCandidates) {
        TCount cnt = LangModel.GetWordCount(LangModel.GetWordIdNoCreate(c));
        candidateCounts.push_back(std::make_pair(cnt, c));
    }
    uniqueCandidates.clear();
    std::stable_sort(candidateCounts.begin(), candidateCounts.end(), [](const TCountCand& a, const TCountCand& b) {
        return a.first > b.first;
    });

    for (size_t i = 0; i < MaxCandiatesToCheck; ++ i) {
        uniqueCandidates.insert(candidateCounts[i].second);
    }
    uniqueCandidates.insert(origWord);
}

std::vector<std::pair<std::wstring,double> > TSpellCorrector::GetCandidatesWithScores(
    const std::vector<std::wstring>& sentence,
    size_t position
) {

    TWords words;
    for (size_t i = 0; i < sentence.size(); ++i) {
        words.push_back(TWord(sentence[i]));
    }
    TScoredWords scoredCandidates = GetCandidatesRawWithPredictions(words, position);

    std::vector<std::pair<std::wstring,double> > results;
    for (auto s: scoredCandidates) {
        std::wstring word = std::wstring(s.Word.Ptr, s.Word.Len);
        if (s.Word2.Ptr && s.Word2.Len) {
            word += L" " + std::wstring(s.Word2.Ptr, s.Word2.Len);
        }
        results.push_back(std::make_pair(word, s.Prediction));
    }
    return results;
}

std::vector<std::pair<std::wstring,std::vector<double> > > TSpellCorrector::GetCandidatesFeatures(
    const std::vector<std::wstring>& sentence,
    size_t position,
    bool full
) {

    TWords words;
    for (size_t i = 0; i < sentence.size(); ++i) {
        words.push_back(TWord(sentence[i]));
    }
    TScoredWords wordsWithFeatures = GetCandidatesRawWithScores(words, position, true, full);

    std::vector<std::pair<std::wstring,std::vector<double> > > results;
    for (auto w: wordsWithFeatures) {
        std::wstring word = w.Word.Wstr();
        if (!w.Word2.empty()) {
            word += L" " + w.Word2.Wstr();
        }
        results.push_back(std::make_pair(word, w.Features));
    }
    return results;
}

std::vector<std::wstring> TSpellCorrector::GetCandidates(const std::vector<std::wstring>& sentence, size_t position) {
    TWords words;
    for (auto&& w: sentence) {
        words.push_back(TWord(w));
    }
    TScoredWords candidates = GetCandidatesRawWithPredictions(words, position);
//    TWords candidates = GetCandidatesRaw(words, position);
    std::vector<std::wstring> results;
    for (auto&& c: candidates) {
        std::wstring word(c.Word.Ptr, c.Word.Len);
        if (c.Word2.Ptr && c.Word2.Len) {
            word += L" " + std::wstring(c.Word2.Ptr, c.Word2.Len);
        }
        results.push_back(word);
    }
    return results;
}

bool TSpellCorrector::HasErrorInternal(const std::vector<std::wstring>& sentence, size_t position) {
    auto featuresDouble = ScoreFeatures(sentence, position);
    std::vector<float> features;
    for (auto f: featuresDouble) {
        features.push_back((float)f);
    }
    if (!EvaluatorErrors) {
        std::cerr << "[error] model not loaded (evaluator errors)\n";
        return true;
    }
    double result = EvaluatorErrors->Apply(features, NCatboostStandalone::EPredictionType::Class);
    return result >= 0.5;
}

std::wstring TSpellCorrector::FixFragment(const std::wstring& text) {
    TSentences origSentences = LangModel.Tokenize(text);
    std::wstring lowered = text;
    ToLower(lowered);
    TSentences sentences = LangModel.Tokenize(lowered);
    std::wstring result;
    size_t origPos = 0;
    for (size_t i = 0; i < sentences.size(); ++i) {
        TWords words = sentences[i];
        const TWords& origWords = origSentences[i];
        size_t offset = 0;
        for (size_t j = 0; j < origWords.size(); ++j) {
            TWord orig = origWords[j];
            TWord lowered = words[j+offset];
            TScoredWords candidates = GetCandidatesRawWithPredictions(words, j+offset);
            if (candidates.size() > 0) {
                words[j+offset] = candidates[0].Word;
            }
            size_t currOrigPos = orig.Ptr - &text[0];
            while (origPos < currOrigPos) {
                result.push_back(text[origPos]);
                origPos += 1;
            }
            std::wstring newWord = std::wstring(words[j+offset].Ptr, words[j+offset].Len);
            if (candidates.size() > 0 && !candidates[0].Word2.empty()) {
                newWord += L" " + std::wstring(candidates[0].Word2.Ptr, candidates[0].Word2.Len);
                ++offset;
                words.insert(words.begin()+j+offset, candidates[0].Word2);
            }
            std::wstring origWord = std::wstring(orig.Ptr, orig.Len);
            std::wstring origLowered = std::wstring(lowered.Ptr, lowered.Len);

            // if word starts with upper cased letter
            if (!FixUpperCased && origWord.size() != 0 && origLowered.size() != 0 && origWord[0] != origLowered[0]) {
                newWord = origWord;
            }
            if (newWord != origLowered) {
                for (size_t k = 0; k < newWord.size(); ++k) {
                    size_t n = k < origWord.size() ? k : origWord.size() - 1;
                    wchar_t newChar = newWord[k];
                    wchar_t origChar = origWord[n];
                    result.push_back(MakeUpperIfRequired(newChar, origChar));
                }
            } else {
                result += origWord;
            }
            origPos += orig.Len;
        }
    }
    while (origPos < text.size()) {
        result.push_back(text[origPos]);
        origPos += 1;
    }
    return result;
}

void TSpellCorrector::SetPenalty(double knownWordsPenalty, double unknownWordsPenalty) {
    KnownWordsPenalty = knownWordsPenalty;
    UnknownWordsPenalty = unknownWordsPenalty;
}

void TSpellCorrector::SetMaxCandiatesToCheck(size_t maxCandidatesToCheck) {
    MaxCandiatesToCheck = maxCandidatesToCheck;
}

const TLangModel& TSpellCorrector::GetLangModel() {
    return LangModel;
}

template<typename T>
inline void AddVec(T& target, const T& source) {
    target.insert(target.end(), source.begin(), source.end());
}


TWords TSpellCorrector::Edits(const TWord& word) {
    std::wstring w(word.Ptr, word.Len);
    TWords result;

    CandsToCheck = GetDeletes2(w);
    CandsToCheck.push_back(std::vector<std::wstring>({w}));
    ThreadResultsWords.clear();
    ThreadResults = 0;

    {
        std::lock_guard<std::mutex> lock(Lock);
        for (int i = 0; i < (int)CandsToCheck.size(); ++i) {
            ThreadTasks.push(i);
        }
    }
    CondVar.notify_all();

    while (true) {
        {
            std::unique_lock<std::mutex> lock(Lock);
            if (ThreadResults == (int)CandsToCheck.size()) {
                break;
            }
            DoneCondVar.wait(lock);
        }
    }

    return ThreadResultsWords;
}

std::vector<std::pair<TWord, TWord>> TSpellCorrector::Splits(const TWord& word, bool full) {
    std::vector<std::pair<TWord, TWord>> results;
    if (word.Len <= 1) {
        return results;
    }
    for (int i = 1; i < (int)word.Len; ++i) {
        std::wstring w1(word.Ptr, i);
        std::wstring w2(word.Ptr + i, word.Len-i);
        TWord lw1 = LangModel.GetWord(w1);
        TWord lw2 = LangModel.GetWord(w2);
        if (lw1.Ptr && lw1.Len && lw2.Ptr && lw2.Len) {
            results.emplace_back(std::make_pair(lw1, lw2));
        }
        if (full) {
            TWords lw1edits = Edits2(TWord(w1));
            TWords lw2edits = Edits2(TWord(w2));

//            std::cerr << "Word1: " << WideToUTF8(std::wstring(lw1.Ptr, lw1.Len)) << "\n";
//            std::cerr << "Candidates: ";
//            for (auto ew1: lw1edits) {
//                std::cerr << WideToUTF8(std::wstring(ew1.Ptr, ew1.Len)) << " ";
//            }
//            std::cerr << "\n";
//
//            std::cerr << "Word2: " << WideToUTF8(std::wstring(lw2.Ptr, lw2.Len)) << "\n";
//            std::cerr << "Candidates: ";
//            for (auto ew2: lw1edits) {
//                std::cerr << WideToUTF8(std::wstring(ew2.Ptr, ew2.Len)) << " ";
//            }
//            std::cerr << "\n\n";

            if (lw1.Ptr && lw1.Len) {
                lw1edits.push_back(lw1);
            }
            if (lw2.Ptr && lw2.Len) {
                lw2edits.push_back(lw2);
            }
            if (lw1edits.empty() || lw2edits.empty()) {
                continue;
            }
            for (auto ew1: lw1edits) {
                for (auto ew2: lw2edits) {
                    results.emplace_back(std::make_pair(ew1, ew2));
                }
            }
        }
    }
    return results;
}

TWords TSpellCorrector::Edits2(const TWord& word, bool lastLevel) {
    std::wstring w(word.Ptr, word.Len);
    TWords result;

    for (size_t i = 0; i < w.size() + 1; ++i) {
        // delete
        if (i < w.size()) {
            std::wstring s = w.substr(0, i) + w.substr(i+1);
            TWord c = LangModel.GetWord(s);
            if (c.Ptr && c.Len) {
                result.push_back(c);
            }
            if (!lastLevel) {
                AddVec(result, Edits2(TWord(s)));
            }
        }

        // transpose
        if (i + 1 < w.size()) {
            std::wstring s = w.substr(0, i);
            s += w.substr(i + 1, 1);
            s += w.substr(i, 1);
            if (i + 2 < w.size()) {
                s += w.substr(i+2);
            }
            TWord c = LangModel.GetWord(s);
            if (c.Ptr && c.Len) {
                result.push_back(c);
            }
            if (!lastLevel) {
                AddVec(result, Edits2(TWord(s)));
            }
        }

        // replace
        if (i < w.size()) {
            for (auto&& ch: LangModel.GetAlphabet()) {
                std::wstring s = w.substr(0, i) + ch + w.substr(i+1);
                TWord c = LangModel.GetWord(s);
                if (c.Ptr && c.Len) {
                    result.push_back(c);
                }
                if (!lastLevel) {
                    AddVec(result, Edits2(TWord(s)));
                }
            }
        }

        // inserts
        {
            for (auto&& ch: LangModel.GetAlphabet()) {
                std::wstring s = w.substr(0, i) + ch + w.substr(i);
                TWord c = LangModel.GetWord(s);
                if (c.Ptr && c.Len) {
                    result.push_back(c);
                }
                if (!lastLevel) {
                    AddVec(result, Edits2(TWord(s)));
                }
            }
        }
    }

    return result;
}

void TSpellCorrector::Inserts(const std::wstring& w, TWords& result) const {
    for (size_t i = 0; i < w.size() + 1; ++i) {
        for (auto&& ch: LangModel.GetAlphabet()) {
            std::wstring s = w.substr(0, i) + ch + w.substr(i);
            TWord c = LangModel.GetWord(s);
            if (c.Ptr && c.Len) {
                result.push_back(c);
            }
        }
    }
}

void TSpellCorrector::Inserts2(const std::wstring& w, TWords& result) const {
    for (size_t i = 0; i < w.size() + 1; ++i) {
        for (auto&& ch: LangModel.GetAlphabet()) {
            std::wstring s = w.substr(0, i) + ch + w.substr(i);
            if (Deletes1->Contains(WideToUTF8(s))) {
                Inserts(s, result);
            }
        }
    }
}

void TSpellCorrector::PrepareCache(TWordId startWordId) {
    auto&& wordToId = LangModel.GetWordToId();
    size_t n = 0;
    size_t s = 0;
    for (auto&& it: wordToId) {
        n += 1;
        s += it.first.size();
        if (n > 3000) {
            break;
        }
    }
    size_t avgWordLen = std::max(int(double(s) / n) + 1, 1);
    size_t avgWordLenMinusOne = std::max(size_t(1), avgWordLen - 1);

    uint64_t deletes1size = wordToId.size() * avgWordLen;
    uint64_t deletes2size = wordToId.size() * avgWordLen * avgWordLenMinusOne;
    deletes1size = std::max(uint64_t(1000), deletes1size);
    deletes1size = std::max(uint64_t(1000), deletes1size);

    double falsePositiveProb = 0.001;
    if (!Deletes1) {
        Deletes1.reset(new TBloomFilter(deletes1size, falsePositiveProb));
    }
    if (!Deletes2) {
        Deletes2.reset(new TBloomFilter(deletes2size, falsePositiveProb));
    }

    uint64_t deletes1real = 0;
    uint64_t deletes2real = 0;

    TWordId lastWordId = LangModel.GetLastWordId();

    for (TWordId wid = startWordId; wid < lastWordId; ++wid) {
        auto deletes = GetDeletes2(LangModel.GetWordByIdWs(wid));
        for (auto&& w1: deletes) {
            Deletes1->Insert(WideToUTF8(w1.back()));
            deletes1real += 1;
            for (size_t i = 0; i < w1.size() - 1; ++i) {
                Deletes2->Insert(WideToUTF8(w1[i]));
                deletes2real += 1;
            }
        }
    }
}

constexpr uint64_t SPELL_CHECKER_CACHE_MAGIC_BYTE = 3811558393781437494L;
constexpr uint16_t SPELL_CHECKER_CACHE_VERSION = 1;

bool TSpellCorrector::LoadCache(const std::string& cacheFile) {
    std::ifstream in(cacheFile, std::ios::binary);
    if (!in.is_open()) {
        return false;
    }
    uint16_t version = 0;
    uint64_t magicByte = 0;
    NHandyPack::Load(in, magicByte);
    if (magicByte != SPELL_CHECKER_CACHE_MAGIC_BYTE) {
        return false;
    }
    NHandyPack::Load(in, version);
    if (version != SPELL_CHECKER_CACHE_VERSION) {
        return false;
    }
    uint64_t checkSum = 0;
    NHandyPack::Load(in, checkSum);
    if (checkSum != LangModel.GetCheckSum()) {
        return false;
    }
    std::unique_ptr<TBloomFilter> deletes1(new TBloomFilter());
    std::unique_ptr<TBloomFilter> deletes2(new TBloomFilter());
    deletes1->Load(in);
    deletes2->Load(in);
    magicByte = 0;
    NHandyPack::Load(in, magicByte);
    if (magicByte != SPELL_CHECKER_CACHE_MAGIC_BYTE) {
        return false;
    }
    Deletes1 = std::move(deletes1);
    Deletes2 = std::move(deletes2);
    return true;
}

bool TSpellCorrector::SaveCache(const std::string& cacheFile) {
    std::ofstream out(cacheFile, std::ios::binary);
    if (!out.is_open()) {
        return false;
    }
    if (!Deletes1 || !Deletes2) {
        return false;
    }
    NHandyPack::Dump(out, SPELL_CHECKER_CACHE_MAGIC_BYTE);
    NHandyPack::Dump(out, SPELL_CHECKER_CACHE_VERSION);
    NHandyPack::Dump(out, LangModel.GetCheckSum());
    Deletes1->Dump(out);
    Deletes2->Dump(out);
    NHandyPack::Dump(out, SPELL_CHECKER_CACHE_MAGIC_BYTE);
    return true;
}

double TSpellCorrector::Score(const std::wstring& text) {
    return LangModel.Score(text);
}

std::vector<double> TSpellCorrector::ScoreFeatures(const std::vector<std::wstring>& sentence, size_t position) {
    TWords words;
    for (size_t i = 0; i < sentence.size(); ++i) {
        words.push_back(TWord(sentence[i]));
    }
    std::vector<double> features;
    LangModel.ScoreFeatures(words, position, features);
    return features;
}

bool TSpellCorrector::LoadAlphabet(const std::string &alphabetFile) {
    return LangModel.GetTokenizer().LoadAlphabet(alphabetFile);
}

} // NJamSpell
