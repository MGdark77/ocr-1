#pragma once

#include <memory>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>

#include "contrib/catboost_evaluator/evaluator.h"

#include "lang_model.hpp"
#include "bloom_filter.hpp"

namespace NJamSpell {


class TSpellCorrector {
public:
    TSpellCorrector(int numThreads = 0);
    ~TSpellCorrector();
    bool LoadLangModel(const std::string& modelPath);
    bool SaveLangModel(const std::string& modelPath);

    // wstring API
    std::vector<std::wstring> GetCandidates(const std::vector<std::wstring>& sentence, size_t position);
    std::vector<std::pair<std::wstring,double> > GetCandidatesWithScores(const std::vector<std::wstring>& sentence, size_t position);
    std::wstring FixFragment(const std::wstring& text);
    void AddText(const std::wstring& text, double priority = 0.01, bool addToDictionary = false);

    // string API
    std::vector<std::string> GetCandidatesU(const std::vector<std::string>& sentence, size_t position);
    std::vector<std::pair<std::string,double> > GetCandidatesWithScoresU(const std::vector<std::string>& sentence, size_t position);
    std::string FixFragmentU(const std::string& text);
    void AddTextU(const std::string& text, double priority = 0.01);

    bool TrainLangModel(
            const std::string& textFile, const std::string& alphabetFile, const std::string& modelFile,
            const std::string& tmpDir, const std::string& gramsFile
        );
    bool TrainAdd(const std::string& textFile, const std::string& modelPath, double priority = 0.001, const std::string& gramsFile = std::string());

    void SetDictionaryWordFixPenalty(double newPenalty);
    void SetShortWordsAfterNumberLength(int length);
    void SetFixUpperCased(bool fixUpper);

    NJamSpell::TScoredWords GetCandidatesRawWithScores(const NJamSpell::TWords& sentence, size_t position, bool needFeatures = false, bool full = true);
    NJamSpell::TScoredWords GetCandidatesRawWithPredictions(const NJamSpell::TWords& sentence, size_t position);
    bool HasErrorRaw(const NJamSpell::TWords& sentence, size_t position);
    bool HasErrorInternal(const std::vector<std::wstring>& sentence, size_t position);
    NJamSpell::TScoredWordsWstr GetMaskedWordRaw(const NJamSpell::TWords& sentence, size_t position, size_t count);
    std::vector<std::pair<std::wstring,double> > GetMaskedWord(const std::vector<std::wstring>& sentence, size_t position, size_t count);
    std::vector<std::pair<std::wstring,std::vector<double> > > GetCandidatesFeatures(const std::vector<std::wstring>& sentence, size_t position, bool full);
    void SetPenalty(double knownWordsPenalty, double unknownWordsPenalty);
    void SetMaxCandiatesToCheck(size_t maxCandidatesToCheck);
    const NJamSpell::TLangModel& GetLangModel();
    double Score(const std::wstring& text);
    std::vector<double> ScoreFeatures(const std::vector<std::wstring>& sentence, size_t position);

    bool LoadAlphabet(const std::string& alphabetFile);
private:
    void Worker();
    void ProcessTask(int taskID);
private:
    void FilterCandidatesByFrequency(std::unordered_set<NJamSpell::TWord, NJamSpell::TWordHashPtr>& uniqueCandidates, NJamSpell::TWord origWord);
    TScoredWord MakeScoredWord(
            TWord candWord1, TWord candWord2, const TWords& sentence, size_t position,
            bool firstLevel,bool knownWord, bool needFeatures
    );
    std::vector<std::pair<NJamSpell::TWord, NJamSpell::TWord>> Splits(const NJamSpell::TWord& word, bool full = false);
    NJamSpell::TWords Edits(const NJamSpell::TWord& word);
    NJamSpell::TWords Edits2(const NJamSpell::TWord& word, bool lastLevel = true);
    void Inserts(const std::wstring& w, NJamSpell::TWords& result) const;
    void Inserts2(const std::wstring& w, NJamSpell::TWords& result) const;
    void PrepareCache(TWordId startWordId = 0);
    bool LoadCache(const std::string& cacheFile);
    bool SaveCache(const std::string& cacheFile);
private:
    TLangModel LangModel;
    std::unique_ptr<TBloomFilter> Deletes1;
    std::unique_ptr<TBloomFilter> Deletes2;
    double DictionaryWordFixPenalty = 0.0;
    double KnownWordsPenalty = 20.0;
    double UnknownWordsPenalty = 5.0;
    size_t MaxCandiatesToCheck = 999;
    int ShortWordsAfterNumbersLength = 0;
    bool FixUpperCased = true;
    std::unique_ptr<NCatboostStandalone::TOwningEvaluator> EvaluatorShort;
    std::unique_ptr<NCatboostStandalone::TOwningEvaluator> EvaluatorErrors;
    std::unique_ptr<NCatboostStandalone::TOwningEvaluator> EvaluatorRank;
    std::vector<std::unique_ptr<std::thread>> Threads;
    std::mutex Lock;
    std::condition_variable CondVar;
    std::condition_variable DoneCondVar;
    bool Finished = false;
    std::queue<int> ThreadTasks;
    int ThreadResults = 0;
    std::vector<std::vector<std::wstring>> CandsToCheck;
    TWords ThreadResultsWords;
};


} // NJamSpell
