#include "dictionary.hpp"
#include "utils.hpp"


namespace NJamSpell {


void TDictionary::Load(const std::string& fileName) {
    std::string data = LoadFile(fileName);
    std::string currWord;
    for (auto c: data) {
        if (c == '\n') {
            if (currWord.size() > 0) {
                std::wstring wword = UTF8ToWide(currWord);
                Data.insert(wword);
                currWord = "";
            }
        } else if (c != '\r'){
            currWord += c;
        }
    }
}

void TDictionary::Save(const std::string& fileName) {
    if (!Modified) {
        return;
    }
    std::string data;
    for (auto&& w: Data) {
        data += WideToUTF8(w) + "\n";
    }
    SaveFile(fileName, data);
}

bool TDictionary::Exists(const std::wstring& word) const {
    return Data.find(word) != Data.end();
}

TWord TDictionary::GetWord(const std::wstring& word) const {
    auto it = Data.find(word);
    if (it == Data.end()) {
        return TWord();
    }
    return TWord(*it);
}

void TDictionary::AddWord(const std::wstring& word) {
    Modified = true;
    Data.insert(word);
}

} // NJamSpell
