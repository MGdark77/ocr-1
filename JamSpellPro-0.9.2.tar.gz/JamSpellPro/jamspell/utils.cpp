#include <fstream>
#include <sstream>
#include <chrono>
#include <cassert>
#include <iostream>
#include <cassert>
#include <algorithm>

#ifdef USE_BOOST_CONVERT
    #include <boost/locale/encoding_utf.hpp>
#else
    #include <codecvt>
#endif

#include "utils.hpp"

#include <contrib/cityhash/city.h>


namespace NJamSpell {

std::string LoadFile(const std::string& fileName) {
    std::ifstream in(fileName, std::ios::binary);
    std::ostringstream out;
    out << in.rdbuf();
    return out.str();
}

void SaveFile(const std::string& fileName, const std::string& data) {
    std::ofstream out(fileName, std::ios::binary);
    out << data;
}


TFileLoader::TFileLoader(const std::string& fileName, int bufferSize) {
    BufferSize = bufferSize;
    In.reset(new std::ifstream(fileName, std::ios::binary));
    Buffer.reserve(BufferSize+10);
}

std::wstring TFileLoader::ReadNext() {
    Buffer.resize(BufferSize);
    In->read(&Buffer[0], BufferSize);
    Buffer.resize(In->gcount());
    if (Buffer.size() < (size_t)BufferSize) {
        return UTF8ToWide(Buffer);
    }
    std::string tmp = " ";
    while (true) {
        In->read(&tmp[0], 1);
        if (In->gcount() == 0) {
            break;
        }
        Buffer += tmp;
        if (tmp[0] == '\n') {
            break;
        }
    }
    return UTF8ToWide(Buffer);
}


TTokenizer::TTokenizer()
    : Locale("en_US.utf-8")
{
}

std::vector<std::wstring> Split(const std::wstring& str, const wchar_t delim) {
    std::vector<std::wstring> result;
    std::wstring currStr;
    for (auto c: str) {
        if (c == delim) {
            if (!currStr.empty()) {
                result.push_back(currStr);
            }
            currStr = std::wstring();
        } else {
            currStr += c;
        }
    }
    if (!currStr.empty()) {
        result.push_back(currStr);
    }
    return result;
}

std::unordered_set<wchar_t> StrToSet(const std::wstring& str) {
    std::unordered_set<wchar_t> res;
    for (auto chr: str) {
        if (chr == 10 || chr == 13) {
            continue;
        }
        res.insert(chr);
    }
    return res;
}

bool TTokenizer::LoadAlphabet(const std::string& alphabetFile) {
    std::string data = LoadFile(alphabetFile);
    if (data.empty()) {
        std::cerr << "[error] failed to load alphabet - file not exists or empty\n";
        return false;
    }
    std::wstring wdata = UTF8ToWide(data);
    if (wdata.empty()) {
        std::cerr << "[error] failed to load alphabet - file is empty\n";
        return false;
    }
    std::vector<std::wstring> lines = Split(wdata, L'\n');
    if (lines.empty()) {
        std::cerr << "[error] failed to load alphabet - no lines in file\n";
        return false;
    }
    for (int i = 1; i < lines.size(); ++i) {
        std::vector<std::wstring> params = Split(lines[i], L'\t');
        if (params.size() != 2) {
            std::cerr << "[error] failed to load alphabet - failed to parse line " << i + 1 << "\n";
            return false;
        }
        if (params[0] == L"begin_end_strip") {
            BeginEndStrip = StrToSet(params[1]);
            if (BeginEndStrip.empty()) {
                std::cerr << "[error] failed to load alphabet - empty begin end strip\n";
                return false;
            }
        }
    }
    std::wstring& walphabet = lines[0];
    ToLower(walphabet);
    walphabet += L"0123456789";
    Alphabet = StrToSet(walphabet);
    if (Alphabet.empty()) {
        return false;
    }
    return true;
}

TWord StripBeginEnd(TWord word, const std::unordered_set<wchar_t>& charsToStrip) {
    if (word.empty() || charsToStrip.empty()) {
        return word;
    }
    int startPos = 0;
    int endPos = word.Len-1;
    for (int i = 0; i < word.Len; ++i) {
        startPos = i;
        if (charsToStrip.find(word.Ptr[i]) == charsToStrip.end()) {
            break;
        }
    }
    for (int i = endPos; i >= 0; --i) {
        endPos = i;
        if (charsToStrip.find(word.Ptr[i]) == charsToStrip.end()) {
            break;
        }
    }
    if (startPos > endPos) {
        return TWord();
    }
    if (startPos == endPos && charsToStrip.find(word.Ptr[startPos]) != charsToStrip.end()) {
        return TWord();
    }
    return TWord(word.Ptr+startPos, endPos-startPos+1);
}

TSentences TTokenizer::Process(const std::wstring& originalText) const {
    if (originalText.empty()) {
        return TSentences();
    }

    TSentences sentences;

    TWords currSentence;
    TWord currWord;

    for (size_t i = 0; i < originalText.size(); ++i) {
        wchar_t letter = std::tolower(originalText[i], Locale);
        if (Alphabet.find(letter) != Alphabet.end()) {
            if (currWord.Ptr == nullptr) {
                currWord.Ptr = &originalText[i];
            }
            currWord.Len += 1;
        } else {
            if (!currWord.empty()) {
                currWord = StripBeginEnd(currWord, BeginEndStrip);
                if (!currWord.empty()) {
                    currSentence.push_back(currWord);
                    currWord = TWord();
                }
            }
        }
        if (letter == L'?' || letter == L'!' || letter == L'.') {
            if (!currSentence.empty()) {
                sentences.push_back(currSentence);
                currSentence.clear();
            }
        }
    }
    if (!currWord.empty()) {
        currSentence.push_back(currWord);
    }
    if (!currSentence.empty()) {
        sentences.push_back(currSentence);
    }

    return sentences;
}

void TTokenizer::Clear() {
    Alphabet.clear();
}

const std::unordered_set<wchar_t>& TTokenizer::GetAlphabet() const {
    return Alphabet;
}

std::wstring UTF8ToWide(const std::string& text) {
#ifdef USE_BOOST_CONVERT
    using boost::locale::conv::utf_to_utf;
    return utf_to_utf<wchar_t>(text.c_str(), text.c_str() + text.size());
#else
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t, 0x10ffff, std::little_endian>> converter;
    return converter.from_bytes(text);
#endif
}

std::string WideToUTF8(const std::wstring& text) {
#ifdef USE_BOOST_CONVERT
    using boost::locale::conv::utf_to_utf;
    return utf_to_utf<char>(text.c_str(), text.c_str() + text.size());
#else
    using convert_type = std::codecvt_utf8<wchar_t, 0x10ffff, std::little_endian>;
    std::wstring_convert<convert_type, wchar_t> converter;
    return converter.to_bytes(text);
#endif
}

uint64_t GetCurrentTimeMs() {
    using namespace std::chrono;
    milliseconds ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
    return ms.count();
}

static const std::locale GLocale("en_US.UTF-8");
static const std::ctype<wchar_t>& GWctype = std::use_facet<std::ctype<wchar_t>>(GLocale);

void ToLower(std::wstring& text) {
    std::transform(text.begin(), text.end(), text.begin(), [](wchar_t wch) {
        return GWctype.tolower(wch);
    });
}

wchar_t MakeUpperIfRequired(wchar_t orig, wchar_t sample) {
    if (GWctype.toupper(sample) == sample) {
        return GWctype.toupper(orig);
    }
    return orig;
}

uint16_t CityHash16(const std::string& str) {
    uint32_t hash = CityHash32(&str[0], str.size());
    return hash % std::numeric_limits<uint16_t>::max();
}

uint16_t CityHash16(const char* str, size_t size) {
    uint32_t hash = CityHash32(str, size);
    return hash % std::numeric_limits<uint16_t>::max();
}

} // NJamSpell
