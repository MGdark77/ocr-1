## Ruby example

This is a simple example of building jamspell for ruby (`test.rb`):

```
require 'jamspellpro'
jsp = Jamspellpro::TSpellCorrector.new()
jsp.LoadLangModel('../test_data/test_model')
print jsp.FixFragment('test sqntence'), "\n"
```


#### Requirements
- latest swig (worked on swig4, may work on swig3 but not sure)
- ruby with headers
- cpp compiler (checked on clang, should work on gcc, not sure about vsc)

#### Steps
- Edit `build_ruby.sh`. Set SWIG_BINARY, RUBY_LIB, RUBY_INCLUDE, RUBY_INCLUDE2 path
- Run `./build_ruby.sh`
- Run `ruby test.rb`
- Clean files with `./clean.sh`

