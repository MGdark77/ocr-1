require 'jamspellpro'
jsp = Jamspellpro::TSpellCorrector.new()
jsp.LoadLangModel('../test_data/test_model')
print jsp.FixFragment('test sqntence'), "\n"

