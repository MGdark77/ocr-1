rm -rf *.cxx *.bundle
