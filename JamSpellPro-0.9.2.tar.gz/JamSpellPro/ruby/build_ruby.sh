set -e

SWIG_BINARY='/usr/local/opt/swig@4.0/bin/swig'

RUBY_LIB='/Users/filipp/.rbenv/versions/2.6.3/lib/'
RUBY_INCLUDE='/Users/filipp/.rbenv/versions/2.6.3/include/ruby-2.6.0/x86_64-darwin19'
RUBY_INCLUDE2='/Users/filipp/.rbenv/versions/2.6.3/include/ruby-2.6.0/'



$SWIG_BINARY -ruby -c++ -outcurrentdir ../jamspellpro.i

g++ -shared -std=c++11 -L$RUBY_LIB -lruby -I$RUBY_INCLUDE -I$RUBY_INCLUDE2 -I../ -I../contrib jamspellpro_wrap.cxx ../contrib/bloom/*.cpp ../contrib/phf/*.cc ../contrib/cityhash/*.cc ../contrib/tsl/*.cpp  ../contrib/catboost_evaluator/*.cpp ../jamspell/*.cpp -o jamspellpro.bundle

