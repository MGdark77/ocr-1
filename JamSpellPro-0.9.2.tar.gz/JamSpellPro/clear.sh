#!/usr/bin/env bash
rm -rf tmpbuild/ jamspell.egg-info/ dist/ build/ jamspell.py jamspell.egg-info/ jamspell_wrap.cpp _jamspell.so .cache
rm -rf tmpbuild/ jamspellpro.egg-info/ dist/ build/ jamspellpro.py jamspellpro.egg-info/ jamspellpro_wrap.cpp _jamspellpro.so .cache
rm -rf catboost_error.bin catboost_rank.bin catboost_short.bin frequencies.bin frequencies.bin.spell 
rm -rf *.tmp
rm -rf temp temp_model
