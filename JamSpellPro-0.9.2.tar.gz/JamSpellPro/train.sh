rm -rf tmpbuild
mkdir tmpbuild
cd tmpbuild
cmake ..
make
./main/jamspell train ../test_data/alphabet_en.txt ../dataset/eng_big_train.txt en_new.bin
mv en_new.bin ../dataset/en_new.bin
cd ..
python3.7 setup.py install
python2.7 setup.py install
