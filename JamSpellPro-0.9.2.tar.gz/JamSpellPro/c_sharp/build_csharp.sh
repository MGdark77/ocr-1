set -e

SWIG_BINARY='/usr/local/opt/swig@4.0/bin/swig'

$SWIG_BINARY -csharp -c++ -outcurrentdir ../jamspellpro.i
g++ -std=c++17 -shared -I../ -I../contrib jamspellpro_wrap.cxx ../contrib/bloom/*.cpp ../contrib/phf/*.cc ../contrib/cityhash/*.cc ../contrib/tsl/*.cpp  ../contrib/catboost_evaluator/*.cpp ../jamspell/*.cpp -o libjamspellpro.so

