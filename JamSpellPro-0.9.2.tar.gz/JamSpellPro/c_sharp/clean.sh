
ls *.cs | grep -v runme.cs | xargs rm -f
rm -rf *.class
rm -rf *.exe
rm -rf jamspellpro_wrap.cxx
rm -rf libjamspellpro.so

