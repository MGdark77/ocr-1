## C# example

This is a simple example of building jamspell for c# (`runme.cs`):

```
using System;
public class runme {
     static void Main() {
         var jsp = new TSpellCorrector();
         jsp.LoadLangModel("../test_data/test_model/");
         Console.WriteLine(jsp.FixFragmentU("read the sqntence"));
     }
}
```

**WARNING**: You should add `U` letter to all methods (eg. `FixFragmentU` instead of `FixFragment`, it is a swig issue workaround)

#### Requirements
- latest swig (worked on swig4, may work on swig3 but not sure)
- c# compiler
- cpp compiler (checked on clang, should work on gcc, not sure about vsc)

#### Steps
- Edit `build_csharp.sh`. Set SWIG_BINARY path
- Run `./build_csharp.sh`
- Compile with `csc -out:runme.exe`
- Run `mono runme.exe`
- Clean files with `./clean.sh`

