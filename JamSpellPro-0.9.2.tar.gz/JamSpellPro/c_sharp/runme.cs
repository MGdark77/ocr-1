using System;
public class runme {
     static void Main() {
         var jsp = new TSpellCorrector();
         jsp.LoadLangModel("../test_data/test_model/");
         Console.WriteLine(jsp.FixFragmentU("read the sqntence"));
     }
}
