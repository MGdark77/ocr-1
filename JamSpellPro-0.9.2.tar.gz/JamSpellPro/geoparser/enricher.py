#!/usr/bin/env python3

import os, sys
import tqdm
import pymorphy2

def main():
    fname = sys.argv[1]
    lang = sys.argv[2]
    morpher = None
    if lang == 'ru':
        morpher = pymorphy2.MorphAnalyzer()
    print('read file')
    data = open(fname, 'r').read().split()
    allWords = set()
    print('processing')
    for w in tqdm.tqdm(data):
        if not w:
            continue
        wl = w.lower()
        if wl[0] == w[0]:
            continue
        allWords.add(w)
    with open('geo_words_' + lang + '.txt', 'w') as f:
        f.write('\n'.join(allWords))

    if morpher is None:
        return
    print('generating word forms')
    allWordForms = set()
    for w in tqdm.tqdm(allWords):
        wa = morpher.parse(w)
        for wp in wa:
            for wl in wp.lexeme:
                wlw = wl.word
                allWordForms.add(wlw)
    with open('geo_word_forms_' + lang + '.txt', 'w') as f:
        f.write('\n'.join(allWordForms))


if __name__ == '__main__':
    main()
