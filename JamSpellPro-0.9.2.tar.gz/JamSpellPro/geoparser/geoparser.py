#!/usr/bin/env python3

from __future__ import print_function
import os, sys
import lxml.etree as ET
import reverse_geocoder as rg

BATCH_SIZE = 5000


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def processRecords(records, requiredCountries):
    coordReq = [r[0] for r in records]
    coordRes = [r['cc'].lower() for r in rg.search(coordReq, mode=1, verbose=False)]
    #coordRes = [requiredCountries[0] for e in coordReq]
    for i, record in enumerate(records):
        country = coordRes[i]
        strongMatch = record[1]
        name = record[2]
        if strongMatch or country in requiredCountries:
            print(name)

class FileWrapper(object):
    def __init__(self, fileName):
        self.f = open(fileName, 'rb')
        self.started = False
        self.finished = False

    def read(self, size):
        if not self.started:
            self.started = True
            result = b'<root>\n' + self.f.read(size)
        else:
            result = self.f.read(size)
        if len(result) < size and not self.finished:
            result += b'\n</root>\n'
            self.finished = True
        return result

def main():
    fname = sys.argv[1]
    requiredLangs = sys.argv[2].lower().split(',')

    strongMatchNames = ['name:'+rl for rl in requiredLangs]

    context = ET.iterparse(FileWrapper(fname), events=("start",))

    records = []
    coords = None
    n = 0
    for event, elem in context:
        tag = elem.tag
        if tag == 'node':
            coords = (float(elem.get('lat')), float(elem.get('lon')))
        if tag == 'tag':
            strongMatch = False
            if elem.get('k') in strongMatchNames:
                strongMatch = True
            elif elem.get('k') != 'name':
                continue
            val = elem.get('v')
            records.append((
                coords,
                strongMatch,
                val
            ))
            if len(records) == BATCH_SIZE:
                processRecords(records, requiredLangs)
                del records
                records = []
                n += 1
                eprint("processed batch:", n)

        elem.clear()
        # Also eliminate now-empty references from the root node to elem
        for ancestor in elem.xpath('ancestor-or-self::*'):
            while ancestor.getprevious() is not None:
                del ancestor.getparent()[0]

    if records:
        processRecords(records, requiredLangs)

if __name__ == '__main__':
    main()
