osmfilter --keep= --keep-nodes="name" planet.o5m | grep 'name\|node\|root' > dump.xml

