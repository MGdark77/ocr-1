1) Download full planet OpenStreetMap:
```
download-osm planet
```
2) Convert it to o5m:
```
osmconvert planet-201026.osm.pbf -o=planet.o5m
```
3) Filter names:
```
osmfilter --keep= --keep-nodes="name" planet.o5m | grep 'name\|node\|root' > dump.xml
```
4) Extract only text names:
```
python3.7 geoparser.py dump.xml en,gb,us > geo_en.txt
```
5) Add all lexemes:
```
python3.7 enricher.py geo_en.txt
```

