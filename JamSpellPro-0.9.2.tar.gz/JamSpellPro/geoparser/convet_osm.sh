osmconvert planet-201026.osm.pbf -o=planet.o5m
