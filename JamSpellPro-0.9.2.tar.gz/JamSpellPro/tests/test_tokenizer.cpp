#include <gtest/gtest.h>

#include <jamspell/utils.hpp>

TEST(StripBeginEndTest, basicFlow) {

    std::unordered_set<wchar_t> charsToStrip;
    charsToStrip.insert(L'x');
    std::wstring str = L"test";
    NJamSpell::TWord word(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_EQ(L"test", word.Wstr());

    str = L"xxtestx";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_EQ(L"test", word.Wstr());

    str = L"xxx";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_TRUE(word.empty());

    str = L"";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_TRUE(word.empty());

    str = L"x";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_TRUE(word.empty());

    str = L"a";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_EQ(L"a", word.Wstr());

    str = L"ax";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_EQ(L"a", word.Wstr());

    str = L"xa";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_EQ(L"a", word.Wstr());

    str = L"axa";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_EQ(L"axa", word.Wstr());

    str = L"xaxaxaxxx";
    word = NJamSpell::TWord(str);
    word = NJamSpell::StripBeginEnd(word, charsToStrip);
    ASSERT_EQ(L"axaxa", word.Wstr());
}
